/**
 * Bara Indah Sinergi Group - Workflow Approval Web App
 * Server-Side Script (Code.js)
 */

// Render the main web application UI
function doGet(e) {
  // Automatically initialize database if tables don't exist
  try {
    setupSheets();
  } catch (err) {
    Logger.log("Auto setup sheets error: " + err.toString());
  }
  
  var template = HtmlService.createTemplateFromFile('Index');
  template.appUrl = ScriptApp.getService().getUrl();
  return template.evaluate()
    .setTitle('Bara Indah Sinergi Group - Dashboard')
    .setSandboxMode(HtmlService.SandboxMode.IFRAME)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// Include utility to inject split HTML files (CSS / JS) into the main template.
// NOTE: When copying to Google Apps Script, ensure files are named EXACTLY:
//   Index.html  →  named "Index"  in the GAS editor
//   Stylesheet.html → named "Stylesheet" in the GAS editor
//   JavaScript.html → named "JavaScript" in the GAS editor
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/**
 * DATABASE CONNECTOR
 * Dynamically gets the active spreadsheet or creates one if not found.
 */
function getSpreadsheet() {
  var ss;
  try {
    ss = SpreadsheetApp.getActiveSpreadsheet();
    if (ss) return ss;
  } catch (e) {
    // Container-bound spreadsheet not active
  }
  
  var props = PropertiesService.getScriptProperties();
  var ssId = props.getProperty('SPREADSHEET_ID');
  if (ssId) {
    try {
      return SpreadsheetApp.openById(ssId);
    } catch (e) {
      // Invalid spreadsheet ID, recreate
    }
  }
  
  // Standalone mode: Create a new spreadsheet
  ss = SpreadsheetApp.create('Bara Indah Sinergi Group - Workflow DB');
  props.setProperty('SPREADSHEET_ID', ss.getId());
  return ss;
}

/**
 * HELPER: Convert sheet values to Array of Objects
 */
function getSheetDataAsObjects(sheetName) {
  if (useGitHub()) {
    return getGitHubData(sheetName);
  }
  var ss = getSpreadsheet();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  
  var data = sheet.getDataRange().getValues();
  if (data.length <= 1) return [];
  
  var headers = data[0];
  var rows = data.slice(1);
  
  return rows.map(function(row) {
    var obj = {};
    headers.forEach(function(header, index) {
      if (header !== undefined && header !== null) {
        var val = row[index];
        obj[header] = val;
        // Map lowercase key
        var lowerHeader = header.toString().toLowerCase().trim();
        if (header.toString() !== lowerHeader) {
          obj[lowerHeader] = val;
        }
        // Map TitleCase key
        var titleHeader = lowerHeader.charAt(0).toUpperCase() + lowerHeader.slice(1);
        if (header.toString() !== titleHeader) {
          obj[titleHeader] = val;
        }
      }
    });
    return obj;
  });
}

/**
 * HELPER: Append object to sheet
 */
function appendObjectToSheet(sheetName, obj) {
  if (useGitHub()) {
    appendGitHubRecord(sheetName, obj);
    return;
  }
  var ss = getSpreadsheet();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return;
  
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var row = headers.map(function(header) {
    return obj[header] !== undefined ? obj[header] : "";
  });
  sheet.appendRow(row);
}

/**
 * HELPER: Update object in sheet by matching ID
 */
function updateObjectInSheet(sheetName, idValue, updatedFields) {
  if (useGitHub()) {
    return updateGitHubRecord(sheetName, idValue, updatedFields);
  }
  var ss = getSpreadsheet();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return false;
  
  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var idIndex = headers.indexOf('ID');
  if (idIndex === -1) idIndex = headers.indexOf('id');
  if (idIndex === -1) return false;
  
  for (var i = 1; i < data.length; i++) {
    if (data[i][idIndex].toString() === idValue.toString()) {
      for (var key in updatedFields) {
        var headerIndex = headers.indexOf(key);
        if (headerIndex !== -1) {
          sheet.getRange(i + 1, headerIndex + 1).setValue(updatedFields[key]);
        }
      }
      return true;
    }
  }
  return false;
}

/**
 * DASHBOARD ENDPOINTS
 */
function getDashboardData() {
  var requests = getSheetDataAsObjects('t_requests');
  var budgets = getSheetDataAsObjects('t_budget');
  var logs = getSheetDataAsObjects('t_audit_log');
  
  // 1. Core KPIs
  var totalPD = 0;
  var countPD = 0;
  var totalPR = 0;
  var countPR = 0;
  var pendingCount = 0;
  var approvedCount = 0;
  var rejectedCount = 0;
  
  requests.forEach(function(req) {
    var nominal = parseFloat(req.TotalNominal) || 0;
    var status = req.Status ? req.Status.toUpperCase() : '';
    
    if (req.Type === 'PD') {
      totalPD += nominal;
      countPD++;
    } else if (req.Type === 'PR') {
      totalPR += nominal;
      countPR++;
    }
    
    if (status === 'PENDING') pendingCount++;
    else if (status === 'APPROVED') approvedCount++;
    else if (status === 'REJECTED') rejectedCount++;
  });
  
  // Annual and Available Budget
  var totalBudgetLimit = 0;
  var totalBudgetActual = 0;
  budgets.forEach(function(b) {
    totalBudgetLimit += parseFloat(b.AnnualBudget) || 0;
    totalBudgetActual += parseFloat(b.ActualBudget) || 0;
  });
  var budgetAvailable = totalBudgetLimit - totalBudgetActual;
  var budgetUtilPercent = totalBudgetLimit > 0 ? Math.round((totalBudgetActual / totalBudgetLimit) * 100) : 0;
  
  // 2. Charts Data
  // Monthly Trends (past 6 months)
  var monthlyTrend = {};
  var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // Pre-fill with recent months
  var currentMonth = new Date().getMonth();
  for (var i = 5; i >= 0; i--) {
    var mIdx = (currentMonth - i + 12) % 12;
    monthlyTrend[months[mIdx]] = { PD: 0, PR: 0 };
  }
  
  requests.forEach(function(req) {
    var date = new Date(req.Date);
    var reqMonth = months[date.getMonth()];
    var nominal = parseFloat(req.TotalNominal) || 0;
    if (monthlyTrend[reqMonth] !== undefined) {
      if (req.Type === 'PD') monthlyTrend[reqMonth].PD += nominal;
      if (req.Type === 'PR') monthlyTrend[reqMonth].PR += nominal;
    }
  });
  
  var chartMonths = Object.keys(monthlyTrend);
  var chartPD = chartMonths.map(function(m) { return monthlyTrend[m].PD; });
  var chartPR = chartMonths.map(function(m) { return monthlyTrend[m].PR; });
  
  // Department Distribution
  var deptCounts = {};
  requests.forEach(function(req) {
    var dept = req.Department || 'External';
    deptCounts[dept] = (deptCounts[dept] || 0) + 1;
  });
  
  var totalReqCount = requests.length || 1;
  var chartDepts = Object.keys(deptCounts);
  var chartDeptPercentages = chartDepts.map(function(d) {
    return Math.round((deptCounts[d] / totalReqCount) * 100);
  });
  
  // 3. Department Overview
  var deptOverview = {};
  budgets.forEach(function(b) {
    var d = b.Department;
    if (!deptOverview[d]) {
      deptOverview[d] = { dept: d, budget: 0, pdCount: 0, prCount: 0 };
    }
    deptOverview[d].budget += parseFloat(b.AnnualBudget) || 0;
  });
  
  requests.forEach(function(req) {
    var d = req.Department || 'External';
    if (!deptOverview[d]) {
      deptOverview[d] = { dept: d, budget: 0, pdCount: 0, prCount: 0 };
    }
    if (req.Type === 'PD') deptOverview[d].pdCount++;
    if (req.Type === 'PR') deptOverview[d].prCount++;
  });
  
  var deptOverviewList = Object.keys(deptOverview).map(function(key) {
    return deptOverview[key];
  });
  
  // 4. Approval Progress counts per step
  var approvalProgress = {
    headDept: 0,
    projectManager: 0,
    finance: 0,
    costControl: 0,
    gmCfo: 0
  };
  
  requests.forEach(function(req) {
    if (req.Status === 'Pending') {
      var role = req.CurrentApproverRole;
      if (role === 'Head Department') approvalProgress.headDept++;
      else if (role === 'Project Manager') approvalProgress.projectManager++;
      else if (role === 'Finance') approvalProgress.finance++;
      else if (role === 'Cost Control') approvalProgress.costControl++;
      else if (role === 'GM/CFO') approvalProgress.gmCfo++;
    }
  });
  
  // 5. Recent Activities
  var sortedRequests = requests.slice().sort(function(a, b) {
    return new Date(b.CreatedAt) - new Date(a.CreatedAt);
  });
  var recentActivities = sortedRequests.slice(0, 10).map(function(req) {
    return {
      type: req.Type,
      docNumber: req.DocNumber,
      subject: req.Subject,
      requester: req.Requester,
      status: req.Status,
      date: Utilities.formatDate(new Date(req.Date), "GMT+8", "yyyy-MM-dd"),
      nominal: parseFloat(req.TotalNominal) || 0
    };
  });
  
  // 6. Recent Notifications (logs about submissions / approvals)
  var sortedLogs = logs.slice().sort(function(a, b) {
    return new Date(b.Timestamp) - new Date(a.Timestamp);
  });
  var notifications = sortedLogs.slice(0, 5).map(function(log) {
    return {
      id: log.ID,
      activity: log.Activity,
      docNumber: log.DocNumber,
      user: log.User,
      timeAgo: getTimeAgo(new Date(log.Timestamp))
    };
  });
  
  return {
    kpis: {
      totalPD: totalPD,
      countPD: countPD,
      totalPR: totalPR,
      countPR: countPR,
      pendingCount: pendingCount,
      approvedCount: approvedCount,
      rejectedCount: rejectedCount,
      budgetAvailable: budgetAvailable,
      totalBudgetLimit: totalBudgetLimit,
      budgetUtilPercent: budgetUtilPercent
    },
    charts: {
      labels: chartMonths,
      pdData: chartPD,
      prData: chartPR,
      deptLabels: chartDepts,
      deptData: chartDeptPercentages
    },
    deptOverview: deptOverviewList,
    approvalProgress: approvalProgress,
    recentActivities: recentActivities,
    notifications: notifications
  };
}

// Convert date to "x mins ago" etc.
function getTimeAgo(date) {
  var now = new Date();
  var diffMs = now - date;
  var diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return diffMins + " mins ago";
  var diffHrs = Math.floor(diffMins / 60);
  if (diffHrs < 24) return diffHrs + " hours ago";
  var diffDays = Math.floor(diffHrs / 24);
  return diffDays + " days ago";
}

/**
 * FORM SUBMISSION ENDPOINT
 */
function submitRequest(metadata, items) {
  try {
    if (useGitHub()) {
      if (metadata.attachment && metadata.attachment.indexOf('data:') === 0) {
        metadata.attachment = uploadToGitHubStorage(metadata.attachment, metadata.attachmentName || 'attachment.pdf');
      }
      if (metadata.budgetCapture && metadata.budgetCapture.indexOf('data:') === 0) {
        metadata.budgetCapture = uploadToGitHubStorage(metadata.budgetCapture, 'budget_capture.png');
      }
    } else {
      var ss = getSpreadsheet();
      var requestsSheet = ss.getSheetByName('t_requests');
      var itemsSheet = ss.getSheetByName('t_request_items');
      
      // Auto-migrate schema: ensure columns exist
      if (requestsSheet) {
        var headers = requestsSheet.getRange(1, 1, 1, requestsSheet.getLastColumn()).getValues()[0];
        var newCols = ['Attachment', 'AttachmentName', 'BudgetCapture'];
        var changed = false;
        newCols.forEach(function(col) {
          if (headers.indexOf(col) === -1) {
            requestsSheet.getRange(1, requestsSheet.getLastColumn() + 1).setValue(col);
            changed = true;
          }
        });
      }
    }
    
    var requestId = "REQ-" + Utilities.getUuid().substring(0, 8).toUpperCase();
    var docNumber = (metadata.type === 'PD' && metadata.docNumber) ? metadata.docNumber : generateDocNumber(metadata.type, metadata.department);
    var dateString = metadata.date || new Date().toISOString().substring(0, 10);
    
    // Total Nominal calculation
    var totalNominal = 0;
    items.forEach(function(item) {
      var itemTotal = (parseFloat(item.quantity) || 0) * (parseFloat(item.price) || 0);
      totalNominal += itemTotal;
      
      // Save item
      appendObjectToSheet('t_request_items', {
        ID: "ITEM-" + Utilities.getUuid().substring(0, 8).toUpperCase(),
        RequestId: requestId,
        COA: item.coa,
        PartNumber: item.partNumber || '',
        Description: item.description,
        CostElement: item.costElement || '',
        Quantity: parseFloat(item.quantity) || 0,
        UoM: item.uom,
        Price: parseFloat(item.price) || 0,
        Total: itemTotal
      });
    });
    
    // Determine the approval matrix steps
    var approvalSteps = getApprovalSteps(metadata.type, metadata.department, totalNominal);
    var initialApprover = approvalSteps[0] || 'Approved';
    var status = approvalSteps.length > 0 ? 'Pending' : 'Approved';
    
    // Initial signature JSON structure
    var userSig = '';
    try {
      var users = getSheetDataAsObjects('m_users');
      for (var u = 0; u < users.length; u++) {
        if (users[u].Fullname === metadata.requester) {
          userSig = users[u].Signature || '';
          break;
        }
      }
    } catch(e) {
      Logger.log("Error fetching user signature: " + e.toString());
    }
    
    var signatures = {
      user: { name: metadata.requester, role: 'User', date: new Date().toISOString(), status: 'SUBMITTED', signatureText: userSig ? userSig : metadata.requester }
    };
    
    if (metadata.type === 'PD') {
      signatures['projectManager'] = {
        name: metadata.customPm || 'Yohanes Sam',
        role: 'Project Manager / Operation Manager',
        date: '',
        status: 'PENDING',
        signatureText: ''
      };
      
      approvalSteps.forEach(function(step) {
        var k = step.toLowerCase().replace(/[^a-z]/g, '');
        if (step === 'Project Manager') k = 'deptHeadPm';
        if (step === 'Finance') k = 'financeSite';
        if (k !== 'projectmanager') {
          signatures[k] = { name: '', role: step === 'Project Manager' ? 'Dept Head / PM' : (step === 'Finance' ? 'Finance Site' : step), date: '', status: 'PENDING', signatureText: '' };
        }
      });
    } else {
      approvalSteps.forEach(function(step) {
        var k = step.toLowerCase().replace(/[^a-z]/g, '');
        if (k === 'headdepartment') k = 'supervisor';
        signatures[k] = { name: '', role: step, date: '', status: 'PENDING', signatureText: '' };
      });
    }
    
    // Save main request
    appendObjectToSheet('t_requests', {
      ID: requestId,
      Type: metadata.type,
      DocNumber: docNumber,
      Date: dateString,
      Department: metadata.department,
      Priority: metadata.priority,
      InventoryType: metadata.inventoryType || '',
      PurchaseCategory: metadata.purchaseCategory || '',
      Subject: metadata.subject,
      Requester: metadata.requester,
      TotalNominal: totalNominal,
      Status: status,
      CurrentApproverRole: initialApprover,
      CreatedAt: new Date().toISOString(),
      Signatures: JSON.stringify(signatures),
      UserFor: metadata.userFor || '',
      Attachment: metadata.attachment || '',
      AttachmentName: metadata.attachmentName || '',
      BudgetCapture: metadata.budgetCapture || ''
    });
    
    // Update active department budget actuals
    updateDepartmentBudget(metadata.department, totalNominal);
    
    // Log Activity
    logActivity(metadata.requester, "Create " + metadata.type, "Requests", docNumber);
    
    return { success: true, docNumber: docNumber, requestId: requestId };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// Generate sequential document numbers
function generateDocNumber(type, department) {
  var requests = getSheetDataAsObjects('t_requests');
  var count = requests.filter(function(r) { return r.Type === type; }).length + 1;
  var formattedCount = ("00000" + count).slice(-5);
  var year = new Date().getFullYear();
  return type + "-" + year + "-" + formattedCount;
}

function getSuggestedPDNumber(department) {
  try {
    return generateDocNumber('PD', department);
  } catch(e) {
    return "PD-" + new Date().getFullYear() + "-00001";
  }
}

// Get workflow approval steps from Matrix
function getApprovalSteps(docType, department, amount) {
  var matrix = getSheetDataAsObjects('t_approval_matrix');
  var matchedSteps = [];
  
  var matchedRows = matrix.filter(function(row) {
    var isDocTypeMatch = row.DocType === docType;
    var isDeptMatch = row.Department === 'ALL' || row.Department === department;
    var min = parseFloat(row.MinAmount) || 0;
    var max = parseFloat(row.MaxAmount) || Infinity;
    var isAmountMatch = amount >= min && amount <= max;
    return isDocTypeMatch && isDeptMatch && isAmountMatch;
  });
  
  matchedRows.sort(function(a, b) {
    if (a.Department !== 'ALL' && b.Department === 'ALL') return -1;
    if (a.Department === 'ALL' && b.Department !== 'ALL') return 1;
    return 0;
  });
  
  if (matchedRows.length > 0) {
    matchedSteps = matchedRows[0].Steps.split(',').map(function(s) { return s.trim(); });
  }
  
  // Default fallback route if not found in matrix
  if (matchedSteps.length === 0) {
    matchedSteps = docType === 'PD' ? ["Project Manager", "Finance"] : ["Supervisor", "Finance", "Project Manager"];
  }
  
  return matchedSteps;
}

// Deduct budget
function updateDepartmentBudget(dept, amount) {
  var budgets = getSheetDataAsObjects('t_budget');
  for (var i = 0; i < budgets.length; i++) {
    if (budgets[i].Department === dept) {
      var newActual = (parseFloat(budgets[i].ActualBudget) || 0) + amount;
      updateObjectInSheet('t_budget', budgets[i].ID, { ActualBudget: newActual });
      break;
    }
  }
}

/**
 * APPROVAL CENTER ENDPOINTS
 */
function isPMOnLeave() {
  try {
    var users = getSheetDataAsObjects('m_users');
    for (var i = 0; i < users.length; i++) {
      if (users[i].Role === 'Project Manager' && (users[i].Status === 'Cuti' || users[i].Status === 'On Leave')) {
        return true;
      }
    }
  } catch (e) {
    Logger.log("Error checking PM leave status: " + e.toString());
  }
  return false;
}

function getApprovalRequests(role) {
  var requests = getSheetDataAsObjects('t_requests');
  var isPmLeave = isPMOnLeave();
  return requests.filter(function(req) {
    if (req.Status !== 'Pending') return false;
    // KTT acts as a backup for Project Manager when PM is on leave
    if (role === 'KTT' && isPmLeave && req.CurrentApproverRole === 'Project Manager') {
      return true;
    }
    return req.CurrentApproverRole === role;
  }).map(function(req) {
    // Include signature parser
    var sigs = {};
    try {
      sigs = JSON.parse(req.Signatures);
    } catch(e) {}
    
    return {
      id: req.ID,
      type: req.Type,
      docNumber: req.DocNumber,
      date: Utilities.formatDate(new Date(req.Date), "GMT+8", "yyyy-MM-dd"),
      department: req.Department,
      priority: req.Priority,
      subject: req.Subject,
      requester: req.Requester,
      nominal: parseFloat(req.TotalNominal) || 0,
      signatures: sigs,
      userFor: req.UserFor
    };
  });
}

function processApproval(requestId, action, role, comment, userName) {
  try {
    var ss = getSpreadsheet();
    var requests = getSheetDataAsObjects('t_requests');
    var request = requests.filter(function(r) { return r.ID === requestId; })[0];
    
    if (!request) return { success: false, error: 'Document not found' };
    
    var isPmLeave = isPMOnLeave();
    var finalRole = role;
    if (role === 'KTT' && isPmLeave && request.CurrentApproverRole === 'Project Manager') {
      finalRole = 'Project Manager';
    }

    var signatures = JSON.parse(request.Signatures);
    var approvalSteps = getApprovalSteps(request.Type, request.Department, parseFloat(request.TotalNominal));
    
    // Dynamic key mapper
    function getSigKey(roleVal) {
      var mapping = {
        'Supervisor': 'supervisor',
        'Head Department': 'supervisor',
        'Finance': 'finance',
        'Finance Site': 'finance',
        'Project Manager': 'projectManager',
        'Cost Control': 'costControl',
        'GM/CFO': 'gmCfo'
      };
      return mapping[roleVal] || roleVal.toLowerCase().replace(/[^a-z]/g, '');
    }
    
    var key = getSigKey(finalRole);
    if (request.Type === 'PD') {
      if (finalRole === 'Project Manager' && (signatures.deptHeadPm !== undefined)) {
        key = 'deptHeadPm';
      } else if (finalRole === 'Finance' && (signatures.financeSite !== undefined)) {
        key = 'financeSite';
      }
    }
    if (!key) return { success: false, error: 'Invalid Approver Role' };
    
    if (action === 'APPROVE') {
      // Update signature details
      var userSig = '';
      try {
        var users = getSheetDataAsObjects('m_users');
        for (var u = 0; u < users.length; u++) {
          if (users[u].Fullname === userName) {
            userSig = users[u].Signature || '';
            break;
          }
        }
      } catch(e) {
        Logger.log("Error finding signature: " + e.toString());
      }
      
      signatures[key] = {
        name: userName,
        role: finalRole,
        date: new Date().toISOString(),
        status: 'APPROVED',
        signatureText: userSig ? userSig : "[e-Signed: " + userName + " | " + Utilities.formatDate(new Date(), "GMT+8", "yyyy-MM-dd HH:mm") + "]"
      };
      
      // Determine next approver
      var currentStepIndex = approvalSteps.indexOf(finalRole);
      var nextApprover = '';
      var nextStatus = 'Pending';
      
      if (currentStepIndex !== -1 && currentStepIndex < approvalSteps.length - 1) {
        nextApprover = approvalSteps[currentStepIndex + 1];
      } else {
        // Workflow complete
        nextStatus = 'Approved';
        nextApprover = 'None';
      }
      
      updateObjectInSheet('t_requests', requestId, {
        Status: nextStatus,
        CurrentApproverRole: nextApprover,
        Signatures: JSON.stringify(signatures)
      });
      
      logActivity(userName, "Approved at " + finalRole, "Approval", request.DocNumber);
      
      if (nextStatus === 'Approved') {
        saveApprovedPDFToDrive(requestId);
      }
      
      return { success: true, status: nextStatus };
      
    } else if (action === 'REJECT') {
      signatures[key] = {
        name: userName,
        role: finalRole,
        date: new Date().toISOString(),
        status: 'REJECTED',
        signatureText: "REJECTED"
      };
      
      // If rejected, document status goes directly to Rejected
      updateObjectInSheet('t_requests', requestId, {
        Status: 'Rejected',
        CurrentApproverRole: 'None',
        Signatures: JSON.stringify(signatures)
      });
      
      logActivity(userName, "Rejected at " + finalRole + " - " + comment, "Approval", request.DocNumber);
      return { success: true, status: 'Rejected' };
    }
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

function saveApprovedPDFToDrive(requestId) {
  try {
    SpreadsheetApp.flush();
    var pdfResult = generatePDF(requestId);
    if (!pdfResult || !pdfResult.success) {
      Logger.log("Failed to generate PDF for saving: " + (pdfResult ? pdfResult.error : "Unknown error"));
      return false;
    }
    
    var request = getRequestDetails(requestId);
    var dept = request.metadata.department || 'General';
    var fileName = pdfResult.fileName;
    
    // Extract base64 content
    var base64Data = pdfResult.pdfBase64.split(',')[1];
    var decodedBytes = Utilities.base64Decode(base64Data);
    var pdfBlob = Utilities.newBlob(decodedBytes, 'application/pdf', fileName);
    
    // Find or create the root folder: "Approved Documents"
    var parentFolderName = "Approved Documents";
    var parentFolder;
    var parentIterator = DriveApp.getFoldersByName(parentFolderName);
    if (parentIterator.hasNext()) {
      parentFolder = parentIterator.next();
    } else {
      parentFolder = DriveApp.createFolder(parentFolderName);
    }
    
    // Find or create the department subfolder
    var deptFolder;
    var deptIterator = parentFolder.getFoldersByName(dept);
    if (deptIterator.hasNext()) {
      deptFolder = deptIterator.next();
    } else {
      deptFolder = parentFolder.createFolder(dept);
    }
    
    // Save the file
    deptFolder.createFile(pdfBlob);
    Logger.log("Successfully saved approved PDF to Drive folder: " + parentFolderName + "/" + dept);
    return true;
  } catch (e) {
    Logger.log("Error saving PDF to Drive: " + e.toString());
    return false;
  }
}


/**
 * HISTORY & DOCUMENT VIEWER ENDPOINTS
 */
function getDocumentHistory(typeFilter, statusFilter, deptFilter, monthFilter, yearFilter) {
  var requests = getSheetDataAsObjects('t_requests');
  return requests.filter(function(req) {
    var matchesType = !typeFilter || req.Type === typeFilter;
    var matchesStatus = !statusFilter || req.Status.toUpperCase() === statusFilter.toUpperCase();
    var matchesDept = !deptFilter || req.Department === deptFilter;
    
    var reqDate = new Date(req.Date);
    var reqMonth = ('0' + (reqDate.getMonth() + 1)).slice(-2);
    var reqYear = String(reqDate.getFullYear());
    
    var matchesMonth = !monthFilter || reqMonth === monthFilter;
    var matchesYear = !yearFilter || reqYear === yearFilter;
    
    return matchesType && matchesStatus && matchesDept && matchesMonth && matchesYear;
  }).map(function(req) {
    var sigs = {};
    try {
      sigs = JSON.parse(req.Signatures);
    } catch(e) {}
    
    return {
      id: req.ID,
      type: req.Type,
      docNumber: req.DocNumber,
      date: Utilities.formatDate(new Date(req.Date), "GMT+8", "yyyy-MM-dd"),
      department: req.Department,
      priority: req.Priority,
      subject: req.Subject,
      requester: req.Requester,
      nominal: parseFloat(req.TotalNominal) || 0,
      status: req.Status,
      currentApprover: req.CurrentApproverRole,
      signatures: sigs,
      userFor: req.UserFor || '-'
    };
  });
}

function getRequestDetails(requestId) {
  var requests = getSheetDataAsObjects('t_requests');
  var request = requests.filter(function(r) { return r.ID === requestId; })[0];
  if (!request) return null;
  
  var items = getSheetDataAsObjects('t_request_items').filter(function(item) {
    return item.RequestId === requestId;
  });
  
  var sigs = {};
  try {
    sigs = JSON.parse(request.Signatures);
  } catch(e) {}
  
  var budgets = getSheetDataAsObjects('t_budget');
  var deptBudget = budgets.filter(function(b) {
    return b.Department === request.Department;
  })[0] || null;
  
  return {
    metadata: {
      id: request.ID,
      type: request.Type,
      docNumber: request.DocNumber,
      date: Utilities.formatDate(new Date(request.Date), "GMT+8", "yyyy-MM-dd"),
      department: request.Department,
      priority: request.Priority,
      inventoryType: request.InventoryType,
      purchaseCategory: request.PurchaseCategory,
      subject: request.Subject,
      requester: request.Requester,
      nominal: parseFloat(request.TotalNominal) || 0,
      status: request.Status,
      userFor: request.UserFor,
      attachment: request.Attachment || '',
      attachmentName: request.AttachmentName || '',
      budgetCapture: request.BudgetCapture || ''
    },
    items: items,
    signatures: sigs,
    budget: deptBudget
  };
}

/**
 * BUDGET CONTROL ENDPOINTS
 */
function getBudgetDashboard(deptFilter, projectFilter, yearFilter) {
  var budgets = getSheetDataAsObjects('t_budget');
  var filteredBudgets = budgets.filter(function(b) {
    var mDept = !deptFilter || deptFilter === 'all' || b.Department === deptFilter;
    var mProj = !projectFilter || projectFilter === 'all' || b.Project === projectFilter;
    var mYear = !yearFilter || yearFilter === 'all' || b.Year.toString() === yearFilter.toString();
    return mDept && mProj && mYear;
  });
  
  var totalBudget = 0;
  var budgetActual = 0;
  var deptGroups = {};
  
  filteredBudgets.forEach(function(b) {
    var ann = parseFloat(b.AnnualBudget) || 0;
    var act = parseFloat(b.ActualBudget) || 0;
    totalBudget += ann;
    budgetActual += act;
    
    // Grouping by dept
    var dept = b.Department;
    if (!deptGroups[dept]) {
      deptGroups[dept] = { annual: 0, actual: 0 };
    }
    deptGroups[dept].annual += ann;
    deptGroups[dept].actual += act;
  });
  
  var budgetAvailable = totalBudget - budgetActual;
  var utilizationPercent = totalBudget > 0 ? (budgetActual / totalBudget) * 100 : 0;
  
  var chartDeptLabels = Object.keys(deptGroups);
  var chartDeptAnnual = chartDeptLabels.map(function(l) { return deptGroups[l].annual; });
  var chartDeptActual = chartDeptLabels.map(function(l) { return deptGroups[l].actual; });
  
  return {
    kpis: {
      totalBudget: totalBudget,
      budgetActual: budgetActual,
      budgetAvailable: budgetAvailable,
      utilizationPercent: Math.round(utilizationPercent * 10) / 10
    },
    charts: {
      labels: chartDeptLabels,
      annual: chartDeptAnnual,
      actual: chartDeptActual
    }
  };
}

/**
 * BUDGET TAHUNAN CRUD ENDPOINTS
 */

/**
 * Mengembalikan seluruh data budget tahunan tanpa kolom Project
 */
function getBudgetTahunanList() {
  try {
    var budgets = getSheetDataAsObjects('t_budget');
    return {
      success: true,
      data: budgets.map(function(b) {
        return {
          id: b.ID,
          dept: b.Department || '',
          year: b.Year || '',
          annualBudget: parseFloat(b.AnnualBudget) || 0,
          actualBudget: parseFloat(b.ActualBudget) || 0
        };
      })
    };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * Simpan data budget (tambah jika tidak ada id, update jika ada id)
 */
function saveBudgetRecord(payload) {
  try {
    if (!payload.dept || !payload.year) {
      return { success: false, error: 'Department dan Year wajib diisi' };
    }
    if (payload.id) {
      // Update existing
      var updated = updateObjectInSheet('t_budget', payload.id, {
        Department: payload.dept,
        Year:        payload.year,
        AnnualBudget: payload.annualBudget || 0,
        ActualBudget: payload.actualBudget || 0
      });
      return { success: updated };
    } else {
      // Tambah baru
      var ss    = getSpreadsheet();
      var sheet = ss.getSheetByName('t_budget');
      if (!sheet) return { success: false, error: 'Sheet t_budget tidak ditemukan' };
      var lastRow = sheet.getLastRow();
      var newId   = 'BDG-' + lastRow;
      appendObjectToSheet('t_budget', {
        ID:           newId,
        Department:   payload.dept,
        Project:      '',
        Year:         payload.year,
        AnnualBudget: payload.annualBudget || 0,
        ActualBudget: payload.actualBudget || 0
      });
      return { success: true, id: newId };
    }
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * Hapus satu record budget berdasarkan ID
 */
function deleteBudgetRecord(id) {
  return deleteMasterRecord('t_budget', id);
}

/**
 * Import batch data budget dari array rows (hasil parse CSV di frontend)
 * rows: [{ dept, year, annualBudget, actualBudget }, ...]
 */
function importBudgetData(rows) {
  try {
    if (!rows || !rows.length) return { success: false, error: 'Tidak ada data untuk diimport' };
    var ss    = getSpreadsheet();
    var sheet = ss.getSheetByName('t_budget');
    if (!sheet) return { success: false, error: 'Sheet t_budget tidak ditemukan' };
    var lastRow = sheet.getLastRow();
    var count   = 0;
    rows.forEach(function(row) {
      if (!row.dept || !row.year) return;
      lastRow++;
      appendObjectToSheet('t_budget', {
        ID:           'BDG-IMP-' + lastRow,
        Department:   row.dept,
        Project:      '',
        Year:         row.year,
        AnnualBudget: parseFloat(row.annualBudget) || 0,
        ActualBudget: parseFloat(row.actualBudget) || 0
      });
      count++;
    });
    return { success: true, count: count };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * AUDIT TRAIL LOGGING
 */
function logActivity(user, activity, module, docNumber) {
  try {
    appendObjectToSheet('t_audit_log', {
      ID: "LOG-" + Utilities.getUuid().substring(0, 8).toUpperCase(),
      Timestamp: new Date().toISOString(),
      User: user,
      Activity: activity,
      Module: module,
      DocNumber: docNumber || '-',
      IPAddress: '192.168.10.' + Math.floor(Math.random() * 254 + 1) // Mock IP for intranet look
    });
  } catch(e) {
    Logger.log("Logging failed: " + e.toString());
  }
}

function getAuditTrail() {
  return getSheetDataAsObjects('t_audit_log').sort(function(a,b) {
    return new Date(b.Timestamp) - new Date(a.Timestamp);
  }).map(function(log) {
    return {
      timestamp: Utilities.formatDate(new Date(log.Timestamp), "GMT+8", "yyyy-MM-dd HH:mm"),
      user: log.User,
      activity: log.Activity,
      module: log.Module,
      docNumber: log.DocNumber,
      ipAddress: log.IPAddress
    };
  });
}

/**
 * MASTER DATA API FOR TABLES
 */
function getDropdownData() {
  try {
    if (!useGitHub()) {
      var ss = getSpreadsheet();
      var matrixSheet = ss.getSheetByName('t_approval_matrix');
      if (matrixSheet) {
        var headers = matrixSheet.getRange(1, 1, 1, matrixSheet.getLastColumn()).getValues()[0];
        if (headers.indexOf('Department') === -1) {
          var docTypeIndex = headers.indexOf('DocType');
          if (docTypeIndex !== -1) {
            matrixSheet.insertColumnAfter(docTypeIndex + 1);
            matrixSheet.getRange(1, docTypeIndex + 2).setValue('Department');
            var lastRow = matrixSheet.getLastRow();
            if (lastRow > 1) {
              var range = matrixSheet.getRange(2, docTypeIndex + 2, lastRow - 1, 1);
              var values = [];
              for (var i = 0; i < lastRow - 1; i++) {
                values.push(['ALL']);
              }
              range.setValues(values);
            }
          }
        }
      }
      
      // Self-healing check for m_users status column
      var userSheet = ss.getSheetByName('m_users');
      if (userSheet) {
        var userHeaders = userSheet.getRange(1, 1, 1, userSheet.getLastColumn()).getValues()[0];
        if (userHeaders.indexOf('Status') === -1) {
          userSheet.insertColumnAfter(userHeaders.length);
          userSheet.getRange(1, userHeaders.length + 1).setValue('Status');
          var lastRowUser = userSheet.getLastRow();
          if (lastRowUser > 1) {
            var rangeUser = userSheet.getRange(2, userHeaders.length + 1, lastRowUser - 1, 1);
            var valuesUser = [];
            for (var i = 0; i < lastRowUser - 1; i++) {
              valuesUser.push(['Active']);
            }
            rangeUser.setValues(valuesUser);
          }
        }
      }
    }
  } catch(e) {
    Logger.log("Auto migrate schema failed: " + e.toString());
  }

  return {
    departments: getSheetDataAsObjects('m_departments'),
    projects: getSheetDataAsObjects('m_projects'),
    coas: getSheetDataAsObjects('m_coas'),
    costElements: getSheetDataAsObjects('m_cost_elements'),
    users: getSheetDataAsObjects('m_users'),
    matrix: getSheetDataAsObjects('t_approval_matrix')
  };
}

function createMasterRecord(sheetName, prefix, payload) {
  try {
    if (useGitHub()) {
      var existingRecords = getGitHubData(sheetName);
      var count = existingRecords.length + 1;
      var existingIds = existingRecords.map(function(row) { 
        var rawId = row.ID || row.id || '';
        return rawId.toString(); 
      });
      var idValue = prefix + '-' + count;
      while (existingIds.indexOf(prefix + '-' + count) !== -1) {
        count++;
      }
      idValue = prefix + '-' + count;
      payload.ID = idValue;
      appendObjectToSheet(sheetName, payload);
      return { success: true, record: payload };
    }
    
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) return { success: false, error: 'Sheet not found: ' + sheetName };
    
    var lastRow = sheet.getLastRow();
    var idValue = prefix + '-' + lastRow;
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var idIndex = headers.indexOf('ID');
    if (idIndex === -1) idIndex = headers.indexOf('id');
    
    if (idIndex !== -1) {
      var existingIds = data.map(function(row) { return row[idIndex].toString(); });
      var count = lastRow;
      while (existingIds.indexOf(prefix + '-' + count) !== -1) {
        count++;
      }
      idValue = prefix + '-' + count;
    }
    
    payload.ID = idValue;
    appendObjectToSheet(sheetName, payload);
    return { success: true, record: payload };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function updateMasterRecord(sheetName, idValue, payload) {
  try {
    var success = updateObjectInSheet(sheetName, idValue, payload);
    return { success: success };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function deleteMasterRecord(sheetName, idValue) {
  try {
    if (useGitHub()) {
      var success = deleteGitHubRecord(sheetName, idValue);
      return { success: success, error: success ? null : 'Record delete failed' };
    }
    
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) return { success: false, error: 'Sheet not found: ' + sheetName };
    
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var idIndex = headers.indexOf('ID');
    if (idIndex === -1) idIndex = headers.indexOf('id');
    if (idIndex === -1) return { success: false, error: 'ID column not found' };
    
    for (var i = 1; i < data.length; i++) {
      if (data[i][idIndex].toString() === idValue.toString()) {
        sheet.deleteRow(i + 1);
        return { success: true };
      }
    }
    return { success: false, error: 'Record not found' };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * CUSTOM AUTHENTICATION & LOGIN
 */
function loginUser(username, password) {
  try {
    // Self-healing database check: run syncUsers on login attempt to update usernames and passwords dynamically
    try {
      if (!useGitHub()) {
        var ss = getSpreadsheet();
        if (ss) {
          syncUsers(ss);
        }
      }
    } catch(e_sync) {
      console.error("Auto sync users on login failed: " + e_sync.toString());
    }

    var users = getSheetDataAsObjects('m_users');
    var foundUser = null;
    var inputUserNorm = username ? username.toString().toLowerCase().trim().replace(/\s+/g, '.') : '';
    for (var i = 0; i < users.length; i++) {
      var u = users[i];
      var rawUsername = u.Username || u.username || '';
      var dbUserNorm = rawUsername.toString().toLowerCase().trim().replace(/\s+/g, '.');
      if (dbUserNorm && dbUserNorm === inputUserNorm) {
        var rawDbPass = u.Password || u.password || '';
        var dbPass = rawDbPass.toString();
        var inputPass = password ? password.toString() : '';
        if (dbPass === inputPass || 
            ((dbPass === 'bis2026' || dbPass === 'password123') && inputPass === 'BARAindah@2026')) {
          
          if ((dbPass === 'bis2026' || dbPass === 'password123') && inputPass === 'BARAindah@2026') {
            try {
              if (useGitHub()) {
                updateGitHubRecord('m_users', u.ID || u.id, { password: 'BARAindah@2026' });
              } else {
                var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('m_users');
                var data = sheet.getDataRange().getValues();
                for (var r = 1; r < data.length; r++) {
                  var dbRowUser = data[r][1] || '';
                  var dbRowUserNorm = dbRowUser.toString().toLowerCase().trim().replace(/\s+/g, '.');
                  if (dbRowUserNorm === inputUserNorm) {
                    sheet.getRange(r + 1, 6).setValue('BARAindah@2026');
                    break;
                  }
                }
              }
            } catch(e_mig) {
              console.error('Password auto-migration failed: ' + e_mig.toString());
            }
          }
          
          foundUser = {
            username: u.Username || u.username || '',
            fullname: u.Fullname || u.fullname || '',
            role: u.Role || u.role || '',
            department: u.Department || u.department || '',
            signature: u.Signature || u.signature || ''
          };
          break;
        } else {
          return { success: false, error: 'Password salah. Silakan coba lagi.' };
        }
      }
    }
    
    if (foundUser) {
      logActivity(foundUser.fullname, "User Login Success", "Authentication", "-");
      return { success: true, user: foundUser };
    } else {
      return { success: false, error: 'Username tidak terdaftar.' };
    }
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * PROFILE & SIGNATURE SETTINGS
 */
function saveUserSignature(username, signatureBase64) {
  try {
    if (useGitHub()) {
      var success = updateGitHubRecord('m_users', username, { signature: signatureBase64 }, 'username');
      if (success) {
        var users = getGitHubData('m_users');
        var fullName = username;
        for (var i = 0; i < users.length; i++) {
          var rawUser = users[i].Username || users[i].username || '';
          if (rawUser.toLowerCase() === username.toLowerCase()) {
            fullName = users[i].Fullname || users[i].fullname || username;
            break;
          }
        }
        logActivity(fullName, "Updated Custom Signature Profile", "Profile", "-");
      }
      return { success: success, error: success ? null : 'User not found' };
    }
    
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('m_users');
    if (!sheet) return { success: false, error: 'User sheet not found' };
    
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var userIndex = headers.indexOf('Username');
    var sigIndex = headers.indexOf('Signature');
    var nameIndex = headers.indexOf('Fullname');
    
    if (userIndex === -1 || sigIndex === -1) return { success: false, error: 'Database schema mismatch' };
    
    var updated = false;
    for (var i = 1; i < data.length; i++) {
      if (data[i][userIndex].toString().toLowerCase() === username.toString().toLowerCase()) {
        sheet.getRange(i + 1, sigIndex + 1).setValue(signatureBase64);
        updated = true;
        
        var fullName = data[i][nameIndex];
        logActivity(fullName, "Updated Custom Signature Profile", "Profile", "-");
        break;
      }
    }
    return { success: updated, error: updated ? null : 'User not found' };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

/**
 * HTML-TO-PDF GENERATION
 */
function generatePDF(requestId) {
  try {
    var request = getRequestDetails(requestId);
    if (!request) return { success: false, error: 'Document not found' };
    
    var doc = {
      type: request.metadata.type,
      docNo: request.metadata.docNumber,
      date: request.metadata.date,
      dept: request.metadata.department,
      priority: request.metadata.priority,
      inventoryType: request.metadata.inventoryType,
      subj: request.metadata.subject,
      reqName: request.metadata.requester,
      nominal: request.metadata.nominal,
      attachment: request.metadata.attachment,
      attachmentName: request.metadata.attachmentName,
      items: request.items,
      sigs: {}
    };
    if (typeof request.signatures === 'string') {
      try { doc.sigs = JSON.parse(request.signatures); } catch(e) {}
    } else if (request.signatures && typeof request.signatures === 'object') {
      doc.sigs = request.signatures;
    }
    
    var htmlContent = buildPaperHTMLServer(doc);
    
    var blob = Utilities.newBlob(htmlContent, 'text/html', 'document.html');
    var pdfBlob = blob.getAs('application/pdf');
    pdfBlob.setName(request.metadata.docNumber.replace(/\//g, '_') + '.pdf');
    var base64 = Utilities.base64Encode(pdfBlob.getBytes());
    
    return {
      success: true,
      pdfBase64: 'data:application/pdf;base64,' + base64,
      fileName: request.metadata.docNumber.replace(/\//g, '_') + '.pdf'
    };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

function buildPaperHTMLServer(doc) {
  var usersList = getSheetDataAsObjects("m_users");
  const sigs = doc.sigs;
  
  const formatDate = function(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return Utilities.formatDate(d, 'GMT+8', 'dd MMM yyyy');
  };
  
  const formatCurrency = function(num) {
    return "Rp " + new Intl.NumberFormat('id-ID').format(num || 0);
  };
  
  const terbilangText = terbilang(doc.nominal);
  
  const getSignerName = (role, dept, defaultName) => {
    const u = usersList.filter(function(u) { return u.Role === role && (dept ? u.Department === dept : true); })[0];
    return u ? u.name : defaultName;
  };

  const getSigBoxData = function(sigObj, roleKey) {
    let sigContent = '';
    let name = (sigObj && sigObj.name) ? sigObj.name : '-';
    let date = '';
    let statusClass = 'pend';
    let statusText = 'PENDING';
    
    if (sigObj && (sigObj.status === 'SUBMITTED' || sigObj.status === 'APPROVED')) {
      date = formatDate(sigObj.date);
      statusClass = 'app';
      statusText = sigObj.status === 'SUBMITTED' ? 'SUBMITTED' : 'APPROVED';
      if (sigObj.signatureText && sigObj.signatureText.indexOf('data:image') === 0) {
        sigContent = '<img src="' + sigObj.signatureText + '" style="max-height:40px; max-width:110px; object-fit:contain;" />';
      } else if (sigObj.signature && sigObj.signature.indexOf('data:image') === 0) {
        sigContent = '<img src="' + sigObj.signature + '" style="max-height:40px; max-width:110px; object-fit:contain;" />';
      } else {
        sigContent = genSVGSig(sigObj.name).replace('class="esig"','style="width:110px;height:38px"').replace('stroke:var(--cy)','stroke:#1565c0');
      }
    } else if (sigObj && sigObj.status === 'REJECTED') {
      date = formatDate(sigObj.date);
      statusClass = 'rej';
      statusText = 'REJECTED';
      sigContent = '<span style="color:#ff1744; font-weight:bold; font-size:9px;">REJECTED</span>';
    } else if (roleKey) {
      // Fallback signature image lookup from DB.users for visual match
      const signerName = name !== '-' ? name : getSignerName(roleKey, '', '');
      const dbUser = usersList.filter(function(u) { return u.Fullname === signerName; })[0];
      if (dbUser && dbUser.Signature && dbUser.Signature.indexOf('data:image') === 0) {
        sigContent = '<img src="' + dbUser.Signature + '" style="max-height:40px; max-width:110px; object-fit:contain; opacity:0.9;" />';
      }
    }
    
    return {
      content: sigContent,
      name: name,
      date: date,
      statusText: statusText,
      statusClass: statusClass
    };
  };

  if (doc.type === 'PR') {
    // ==========================================
    // PURCHASE REQUEST PDF TEMPLATE
    // ==========================================
    let itemsRowsHTML = '';
    doc.items.forEach(function(item, idx) {
      itemsRowsHTML += '<tr>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center;">' + (idx + 1) + '</td>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center; font-weight:bold;">' + (item.coa || item.COA || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center;">' + (item.partNo || item.PartNumber || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:5px;">' + (item.desc || item.Description || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center;">' + (item.costElement || item.CostElement || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center; font-weight:bold;">' + (item.qty || item.Quantity || 0) + '</td>' +
        '<td style="border:1px solid #111; padding:5px; text-align:center;">' + (item.uom || item.UoM || 'Unit') + '</td>' +
        '</tr>';
    });
    
    const isStock = doc.inventoryType === 'STOCK' ? '&#10003;' : '&nbsp;&nbsp;';
    const isNonStock = doc.inventoryType === 'NON STOCK' || !doc.inventoryType ? '&#10003;' : '&nbsp;&nbsp;';
    
    const sigUser = getSigBoxData(sigs.user, 'user');
    const sigHead = getSigBoxData(sigs.supervisor || sigs.headDept, 'supervisor');
    const sigFin = getSigBoxData(sigs.finance, 'finance');
    const sigPm = getSigBoxData(sigs.projectManager, 'projectManager');
    
    const getPRSupervisor = (dept) => {
      const mapping = {
        'HRGA': 'Mona Asrani',
        'SHE': 'Rosmina Rabbang',
        'External': 'Erwin Eka',
        'QAQC': 'Yusril',
        'Engineering': 'Roymon Biang',
        'Plant': 'Muh. Said',
        'Eksplorasi': 'Laode Rusman',
        'Exploration': 'Laode Rusman'
      };
      return mapping[dept] || '';
    };

    if (sigUser.name === '-') sigUser.name = doc.requester || (session ? session.name : 'Mona Asrani');
    if (sigHead.name === '-') sigHead.name = getPRSupervisor(doc.dept || 'HRGA') || getSignerName('Supervisor', doc.dept || 'HRGA', 'Mona Asrani');
    if (sigFin.name === '-') sigFin.name = 'Putri Amalia';
    if (sigPm.name === '-') sigPm.name = 'Rosalia Natalia';
    
    return `
      <style>
        @media print {
          @page { size: A4 portrait; margin: 0; }
          body { margin: 0; padding: 8mm; }
        }
        .page-break-preview {
          page-break-before: always;
        }
        @media screen {
          .page-break-preview {
            border-top: 2px dashed #cbd5e1;
            margin-top: 30px !important;
            padding-top: 15px !important;
            position: relative;
            page-break-before: auto;
          }
          .page-break-preview::before {
            content: "HALAMAN BARU / NEW PAGE (LAMPIRAN)";
            position: absolute;
            top: -10px;
            left: 20px;
            background: #fff;
            padding: 0 8px;
            font-size: 8px;
            color: #64748b;
            font-weight: bold;
            letter-spacing: 0.5px;
          }
        }
      </style>
      <div style="font-family:Arial,sans-serif; background:#fff; color:#111; padding:15px; font-size:9.5px; border:1.5px solid #111; box-sizing:border-box; max-width:800px; margin:0 auto;">
        <!-- Header -->
        <table style="width:100%; border-collapse:collapse; border:1.5px solid #111; margin-bottom:12px; background-color:#e0e0e0;">
          <tr>
            <td style="width:15%; text-align:center; border:1.5px solid #111; padding:6px; vertical-align:middle;">
              <img src="' + (doc.type === 'PD' ? 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/6xeJSlAAAQAAAAEAABd/anVtYgAAAB5qdW1kYzJwYQARABCAAACqADibcQNjMnBhAAAAF1lqdW1iAAAAR2p1bWRjMm1hABEAEIAAAKoAOJtxA3VybjpjMnBhOjQwZDU4MTIwLThiZDUtNjU3YS00YzBkLTQzY2M2Yjc2ODBkOQAAABMCanVtYgAAAChqdW1kYzJjcwARABCAAACqADibcQNjMnBhLnNpZ25hdHVyZQAAABLSY2JvctKEWQYrogEmGCGCWQM/MIIDOzCCAsCgAwIBAgIUAJ6vFWKBqUkCFltI/1ipbSSYHs4wCgYIKoZIzj0EAwMwUTELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxLTArBgNVBAMMJEdvb2dsZSBDMlBBIE1lZGlhIFNlcnZpY2VzIDFQIElDQSBHMzAeFw0yNjAyMTcxNTE3MTJaFw0yNzAyMTIxNTE3MTFaMGsxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpHb29nbGUgTExDMRwwGgYDVQQLExNHb29nbGUgU3lzdGVtIDYwMDMyMSkwJwYDVQQDEyBHb29nbGUgTWVkaWEgUHJvY2Vzc2luZyBTZXJ2aWNlczBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABLBjir7O78duFgwA85LMipPVJpwNGfPRe9uLhP2QbYYvWYLwkqIuwXGpMdIYJ5OtG6kKVtfi3xS50maSO0eJywCjggFaMIIBVjAOBgNVHQ8BAf8EBAMCBsAwHwYDVR0lBBgwFgYIKwYBBQUHAwQGCisGAQQBg+heAgEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQUkG/QOXwhnfJG44eVEH4Wr2aQ5O4wHwYDVR0jBBgwFoAU2nvhvbQsioXgENZrmsdK8frf9jcwbAYIKwYBBQUHAQEEYDBeMCYGCCsGAQUFBzABhhpodHRwOi8vYzJwYS1vY3NwLnBraS5nb29nLzA0BggrBgEFBQcwAoYoaHR0cDovL3BraS5nb29nL2MycGEvbWVkaWEtMXAtaWNhLWczLmNydDAXBgNVHSAEEDAOMAwGCisGAQQBg+heAQEwGQYJKwYBBAGD6F4DBAwGCisGAQQBg+heAwowMwYJKwYBBAGD6F4EBCYMJDAxOWMzNGQzLTczM2YtN2E0Ny1iOTE3LTUwZGQzOGY0MWVjZTAKBggqhkjOPQQDAwNpADBmAjEAk41aMTcCgSsA+aAKV0GYPGVAUzMSnab02y1JhvXYZraq9fLZxPw8G8NcdJnCEndyAjEAvrBQu9UmLza4dENTmz+o32xGSkRJXRQgjFfWVLanodD/bGcbObPJxEvCR0JMirQCWQLgMIIC3DCCAmOgAwIBAgIUQfqlIUd2IVjaf5ss/439Fgke7j4wCgYIKoZIzj0EAwMwQzELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxHzAdBgNVBAMMFkdvb2dsZSBDMlBBIFJvb3QgQ0EgRzMwHhcNMjUwNTA4MjIzNjI2WhcNMzAwNTA4MjIzNjI2WjBRMQswCQYDVQQGEwJVUzETMBEGA1UECgwKR29vZ2xlIExMQzEtMCsGA1UEAwwkR29vZ2xlIEMyUEEgTWVkaWEgU2VydmljZXMgMVAgSUNBIEczMHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEuCPlUxSiltqnB2lx2ES7FK+TVZWmAxRzzDjTzKZ8umoqyvCqSLOkZBrOieaLqrp+rnzt0EADWWH3X62NqzEXRewW6rb/lS7VXkVCM02gC0ZgJW7+PCsZgLoUBUQ+nkN5o4IBCDCCAQQwFwYDVR0gBBAwDjAMBgorBgEEAYPoXgEBMA4GA1UdDwEB/wQEAwIBBjAfBgNVHSUEGDAWBggrBgEFBQcDBAYKKwYBBAGD6F4CATASBgNVHRMBAf8ECDAGAQH/AgEAMGQGCCsGAQUFBwEBBFgwVjAsBggrBgEFBQcwAoYgaHR0cDovL3BraS5nb29nL2MycGEvcm9vdC1nMy5jcnQwJgYIKwYBBQUHMAGGGmh0dHA6Ly9jMnBhLW9jc3AucGtpLmdvb2cvMB8GA1UdIwQYMBaAFJxc2IlTQ+da1YHbA94ZfwQqKi2qMB0GA1UdDgQWBBTae+G9tCyKheAQ1muax0rx+t/2NzAKBggqhkjOPQQDAwNnADBkAjACxtEE3NW13bwN1u/51ericNF6rkEhYVESDO6Jqb5cX37Hwg0X9S2rH+vXaoFZIHsCMC03wCKKomDHgqV47UtyyHpZlo5IZACW72Xdc4gipdWMEmhvPk88dvxbYtn+LVd9zKRnc2lnVHN0MqFpdHN0VG9rZW5zgaFjdmFsWQfeMIIH2gYJKoZIhvcNAQcCoIIHyzCCB8cCAQMxDTALBglghkgBZQMEAgEwgY4GCyqGSIb3DQEJEAEEoH8EfTB7AgEBBgorBgEEAdZ5AgoBMDEwDQYJYIZIAWUDBAIBBQAEIEhQYq0zTF6jvlNL1BaaeqnT+1ZhlVNzmzTVNBzr2v9xAhR2SV9Bxvu8ms7+MXALqk/0FkoYZhgPMjAyNjA2MDcwNTUyNDBaMAYCAQGAAQoCCGPganbaJvncoIIFoDCCAskwggJPoAMCAQICFACy1dUfIWdeE7xBMKqIvDvk4LoeMAoGCCqGSM49BAMDMFIxCzAJBgNVBAYTAlVTMRMwEQYDVQQKDApHb29nbGUgTExDMS4wLAYDVQQDDCVHb29nbGUgQzJQQSBDb3JlIFRpbWUtU3RhbXBpbmcgSUNBIEczMB4XDTI1MDkwODEzNDg1NVoXDTMxMDkwOTAxNDg1NFowUzELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkdvb2dsZSBMTEMxLzAtBgNVBAMTJkdvb2dsZSBDb3JlIFRpbWUgU3RhbXBpbmcgQXV0aG9yaXR5IFQ5MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1Af1CI0WrI5ooiRXmqW7/7HDsr8E+movv/TM6OFbSNnzLLEj75bHe1V5sEMiSjxpvAHs5EDTVcU2rlekCiU8s6OCAQAwgf0wDgYDVR0PAQH/BAQDAgbAMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFDuxPDki1qaJ6sBTqbUrLieAWMcJMB8GA1UdIwQYMBaAFN5Vl4xgdDsD4mq0RAZll2HK5fiOMGwGCCsGAQUFBwEBBGAwXjAmBggrBgEFBQcwAYYaaHR0cDovL2MycGEtb2NzcC5wa2kuZ29vZy8wNAYIKwYBBQUHMAKGKGh0dHA6Ly9wa2kuZ29vZy9jMnBhL2NvcmUtdHNhLWljYS1nMy5jcnQwFwYDVR0gBBAwDjAMBgorBgEEAYPoXgEBMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMAoGCCqGSM49BAMDA2gAMGUCMQCzqa3oVRmfXsvBWKjk8A9tf1vOqqVZUztTnC0an4pl25XNL3dykNrSeKB0brBO/Q8CMDrMQoWii1c1EeHx6Gr/G0YD9vgvDzVMagds2GswnGrsKD2ur3Mk3j8jgNkAN2zgXjCCAs8wggJWoAMCAQICFEUAg25yEwLFZKSeZDN2+o8Jt2T0MAoGCCqGSM49BAMDMEMxCzAJBgNVBAYTAlVTMRMwEQYDVQQKDApHb29nbGUgTExDMR8wHQYDVQQDDBZHb29nbGUgQzJQQSBSb290IENBIEczMB4XDTI1MDUwODIyMzYyNloXDTQwMDUwODIyMzYyNlowUjELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxLjAsBgNVBAMMJUdvb2dsZSBDMlBBIENvcmUgVGltZS1TdGFtcGluZyBJQ0EgRzMwdjAQBgcqhkjOPQIBBgUrgQQAIgNiAASjfffxvQgqH0VZJeBS+akg3/7bLo9FIdhPCtXNA3HdZyosWW7AnCQyciJ5uQKRX7mmykefp8U0cxN+XsUlROkxIo401bgW/hrBqzPqxiEsI0//AeTgwX/wOGvFcq0lSwqjgfswgfgwFwYDVR0gBBAwDjAMBgorBgEEAYPoXgEBMA4GA1UdDwEB/wQEAwIBBjATBgNVHSUEDDAKBggrBgEFBQcDCDASBgNVHRMBAf8ECDAGAQH/AgEAMGQGCCsGAQUFBwEBBFgwVjAsBggrBgEFBQcwAoYgaHR0cDovL3BraS5nb29nL2MycGEvcm9vdC1nMy5jcnQwJgYIKwYBBQUHMAGGGmh0dHA6Ly9jMnBhLW9jc3AucGtpLmdvb2cvMB8GA1UdIwQYMBaAFJxc2IlTQ+da1YHbA94ZfwQqKi2qMB0GA1UdDgQWBBTeVZeMYHQ7A+JqtEQGZZdhyuX4jjAKBggqhkjOPQQDAwNnADBkAjBBxgaNHUp8AZXW5U2BdHxgXcxwQltKEYRj/6WH3JQk2IHMqPlHUeZ2Loh2aShYUHECMHALpi3THpvF6RCbABHnU/TtJaPpLGrn8GyfdwVYeRxt4d+68Yo/JxNOuLoaUj4jLTGCAXwwggF4AgEBMGowUjELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxLjAsBgNVBAMMJUdvb2dsZSBDMlBBIENvcmUgVGltZS1TdGFtcGluZyBJQ0EgRzMCFACy1dUfIWdeE7xBMKqIvDvk4LoeMAsGCWCGSAFlAwQCAaCBpDAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDYwNzA1NTI0MFowLwYJKoZIhvcNAQkEMSIEIKNk/t/cNcnkaf7Jtnxin5QY1mSOXpG/p9WlUqDQy+1cMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIIKlq0QAjdVtBAAMFHzONP76bjuGtsCEQB7qJGY9f6bDMAoGCCqGSM49BAMCBEcwRQIgBv+8cWVpfVCYeQ/a4DZ73+aI3w83Nf/9a36S36KEYTwCIQCclXnnLBv9eWB+XKemJV3eXZiCJGgxm2gnyz3CmIj7eWVyVmFsc6Fob2NzcFZhbHOCWQP0MIID8AoBAKCCA+kwggPlBgkrBgEFBQcwAQEEggPWMIID0jCB7KFCMEAxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpHb29nbGUgTExDMRwwGgYDVQQDExNDMlBBIE9DU1AgUmVzcG9uZGVyGA8yMDI2MDYwNjE1MTQwMFowgZQwgZEwaTANBglghkgBZQMEAgEFAAQgssyQyamfMvBXXlCCvNODuNEJ0MZY4HuaHcboqhUW7SoEIJwa/V8+flyCR5a1dPJTP+OCaW+uDbdG9nAQsZU5sds9AhQAnq8VYoGpSQIWW0j/WKltJJgezoAAGA8yMDI2MDYwNjE1MTQ0MlqgERgPMjAyNjA2MTMxNTE0NDJaMAoGCCqGSM49BAMCA0gAMEUCICaUFlNSWqvlfSgwA0dUFvYEW96OsHu+DbWmJpiAY2LhAiEA1pb+sOkj3O/Ne6Dk5kn+EK1S9pyPrSV9qd2b5600/RKgggKJMIIChTCCAoEwggIHoAMCAQICFAD7uDwoHlCGP2W2GdKp20+VesvfMAoGCCqGSM49BAMDMFExCzAJBgNVBAYTAlVTMRMwEQYDVQQKDApHb29nbGUgTExDMS0wKwYDVQQDDCRHb29nbGUgQzJQQSBNZWRpYSBTZXJ2aWNlcyAxUCBJQ0EgRzMwHhcNMjYwNjA0MjEzMzE2WhcNMjYwNzA0MjEzMzE1WjBAMQswCQYDVQQGEwJVUzETMBEGA1UEChMKR29vZ2xlIExMQzEcMBoGA1UEAxMTQzJQQSBPQ1NQIFJlc3BvbmRlcjBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABNP84g+kzATtakc2xC9a8n4KkjgN74kd5AKoMgOE4M67obL3EFwY/2LSafGRuMesc35dcFygWJEjQ16qmuhAno6jgc0wgcowDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMJMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFPFQGNRbsFBWO8/TeED0/eMCnpP2MB8GA1UdIwQYMBaAFNp74b20LIqF4BDWa5rHSvH63/Y3MEQGCCsGAQUFBwEBBDgwNjA0BggrBgEFBQcwAoYoaHR0cDovL3BraS5nb29nL2MycGEvbWVkaWEtMXAtaWNhLWczLmNydDAPBgkrBgEFBQcwAQUEAgUAMAoGCCqGSM49BAMDA2gAMGUCMDKXitFcvcy13EHw4+ob+1FcFEE+k5p6FxsJr4np5iObod4nSaDVA/19tSDaK05yrgIxAKFC1oKPHislx7tmKhcF/xRzIpM5VKUh/r3Q7VsJWPf3hhdPV2vaF4B9PlaPSce5jUBjcGFkWEYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZHBhZDJBAPZYQFnmWJn65O0CMT2aAia6shp2uuqbh1WIahg8gnHD+f5yWsM5rC8dsuKFQ73bmYmcpK8eEP3wy9rddbPMiD3U4mMAAAG3anVtYgAAACdqdW1kYzJjbAARABCAAACqADibcQNjMnBhLmNsYWltLnYyAAAAAYhjYm9ypWppbnN0YW5jZUlEeCRmZTc5ODNlMi05N2U1LTFjOWMtMzgyZC00ZjA0YjZlMDA0MzF0Y2xhaW1fZ2VuZXJhdG9yX2luZm+iZG5hbWV4Ikdvb2dsZSBDMlBBIENvcmUgR2VuZXJhdG9yIExpYnJhcnlndmVyc2lvbnM5Mjc1ODI4OTA6OTI3NTgyODkwcmNyZWF0ZWRfYXNzZXJ0aW9uc4KiY3VybHgqc2VsZiNqdW1iZj1jMnBhLmFzc2VydGlvbnMvYzJwYS5hY3Rpb25zLnYyZGhhc2hYIGgiUSvLc5QdCQvuwFPp+rbQOlwIq5u0SQyj9VpE0Oi5omN1cmx4KXNlbGYjanVtYmY9YzJwYS5hc3NlcnRpb25zL2MycGEuaGFzaC5kYXRhZGhhc2hYIB2treRnXvAb2nZuf4qjezKTxSBbGu1+PHRzfGobnbRuaXNpZ25hdHVyZXgZc2VsZiNqdW1iZj1jMnBhLnNpZ25hdHVyZWNhbGdmc2hhMjU2AAACUWp1bWIAAAApanVtZGMyYXMAEQAQgAAAqgA4m3EDYzJwYS5hc3NlcnRpb25zAAAAAJxqdW1iAAAAKGp1bWRjYm9yABEAEIAAAKoAOJtxA2MycGEuaGFzaC5kYXRhAAAAAGxjYm9ypGpleGNsdXNpb25zgaJlc3RhcnQUZmxlbmd0aBkXi2NhbGdmc2hhMjU2ZGhhc2hYIMvph5mUhWqdzPCnzkr1ISRKNjB7IB/ZI/miN9Yb6mfPY3BhZE4AAAAAAAAAAAAAAAAAAAAAAYRqdW1iAAAAKWp1bWRjYm9yABEAEIAAAKoAOJtxA2MycGEuYWN0aW9ucy52MgAAAAFTY2JvcqFnYWN0aW9uc4KjZmFjdGlvbmxjMnBhLmNyZWF0ZWRrZGVzY3JpcHRpb254IENyZWF0ZWQgYnkgR29vZ2xlIEdlbmVyYXRpdmUgQUkucWRpZ2l0YWxTb3VyY2VUeXBleEZodHRwOi8vY3YuaXB0Yy5vcmcvbmV3c2NvZGVzL2RpZ2l0YWxzb3VyY2V0eXBlL3RyYWluZWRBbGdvcml0aG1pY01lZGlho2ZhY3Rpb25rYzJwYS5lZGl0ZWRrZGVzY3JpcHRpb254KEFwcGxpZWQgaW1wZXJjZXB0aWJsZSBTeW50aElEIHdhdGVybWFyay5xZGlnaXRhbFNvdXJjZVR5cGV4Rmh0dHA6Ly9jdi5pcHRjLm9yZy9uZXdzY29kZXMvZGlnaXRhbHNvdXJjZXR5cGUvdHJhaW5lZEFsZ29yaXRobWljTWVkaWH/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAQABAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+/OIEIB0wqgAdAAAo6knjb/M9+JCAfyx0H+H/ANb2pFHA4xwM5OSMdvT8R+VOo33C7er369RAMdP5D8+nt9PajA/TA4HH04/+tz0paKAEAA//AFD8+B/9b2ox374xnj8+n/1valooAQDH5Y7f4f8A1vajH8vQfn06/p7UtFABSY5z7Y6D88/5FLRQAgGPyx2/w/8Are1GOc+3oPzzj6/nS0UAFJjnPtjoPzz/AJFLRQAUmOc+2Ogz9c4+vt7UtFABj+WO3+f6UmOc+2Ogz9c4+vt7UtFABSY5z7Y6D88/5FLRQAUmOc+2Ogz9c4+vt7UtFABSY5z7Y6D88/5FLRQAY/ljt/n+lJjnPtjoM/XOPr7e1LRQAY/ljt/h/wDW9qTHOfb0Gfr0+vtzS0UAFJjnPtjoPzz/AJFLRQAUmOc+2Og/PP8AkUtFABSY5z7Y6D88/wCRS0UAFJjnPtjoPzz/AJFLRQAY/ljt/n+lJjnPtjoPzz/kUtFABj+WO3+f6UmOc+2Ogz9c4+vt7UtFABj+WO3+f6UmOc+2Og/PP+RS0UAFJjnPtjoPzz/kUtFABj+WO3+H/wBb2pMc59sdBn65x9fb2paKACkxzn2x0GfrnH19valooAMfyx2/z/Skxzn2x0GfrnH19valooAKTHOfbHQfnn/IpaKACkxzn2x0H55/yKWigApMc59sdBn65x9fb2paKACkxzn2x0H55/yKWigApMc59sdB+ef8ilooAKTHOfbHQfnn/IpaKACkxzn2x0H55/yKWigApMc59sdB+ef8ilooAMfyx2/z/Skxzn2x0H55/wAilooAKTHOfbHQZ+ucfX29qWigApMc59sdB+ef8ilooAKTHOfY9h+efzpaKACkxzn2x0GfrnH19valooAMfyx2/wA/0pMc59sdBn65x9fb2paKACkxzn2x0H55/wAilooAKTHOfbHQZ+ucfX29qWigApMc59sdB+ef8ilooAKTHOfbHQfnn/IpaKACkxzn2x0H55/yKWigApMc59sdBn65x9fb2paKACkxzn2x0H55/wAilooAMfyx2/z/AEpMc59sdBn65x9fb2paKACkxzn2x0GfrnH19valooAKTHOfbHQfnn/IpaKACkwM5/oPz6f/AFvalooAMfyx2/z/AEpMc59sdB+ef8ilooAKTHOfY9h+efzpaKACkxzn2x0GfrnH19valooAKTHOfbHQZ+ucfX29qWigApMc59sdB+ef8ilooAMfyx2/z/Skxzn2x0GfrnH19valooAMfyx2/wA/0pMc574x2/w/+t7UtFABj+WO3+f6UmBnP9B+fT/63tS0UAIBj/I/p696Mc59sdB+ef8AIpaKADH8sdv8/wBKTHOe+Mdv8P8A63tS0UAIBj/I/p696Mc574x2/wAP/re1LRQAY/ljt/n+lJjnPtjt/h/9b2paKACj/P0/z/SiigApjIrDBGcZI6dcEcccHk8gZ5OOtPooD+uq/IYDkjgDI6bh2zwMZ79/QHinenH+ffn/ABpo6jgcgcbgegPA+h7+x4707Ht2655GeTk5z+RPNHbT+k/nr22v2QvX/g9PX56/PstFFFAwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGA5I4AyOmfTkDjuD1OOMcdMlwHt2655GckjPXr3poycHA6DjPp2x6gnk9ugz1Lse3b15GeSCevXuM0u39dd3vqum197dktk/TXr03069fT7looopjCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAYM8cdhwT6e3qD1PbGBnqVx7duufXJIz169xmkGeOByBxngEdgOxBGT6AEAZ6qPYdR1z684znPXuKX9a+u/X5L+klsvlru3t679dem/Z1FFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADRnjjt0zwMdseuevHAGBk0D2HUdc+vOM5z17ikGeDgYx0zwCOwHYg9eOOg5HKj2HUdc+vOM5z17il/X4ry3XT+rStlp22+X4dHrsh1FFFNbL+v8vyRQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADBk4OO3I7DHbr1B68cYwMkcqPYdR1z65JGevXuM9aQEnHAxgcZ47dB7E8nnHQcjlR7DqOufXJIz169xnrS/r8V5brp/VpWy06Lbfp+HfyX3O/z60Uf59aKa2X9f5fkigooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1J4+g4J+mMe+Ryeccgc9XD2HUdc+uSRnr17jPWmg8jgdB1P5Afj1x0xgc9X49ucHv074z16+maO39dd3vZ9lp+pK2Xy16vbf1667fgtFFFC2X9f5fkigooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1PI+g4J/EY57Hk46dB7ux7duufXJIz169xmmg8jgdAOT9MAe4PXHTtz1fj27dc+vOM9evejt/XXd72fZafqJbJ+mvXpvp16+n3LRRRQMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6nv7c4yD1x06D3fj25we/TvjPXr6Zpi5444wOp7gdueo7ntg45HL8e3OD36d8Z69fTNL+vxXrt0/qyWyfpr16b6devp9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARg9OOw6n6cDtnOM46YwOer8e3OD36d8Z69fTNMUnjjsOp9PTtkHrjpzjnq/Htzg9+nfGevX0zS/wCH/H52a6L+lK2T9Neutt9Pv8l9y0UUUygooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1J447DqfQdu2R3I6duerh7DqOufXnGc569xTV6jjsOp9Ow+h5OOnbnkvx7c4Pfp3xnr19M0Pp/XXd72a6LT9SVsn6a9dbb6ff5L7looooKCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjXt9BwT/L8Rk4yBjA5HL8e3OD36d8Z69fTNMUnjjsOp9B27ZHcjp256vx7c4Pfp3xnr19M0P+vv8AzXT+mStl8tevTfTr18l9y0UUUFBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARjPHA6Dgn6dBn1HJx245GS/Htzg9+nfGevX0zTBnjjsOp+nA7ZGAWxnH1HL8e3OD36d8Z69fTNLtt/T676rptfe3US2T9NevTfTr19PuWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6n0HbtkdyOnbnq/Ht2659ecZ69e9MUnjjsOp44HbtkHqR0wR15L8e3OD36d8Z69fTNL+vxXluun9WldH3tru+m+nW2v3+i0UUUygooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1J447Dqe/tzjIPXHToPd+Pbt1z684z1696YD047DqfyA7ZB64zjoOer8e3OD36d8Z69fTND6f113e9mui0/UldPlru3tvp12fp9y0UUUFBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARrnjjsOp+nTnseuOmMDpy/Htzg9+nfGevX0zTFJ447DqeOB27ZB6kdMEdeS/Htzg9+nfGevX0zR2/rru97PstP1Etk/TXr03069fT7looooGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGpPHHYdTxwOw55zjJHTp7l+PbnB79O+M9evpmmjPHToOpOMjpj345IHH16ux6Dse/Pryc56+maXbT+r7vfbotPQS6fLXd9N9OvV+X3LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGpPHHYdT6Dt2yO5HTtz1fj27dc8+uCevX0zzTB1HQ8Dv6dMe46nGcfXq/HoOx78+vJznr6ZpfL/AIOvXe1uiuvRbiXT5a7vp5dev3+i0UUUL/hv+GsregwooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEY7dMEDqeM9gPfIyeDjoPd+B6evPcd+uc9fTPNNGePTA6k4yBwB78ZOBx9Ry7A9PXnuO/XOevpnml8l/nZ9d7NdNVfshdvz3fT10fV/8OloooprZf1/l+SGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAwdvTA6k4z2A98j8OmO5dj27dc8jPJyc5/InmmjPHTGO54yOgA9eMnjj6g5d+H8uO/P4+meaXb5/n13s10Wnoui/q/3fg+v9WWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx0xgdTxkdAPfI54+nI5cBjt+Pf15/H6800Z46YwOp7gcYHrxknH06ZL/w/H/P50vu6/hJ772a6K69ELt+a+Xro+v8ATRRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAwZ46YIHU9+3Hr36fTnkuwB2/H/ADzz1poB49MDqTjjpx69ycfTnq/8Px/z+dL7n/wH131XTVeiF/XnuvLZ9f6sUUUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUANGeOMjA6n06cc85wc9ug9S6mjPHHGB1P5cDv0OcYHQe7qX3f8M+u+q6a666IX9ee68tn1/qxRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQA0ZOMDgjPsMdPx9T0HbNOpvPYcYHXjGOgxzznqewHrTqXX+u/o9umurvsH9f1+oUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooATnjA4x34xjoMc8574496X8P8/5J/Wk54wOMd+MY6DHPOe+OPelpfj+WjX4rp/VgKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUhZR1IH1IH86AFopnmR/8APRP++l/xo8yP/non/fS/40Ds+z/r/h194+ikDKehB+hB/lS0CCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBOeMDjHfjGOgxzznvjj3paTnjA4x34xjoMc8574496Wl+P5aP56r8/wAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUV+Ln7e3/BdD9jH9iGfV/A9lrU37Qnx203zreb4TfCjU9Nu7fw7qMbBRbfEfx7Ibrw54JdJA8d3pSprvjC0ZQ0nhMxOstfx9fthf8ABc39v/8Aa8n1PRB8SJP2fPhdemeGL4bfAe81LwrPc6dMpi+z+KPiOJl8eeI5Jrc+XfwWmpeHvD12Szr4bgVtg+Wzfi/KMpc6PtHjMXHR4fCuM1CW3LWrt+ypNPSUE6laL3pan7/4dfRu8R/EKlQzH6jT4Z4frKNSGc8QKrhniaMkmqmXZbGDx+NjOLUqNaVLDYGttHGp6H96n7Sn/BRX9ib9kVbm3+P37Rvw48FeILZHc+B4NWfxT8RZSqb0WP4feEoNc8YKs3CRXE2jQ2hY4a4UBiPwr+OH/B1D+z54dnu9O/Z4/Zt+KnxZmjEkUHiP4h67oXwi8NyyqcJc2tlb2/jzxVdWjY3CO/0XQbllIDLC2QP4hSvmTz3Ls811dSvPdXUsjz3V3PIxaS4urqUvcXM0jktJNPJJJIxLOxYmpoE+0tcR2qPdPZ27Xd4lpHJctZ2kbIr3V2IFkNtbRs6K9xOI4ULrucEjPwON4+zjEtxwkcPl8G2o8kFiayv3qV06crK/w4aDv+H9f8K/Q+8M8np06vEmMzri7FxSdWNbESyPKpNNa08JllRZhBOTV/aZvXg1ZOKu7/0Y/Ez/AIOc/wDgoB4uaeD4e+Bf2dvhFYsWEE1t4W8VfEDX4FJO3fqHiXxVaaHPKgx83/CLRxswyYcEg/FXi3/guB/wVR8ZySPe/tc+JNAjk3YtvBXgD4UeE4owcYEUuneBxfKFxhS148gwCXJ5P5Rkgc7ieOMZGfcHkfTHHGOea+hv2dP2Tf2l/wBrbxJN4V/Zu+C3jr4t6lZTQwaxe+G9Nig8K+G3uP8AU/8ACVeNtam0zwf4Y8xctCmt65ZTXCg/ZopiAD4M87z/ABtWNKOZZlXq1Hyxo4erXg6kt7Ro4dwUnuuWNNvbSx+wUPCrwc4TwVXH1uCOBsswGDj7SvmWd5fl1elhoKyc6+ZZ4q8qceay56tdauKbbPern/gqh/wUnvHaSb9uP9o4MxJItfHK2CAnniKxsLeNccYCoAOmOtXNO/4Ku/8ABS7SpUmtP24P2gpHQ5C6l4o07WoSe2+DWNHvonH+y6MCOCMV+mHw8/4Nif2/PFGjQ6n42+In7OHwrvJ4xIPDmo+JvGfjPWrRyAfI1Cfwt4PPh6OQH5WbTde1aIH/AFcso5ryD45/8G6//BSb4O6bea14X8MfDH9oLSrGCS5nh+DvjeSLxQsEYyzQ+FfiJpXgm61GfHKWWg3utX8x+S3tZnwD1yy3jCnD28qOdqKXNeNfETqJWTbdGnXlXT3unT9dUz5jD8c/RnxuMWVU8f4VSryn7JRrZRk2HwU5XUVGGYYnLaOWzTbSj7PFSjK6UW7o8q8G/wDBeb/gqv4MaLH7TVv4utoiubPx18J/hTrSTKpB2TXmneEtF1YhgMO0WoxyHnDg4I+5fhb/AMHR37ZPhqW1h+LfwH+AXxV0+NlFzP4Xm8a/CnxBcoMbyLubU/iFoiykAlQnh+FNxPAUAV/OV4g8J6t8NPiA3gf41+FPiD8PNT0HV7W28ceEtT8PSeGviNo+nGdFvjaeHvGMGnrFqgt98mmpq0drp19MI0a8it5jdR/vn+z/AP8ABB7wT+2v8KIfjB+xR/wUF+HXxL0VjDaaz4U+JXwg1vwJ4y8C67Nb+efDPj/T/D/jrxle+HtYhxIEf+xLnTNWtozqeg3+raZJFcvWV4/izFVZ0svzDF1q9HWWGr4unKraNubkoY6q3UUNVONOE3T/AOXiipRbXH/B/wBHfI8BhMx404M4byvKMz5Y0M8ynhvMMPl7nVUXSjXzjhLBeywU8TGSlhJYyvQWKSk8NKq6c+T9pPgL/wAHO/7E/wAQp7LS/jh8PPjD+zrqlzJHHNq15pVr8U/AdqX4Z5Nd8DbvFghRuTJN8P4I1TLu0YWv3R+BP7U37OX7Tuhf8JJ+z98a/hv8W9LSFJ7v/hCvFOmatqWlK5wqa5occ665oE5b5Tba1p1hcq3ytCrcV/Ad8cP+Df3/AIKafBaG91HTfhF4X+OehWSs8mp/A7xzpmvag8QyQ0fhDxfD4J8Y3kpA/wCPXSNB1WbJCrvbZn8odV0X4w/s5fEWBNZ0r4rfs/fFzw9cCWzOo2Xi74TfETSZ4GyJrGS4i0DxBCodQRPbEW8gwQ7oRX0UOMeIsplGGd5XKpTVk6s6FTB1JN2TcKsYPC1EnqlCkr6rnXT8UxX0aPBXxCo1cT4U8fUsFi+R1FgcPmmE4mwVFJJxhiMDUr0c9wV7qMqmKxlR04tS9hNpqX+uXnt39O9FfwBfsZ/8HHv7YHwAk0zwt+0ZY2n7WHw1gaG3k1PV7m08L/GrSbNSQ0ll41s7I6L4weNWMhtvGWkPq98yLHJ4ss1JkH9gf7FP/BTD9kL9vjQjd/AX4l2snjOys1u/EXwh8Yxx+GPiv4ZTB86W+8J3dxI+q6XC2FbxF4Xu9e8NhmSI6us7eSv22T8TZTnSUMNX9libXeExPLSr7X/drmcKytd/upzairyjE/ljxH8B/EXwzdXE5zlP9oZHCVo8RZK6mOytRbSjLFv2dPFZc22o3zDDYanOb5KFSv8AE/vqikBB6f5/Klr6A/GwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooATnjA4x34xjoMc8574496Wk64wOMZ5/QY5598fnS0vx/LR/PVfn+AFFFFMAooooAKKKKACiiigAoor4B/wCChH/BRb4Df8E6/hE3xE+LF8+ueMNfF7Y/Cz4Q6Fd2sfjT4leILWJWe3sEuBImj+HNMaa3l8T+L7+FtL8P2k0QKX+rXmlaPqOOIxFDCUamJxNWFChSi51KtR2jGK082221GMYpynJqMU5NJ+pkuS5txHmuByTI8BiczzbMq8cPgsDhYe0rVqkk27K6jCnTgpVa1apKFGhRhOtWnCnCUl9HftD/ALR/wV/ZU+Fuv/GX4+fEDQvh18PvDyKtxq+szt9p1LUZlc2WgeHtJt0m1TxF4j1NopI9N0HRbS91S9KSNDbGKGaSP+Er/gpb/wAF/P2gf2vbnX/hb+zjceJf2dP2cJnu9Oml03UBpvxl+J+mSBoHl8X+JNIuXbwXoGoQFt/gvwlfm4kt55rbxD4l1m3k/s61/Mb9uD9vP9oj/goB8Vpvif8AHfxLvsdOnvI/h98MtCmu7f4d/C/R7x1B03wrpM8r/aNTuIo4F1zxZqhn8Qa/LEhurmGxhsdNsfi5mSNGZ2VFVSzu5AVFGdxYkgKAM5J49xwa/HOIuMsVmTqYXL3UwmA1i5RbjicVF6P2kou9KlLb2MJe9Fv205Rl7OH+mPgt9GLh/genhM/4yo4TiTjC0K1LDVILEZJkFWylGOEo1E4Zhj6UrOWYYiDpUaii8BRpSpRxleVEVF2qoUZLEKByxO5nbjLMxJZmYlixLMSxJr6M/Zo/ZN/aN/bC8cD4efs3fCXxT8UvEEEsA1m70i2isvCnhOG4YLHfeNfGuqyWXhbwpZMATEdY1S2ub0qYdOtb25KQP+63/BJH/ggP4i/ao0Twv+0j+2GfEPw+/Z91iG11v4f/AAr0yefQ/iH8Y9HlVZ7HxDr+pri+8BfDrVYzHLpqWaQ+MvFmmyG/0668L6VPpWs6v/bv8Hfgn8I/2fPAWj/DD4JfDvwl8L/AGgReXpnhfwdo1po2mxuURJr26W2jWbUtUu/LSTUNY1Ka71XUpwbnULy5uGeVryHgjFZjCli8wnLBYOajOnTgk8VXg7NSipJwoU5LWFSpGc2tVRUZRm8vF76VPDvBOKxnD/B+Go8V8TYWVTD4vF1Ks4cPZTioPlqUa1WhKNfNcVQnFwr4XBVcPQpzvCeYxxFKtho/yy/suf8ABt18Bvgd4Kv/AI5f8FJfjFYeKNN8G6Jd+MPFnw98D69qXgf4NeE9F0a1bU9Un8cfEWVdJ8beLLWxs4JXvG0YeArGJ45IB/bVu6PL+A//AAUQ/wCCgHgb476ze/Az9jn4X+Ff2af2IvB98LXw34D8AeFtN8Dat8aLnSpiLT4j/GOTSLa01LXmleNbvwp4W8Q3OojQ4DDqutPe+K55rjT/ANTP+DjT/gp/e/Fj4g6l+wN8E/EjJ8K/hlq1vJ+0LrWkXBWLx98UNLnS7svhsbqFgbjwx8NbmOC68S2hc2+pfEBY9PuoRJ4IVrr5q/4IUf8ABJE/tv8AxFP7RPx50Kdv2UvhP4hFva6FfRSRQfHT4i6U8dx/wiakhTP8PvC0hguPHdxExj1u+a28GwF4pPEz6dWYU6GIx8eGeGMNCnBSdLHYxXlWxMote2VfFy5qqwWH1dWMZKFWqnTp03H2canLwZjc1yXhCt47ePGfYzHYipRp47hPheXLQy7J6GKi3lk8tyGk6GBlxLnMXB4CvVpTxGAy9xxeKxkas8bWwHb/APBH/wD4IXeKP2y4NC/aM/akh1/wB+y9K8OoeDfCNpJcaJ46+PMEcgZLy3vQI77wh8LpmQo3iC2EWv8Ai6HenhWTS9NeLxM/92Hwp+EXww+BngTQPhj8HvAfhf4b+APDFotnofhPwhpFpo2j2MYVRJL9mtI0+0310y+dqGpXbT6jqV00l3f3VzdSyzP3dlZWem2dpp2nWltYWFhbQWdjY2cEVraWdpaxJBbWtrbQJHDb21vDGkMEEKJFDEiRxoqKqi1X6TkmQ4HI8OqeHgp4iUUsRi5xXtq8tG1fV06KkrwoxfLGycnOpzVJfw74qeL3FXitnM8bnOJqYXJ8PVm8m4cw9aby3K6OsYScLQjjMwnD/ecyr01WqycoUY4bCRo4WiUEA9aa7Kis7kKqgszHgKoGST7Ada/C39uf/g4A/Yr/AGQrnWPA/gPUbj9qH4zaY09pP4N+FGraefBnh7U4jsa08a/FSVL7w5pc0Mm6O703w1b+L9fsp43t9Q0exfLL343H4LLqLr43E0sNSV7SqS1k1vGnBXqVJa/BTjKVtbWPkOFuDuKONsyjlPCuR4/O8e+VzpYKjzU8PTlLlVbGYqo4YTA4fm914jGV6FBSsnUTaR+iP7YP7Bn7Lf7dPgSbwN+0X8MNI8VPDaTweGvHNhHFo3xL8CXEwcrf+C/HFrCdY0d0ncXM+mSyXnh3VpIo4de0XVrMNav/AArftMfs5ftff8G/X7XPhL4o/A34u2viPwN4oubuPwR4q8+3jtPiD4YsZob3UvhT8e/htb36SGcWs0bw6rbRLo+oBk8TeCNX0DxHZXumaHyf7Vn/AAXq/wCCi/7UU+oaXpXxOj/Zv+H12ZY4vBXwBF54Y1VrNw0Yj1n4n3U1z8QL64eEmO7bRdV8L6VdEuw0aFG2L8Jfs/8A7G37YX7cXiu9m+Bnwe+J/wAcNXu74weIfiFdtcHwvaXsrF5T4p+LHjW+svDlvdE7pHt77xHJqcoDtFayybVP5VnufZdnGKpf2PlmMnmlOpF0MwofucTJ03F2VGjCrWxEeX+G6kqNWk7Si1DnhU/0O8HvCfjXwxyPMIeJnG/DdHw/x+ErUs74HzXlzXJKcMVTacqma5jisBl2SYlVeV4j6lTzHA46MeWsqlZYbE4b+2LwD/wcxf8ABPLVvhR4M8XfES4+Kfg74lapokM3jT4VaH8N/Eni258KeIoS0Go6daeK4LTT/C2t6ZLcRvc6NqUOqQT3OmT2smp2Gk35uNPt/BvjX/wcNf8ABIz48eHLnwF8ZP2afjf8ZvBd0JVk0zxz8D/hXrmmxtKhja80638QfE1rvT75VJa3v7IWWoW7BZIJ4pVVl/lo/a4/4J2fHX/gnh8RPgzon7Y/hu5074cfE5NO1a88ZfBzVLTxTGml2d/axeO/Cnh/V9a0yx0Z/ib4S0y4ivho+o2j6RqEV5p09jqd/p8l1eWv9en7Nn/BvV/wSY8W/DfwH8U9Gufi1+0Z4Q8e+GNE8W+G/FviT4wavpmk+INH1qxhv7K+t7H4Z2Xw9jto5opl82wukN5YzCWzvBHdQTRp6mCzPjDNamIwCp5XQq4WnSjiaWOouE5RqR0nUpP2zmp25pOnQVNc8dIxlC/59xXwH9Gfw7wGS8XfWfEDN8u4hxOOxHD2ZcJ5vRxmDpVcHXaqYXB5nCOXRw1TCNulRhjMwq45xo1HOrXqUMRUj/N9+0L4V/4IdfHOXUNd/ZX+O3x7/Yv8X3Pm3Fr4D+Ovwo8e/En4LXV05Vo7BdZ8F3fxJ+IHgi3dyxbUk1jxvp1ku1Lfw3HF86flHfWviP4N+P8AT9X8F/EjRrjxJ4W1GLV/B3xU+Cnjm4mjiuLaQtaaz4a8S6X/AGN4n8P3vy7/ALDrem+HfENsrGLUNJtixjr/AEZrX/gg7/wSZtIBAP2PfC9wAu0zX3xC+Mt9ctxjcbi6+I0su7/aVga8K+Kv/Bt7/wAEyfH1ncjwZ4I+JnwQ1aSJxb6r8N/il4m1GOCUqfLd9H+Jc3j/AEiWJGwTBFaWzOo2rNGSGHHjeCc5r2rU6eRUMQpc7+oVMbhlOV7p+zqU5YeEouzj7GOFSavJy0t9Bwn9Knw1yZvLMbjPFbNslq0nh0uL8Jwxns8PTmlBqeOweNo5ziqU4NxrRzGrnVSUXyUVSXxflj/wTR/4OQtZ0Wbw/wDBj/goY7avojtZ6RoP7T+haSialpa5W3i/4XR4W0a1C6lagbPtHj3wlYpexBTceIfDV80l9r8f9jXhbxX4Z8ceHNF8YeDPEGi+K/CniTTbTWPD3iXw7qdnrOha3pN/Es1lqOk6rp81xY6hZXULLJBdWs8sMqnKOecfwq/tgf8ABtH+1L8GdM1jxl+zH470T9p3wtpsE15J4JutMh8AfGJLSFHlli0nTp9RvvB/jS4iiU5isda8OatfuFi0vw5eXckdq3w//wAE4P8AgrB+0d/wTB+I178OfEmm+KfF/wAB4/E1zYfFL9nPxcLvSPEPgjWI7vydf1j4e22uiCfwH48sZVkfWfDN7Da6B4nmja31uzstTe217TuzLeJM4yKtSy7irDV1Qk1ChmEkqsopJJ89am6kMZTjeLnOE5Ymkm3NVbxjH5/jjwQ8OfF7Lcfxr9H/ADnK6mb4aLxGbcG0JSwFDESleTeEy7Gww2KyHGVXGao0K+HpZRjJLlw0sH7OpWq/6VNFeFfs3/tI/B79rH4QeE/jl8C/GOn+Nfh74vtDNZahalob7S9Rg2pqnhzxJpc2LzQPE+h3LGz1rQtQjju7G5AOJbWa2uZ/da/SqdSFWEKtKcalOpGM6dSElOE4TSlGcJRbjKMotOMk2mmmnY/hXF4PF5fisTgcdhq+DxuDr1cNi8JiqU6GJw2IozdOtQr0aijUpVaU4yhUpzjGcJJxkk00FFFFWc4UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACc8YHGO/GMdBjnnPfHHvS0nJwQOCAefzHrznqfalpfj+Wj+eq/P8AKKKKYBRRRQAUUUUAFFFeWfG740fDr9nf4TePfjb8W/ENt4V+HPw18O33ifxVrdz8xt7CzULHa2duCJL/VtUvJLbStF0u33Xerave2WmWccl1dwxtM5xpwlUnKMIQjKc5yajGEIpylKUnZRjGKbk20kk23ZG2Gw2IxmIw+EwlCricViq9LDYbD0KcqtfEYivUjSo0aNKClOpVq1JxhThFOUpyUUm2fN3/BQP9vX4Pf8E9fgHq/xn+KNx/autXjzaF8L/htp15Bb+Jfid44ktnlstA0gSrKLTTLNQt/4p8RTQS2PhvRUlvJkub6bTNM1H/ND/ar/AGqfjP8AtnfG3xV8evjr4jbXvGPiSU29hp1oZ4vDXgjwvbzTSaN4G8FabNLL/ZPhnREldYog73up30t3rWs3N7rGoXt5L7H/AMFEv28viX/wUN/aN8Q/GvxsL3Q/B9gbrw98HPhtJdmex+HHw9jujLZWLJGxtbjxXr7JHrPjbWoUU6lrEgtbdotG0rRrO0+FMen0H/6q/DeKOJKudYl0aEpQy3DzkqENYuvJXi8TVi7O8lf2UZJOlB7RnOpf/WXwB8D8F4WZHDMs1o0MVx1nOGg82xfu1VlGGqKNRZHl9ROUYwpvleY4mlJrGYqCSnPC4fCtJ2z7Z9COP0Nful/wQk/4JoWP7dn7RN/8Tfi3ojaj+zN+zvqGkap4t0y7jzp3xQ+JVwBqXhP4Zz7h5d14esIIk8VeP7ZRL9o0v+w/Dt4iWvix54vwvZSB2JxnHuPU8+3Nf1I/8E9f+C837Kn7AH7KHw0/Zx8NfstfGvxXrmiRaj4k+JnjS01r4e6Lb+M/iV4pu21HxRrsENxrF3ey2ED/AGTw/oEl+ttex+GND0S1uYElt2A4uG4ZU8yp1s4r06OEw0XW5KkZzjiK0ZQVGk4whNuCbdWomuWUafs5XVRo+q8aq3H8OBcdl3htlOLzHiTO6qyxYnB18JhamT5bWp1JY/MYVsZicLThiXTgsFg3Tn7ejWxSxlK08KpH9yFvbwWkENrawxW9tbxRwQQQRpFDDDEgjiiiijCxxxRxqqRxoqoiKqqoUAD8r/8AgsT+3vH+wB+xx4s8d+Gr21T41/Em4f4X/Ayxm8uWSDxprljdSXvjKWzdsz6d8PdBh1DxRMJI5LO51a10PRLwomtRk/mT4X/4Oqv2Qr6VE8Yfs4/tMeGImZQ1xpNv8MfFMcak4LMn/Ce6JO2BzhIST0Ffzh/8Flv+Cken/wDBR39pjQPFvw/g8VaP8BPhX4MtvC3wr0DxfYxaRrc+ra6LTWPiH4t1rRrXUNUtLDU9X1aHTvD8CQ390smg+EdGuS8ct5cxL+lZ5xdltPKsRLLMdTr4yslQoRp80alJ1LqddxnGMo+ygpOMrNKq6aasz+GvCX6NXHGO8Q8lpcfcKY3KuF8uqSzbNquMlhauFx8MC4VMPlMauFxFenWlmGLnQpYmlCoqn9nrHVIPmpHyT+xp+yx8Rf28P2pfh1+z94TvtSl1z4keI7nV/Hvjm78zU7nwv4LtJzrHxF+Ius3Fw5+2X1rZS3ElobyYHWvFep6RpjymfVV3f6lfwR+DHw7/AGd/hJ8Pvgh8JvD9v4Y+Hfwz8M6d4V8LaNBh2hsNPjw93e3G1Hv9X1W7e51XW9UnButW1i9vtSu3kuruZ2/mY/4NiPgd8FPh98G/HXx81X4hfDPVf2hfjtqc/hvSPBdr4z8MX3jzwN8IPB2pTQWenX/hqDVJPEGi3vjjxVb3/ibUra60+3F7oel+B7kKfKBP9UOu+IvD/hjTLnWvEuu6P4e0azUvd6trmp2Wk6ZaoOS1zfX89vawKACS0sqgAEk8U+CMqp4HK1j6nI8Vj4qpKd0/Y4ZJOjSbu+VzVq9XZtzpxmr0kzL6VviHjeLOPnwhgliaWQ8H1J4LD4b2dSnHMc8nalmWPjS5Y+2hh5p5VgZRjOCjQxWIw0+TMJp7NfGf7aX7fP7M37A/w6/4WD+0N47g0WbUVuI/BvgHRVh1j4kfEPUbdQX07wb4US4gub5YmaNdQ1q+m07w1oolhfXNa01J4DL+YH/BT/8A4L5fs9/seeFLnwL+zZ4i8B/tI/tJa7ZzLpdn4Y8R2Pif4W/DGFw0SeIPiT4l8M389rfahHJl9M+H2ianHr2otE8mt3nhjTmtby+/gd+OHx9+MP7TPxP8RfGb48fEHXfiV8SPFMxfU/EOu3KsLazR3a00PQdMgWHTPDfhrS1cw6T4d0S1stJ06AbYLZXaSR1xDxlhss5sJl/s8Zj2rOSfNhsNfW9SUGva1bbUoSSi7upOLj7Oengr9GDPOPPYcQ8ZLG8N8IqSlQw7p+wz3PlGVmsHSxEJfUMA7PmzDE0ZSrKywWHqwnLFUP1x/wCCh3/Bc79q39uZ9a8BeEby8/Z1/Z1vTPZ/8K18E61cf8Jd4z0uQsoHxS8fWa2V5q8F5EQLnwl4dj0fwp5ZW21KDxHLAupSfmr+zL+yX+0H+2D8QYPhZ+zd8Lde+I3iVBby6pJpkMdh4W8H6bcSeUmr+NfFd8bfw94S0kNu8qbVb2Ce/dDa6Va6jfmO1ks/sm+D/wBl7xr8V9Mtv2uvjdr3wT+C2kiHUPEV74L8DeJvHHjvxckc8Ybwt4Uj0PQ9a03w3cXkQkN54o8QQT2+lwHNhpGtXjrbw/22/s0/8Fjf+CF37LXwz0b4Q/ALxvcfCnwNo6h/7PsfgN8aRe6vqLxql1r3ijXX8EX+seKPEV6I0+369r1/qGqXKpFE9yYIYIo/hMuw0c/xcsbn+e4WhT5knGtjMPHFVUmm6VGjKahhaKezlTULu9OjO8pr+t+Ms+r+DWQUeFvCHwlzzOcbKiqsJZVw7nOJ4fwUpwUY43N80w1Cpis/zKaS5qFPGTrKKUcZmGGlTpUKvnP7BP8AwbWfAD4OQaP4/wD20dWsv2j/AImxiC9T4b6WdQ0v4EeF7tcOLe5sZVsfEHxOuIHVN1z4nGk+GbpTJBP4ImCpct/Sx4Y8LeGPBWg6X4W8G+HNC8JeGNEtI7DRfDnhnSLDQtC0ixhGIbLTNI0u3tbCwtIhxHb2tvFCg4VAK/Kfw/8A8F4f+CTviJ0ig/a/8KaTK5ChfE/gr4p+Fo1JOB5lzr3gaws4x6s9wqjklgK+svh1/wAFCv2Ffi28EHw5/a9/Zz8VXlyVWDTbD4v+Bo9XlZyAqJo95rVtqhkJIHliz3gnBUHiv1TKlw9gaSoZVXy2KdlJ0cVQq1qr6OrUVSVWo77KUmot2iorQ/z08Qq3jNxVjpZt4g5VxtNwlOVClmeQ5tl2V5fGW8MDgZYPD4HBw5WoylRpRnVtz1qlWo5Tcf7ef7F/w2/b2/Zm8f8A7PHxGiitDr9n/avgXxetslzqXw8+I+kRTy+EvGulAlJDJpl7K9rq1lDNB/bfhu/1rw/PNHa6rOw/nQ/4N8v2rPiP+zh8bvjL/wAEhP2pGl0Dxt8PfE3i7VvgzZ6nctJb2Ov6NLPqnxK+Hug3Uyob3w94j0+VPi98PJoBHa3+kXnivULdpIb/AE+Nf67bK+stStob3T7y1v7O4QSW91Z3EVzbTxsMq8M8LvFIjDkMjMpHIOK/lD/4OJ/2WfGHwe8ZfAn/AIK4fs42jaV8UvgJ428B6V8XLrT4HCXmnaZrVuPhd451tYAgmstP1aU/C/xbLcGV9T8M+LfDuny7NO0SQVyZ/Qlg62G4jwkW62X+5j6dPfF5VUkvbxdtJSw6ft6bl7seVzlf2cEvpPB/N8NxJl2e+CnEVeEMq4zbxXCWLxUrQ4e8QMJTbyjEU5Su6NDOXBZTjoU1z1va0qMHTjicTOf9YwOf6+31pM8ke/8AQHP64rxH9mr45+E/2mfgD8IP2gPA7hvDHxc8AeG/HGnQeYJZdNfWtNhuNR0O7dQFGo+H9UN7oepxgfudR0+6iIDIQPb6+nhOFSEKlOSlCpGM4SW0oTSlGS8mmmvJn4RisLiMDisTgsXRnh8Xg8RWwuKw9VctShiMPUlSrUakfszpVIShNdJRaEIB/Hvgf1FfhJ/wWH/4JA/Br9t/wfefGvw2sPws/aK8E2KXV98SPD+hDUY/G/gzT0VdS034g+HbKS0ufF83hjSYpNU8P3tnKPFcVtYTeHdLlvob2z01P3cprosilHUMrDBVgCCD1BBBBB6EEdK5sdgcNmOFq4TF0YVqNVaxmm+Wa1hUg4uMoTg9VKEoyWqUkmz3OEeLc/4Hz/AcScNZjiMszTAVOaFbDzSjXoycfb4TE05xnRxGGxEI8lWhXpVaUlaTpuUINf5t37L/AO03+2B/wQm/a71XwV8S/DGo3fgHxBc6Vd/Fj4U22pjUPA3xe8BTu9vo3xe+DfiJzFpF/q0dis1x4Q8Y2iW8eqW8c3g7xla2TpcWulf6F/7P/wAffhV+098IfBPxy+Cviux8ZfDnx/pMWraFrFmSksbbmhv9J1aykP2jSdf0S/juNK13RbxY73StUtbmyuEDxbj+Zv7Qv/BP/wCCn/BQX4C/Fb9k34pQRaF8Qv2Z/iBrnhj4HfFfTreK68V/DXQ/Enh7QviD8Kms2kMU2r+C4vA/inw/8PfFnhi8ulsfEo8EXUwlsde03StY0v8AmN/4JvftbfHX/giH+3N4t/Yw/bCjuvD/AMB/HXi2w07x6s8t1deFvCGr6syWHhD9o/4eXk0a/afAniGzjtbXxnPawRS3Hh6I3OqWcXifwQ+ln4TLquK4TxVHB4upOvw/jqsoYXEzfNLLcW5NTw9aVoxjBVVOFRpRo1FGWLpKm1iaUv6x4vwGRfSNyHMuJMgwWFynxo4Uy6ljeIMjwcPZUOPOHoUKNTD51lNBylUqYxYOph6uHpOVXG0fa0snxUsVCplOLj/oEUVWs7u2v7W2vbO4gu7O8giurS6tpUnt7m2nRZILi3njZ4p4JomSSKaJmjljZZI2ZGVjZr9GP4q23CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooATnjA4x34xjoMc8574496Wm88YHBAPPQY6Dvznv0wBTqX4/lo/nqvz/ACiiimAUUUUAFFFFABX8Hf/Bxt/wAFJJfjt8ZR+xH8J9e874QfAbxAl38Xr/TJ3+y+PPjbZKyDw3PIj7LvQvhOk0lnPbkLDP4+utW+0xyyeFNIul/qM/4K5ftxw/sEfsWfET4raNeW0fxY8WmP4YfA+xl8qR5viV4rs75bPXGtXb/SLHwRo1prHjW+R42t7hdBi02ZlfUod3+YRcXN7qF1dajqV7d6lqWoXlzqGpalf3El1f6lqN9cSXV/qF9dTM01zeX13NNdXVxK7Sz3EskshZnJr824+zt0aMMmw8+WpiYqrjZResaF/wB1Qv3rSi51Fo/ZQjFpwrM/uL6H3hVSzXMMZ4nZ3hlPCZJXnlvC9GtBOFfN3STx2aKMlaSyyjVhQwkrSg8ZXrVYOGIy+DVvbgc5BJA69RjkcccnOM49zTwMAeuB/If4UfMQSoPHU8YHTrk4J57HrxSA8Ae38gP8a/KbaJ97/hY/0Mi27t9Xp6f194vGR+n6fj/+rmlHXPQ+vp/n2r7T/wCCfv7N/wAIP2qf2i4fhn8e/jXF+z78I9I+Hnjv4j+NfibLP4fszpel+CbKyuWsI77xVIuh2El817n7VdwXzqsDx22n3c8saDrv2vrr/gmr4QuNS+HX7EXhr9oD4sXNnILO7/aQ+N/xAh0fQ7+a3uP39x8O/hT4a8HeEbm/0+8ij2w6747OkqqSyeT4Ml22+pV1wwU3hXjJ18NRpuc6dOnUqt4ivOEYSlGlh6UalVxXtIJ1ZxhRjJ2nUizwK3FOFpcQw4Yw2V55mGPjhMLjsbicFlyWUZZhcXVrUqNTH5vja+CwCqz+r16kcBha+LzOpSpupRwNWNr/AAEpxlT2ySfyqQH0x+hqEAnng9B2PPAB685655BPXiv1z/4Jgf8ABIj4uf8ABTA+O/E+gfETwz8IfhR8Nde0vwt4j8b694f1PxbrGreJNR03+2ZdF8I+GbLUNDsr6bSNMl0+51q61XxJpMdmut6T9lh1FpbiO3nBYLFZhiIYTB0pV8RU5uSmpRjflTlJuU5RhFKKbcpyjFJb3sHE3EuRcIZNjOIeI8zo5Vk+B9l9ZxlaNapGEq1anQo06dHDU62Ir1atacIQpUKNSrKTVoNJtfkeipHcRXsI8i9t5Fltr23Zre8t5kwY5be7gaOeCVCAUkikV1IBVgQDXY+MviZ8S/iNZ6Tp3xF+JPxE+IWnaBD9m0HT/HnjrxX4ysNDt8AGHSLLxJq+pW2nRkKoKWkUKkKoIIVQPub/AIKXfsbfA79hX412PwE+F/7TGo/tG+PdC06S4+Lyj4f6X4Q0X4a6xcC2fRvCp1XTvGHiYat4qubV59R1zQxbwDwvZSaRDe6ld6pf3Vjpv5wu6RqzyOqIilmZiAFA7kn6U8TQr4KrXwlecY1aclTr06danVgpRs3CU6U5UpSpv3ZLmfs5xlCVpJpaZFmmWcU5ZlPEeWxq18FjMO8VlOKx2XYvAYpYaq3CNejh8zw2GxuGpYqmlUo1JUaccVhZ0q9J1MPXpVJxeTEihUjRFA+6qIqY54CgAZ44wPT2I/Z39gP/AIIdfHf/AIKC/C+H4yeCPjl+zt4D8Ey6jeaZNpmpa/q3jf4j6Rc2V5dWTp4n8E+E7IW/hKa5azlu9N0/xL4k0vV9Q0yS11WLTBp93bXM348+IdC1/wAK6rLoHivQtb8Ka9BDBcy6H4m0fUdA1mK2uoUuLW5k0vVre0v0gureWK4tpnt1huIJY5oXkjdWPWfCj4v/ABY+BHjOw+IvwU+JPjT4VeOtOK/ZfFHgTxBfeH9TaJW3Gzv2snS21jTJelxpGsW9/pV2jNHdWc0bMrVgK2Cw+KjLMcLVxWHV41KNOu8PUi+aL5ublbbjZr2blS5m7OpGxzcV5dxRm2RVIcFcRYDh7O6jp18HmmPyunneBq0eSf7iVGVWNOjGvOVOf132WM9lGEuTB13P3P6rvDf/AAaZa7JHG3i/9ufTLSQgGWHwt+zzJcorfxBLnWfi7EXA6BjaJnqUHSvRrf8A4NNfh8gH2n9uL4gStgZNt8EPCNspIzyFm8bXjAc9C55715l+wb/wc6a/o76L8O/+CgXgw69pmYLGL9on4VaKkOsWyklBe/Eb4WWKpbaggYq17rvw6NtLHEh+z+ArqRnlr+uv4N/G74R/tC+ANG+KXwR+InhP4ofD/X49+l+KfB+r22r6bLKqI89jcmBvP03VbPzEj1HRtTgs9W02cm31Cytp1aMfq2U5VwTm1NSwOFhOpFc08PWxOMjiaW1+elLEu6TsnOm50r6KbP8APXxH8RPpUeHWOdDivPq+FwlWo6WDzfLcg4Yr5FjmleKwuPo5DBRqOMedYTGRw2PjD36uFgmm/wCVrUf+DTvwqYmGjft0eMIJtp2DWPgP4c1CEt23Cw+IukuFPAO07uODzXg/i/8A4NQvjVDvPgz9r/4S+JAAxij8Y/CHxR4YJPJUST6R4t8ZAZPBZbV8DkKTgD+2+ivUqcF8OVEl9QlBrZ08XjIv7niHHp2PzrC/Sb8a8NPmfF9PErT3MTw9wzUTtb7Ucnp1Vt0qK93c/guH/BCb/gtD+y7df2x+zd8YvD99NZnzYE+A/wC0j42+F9/L5fzKH0jxbY+AdAmLAEfZ7i/uYX4RgwyDm/Ef9pj/AIOAfgn8MfHXwf8A2sv2e/iP8ffgh4w8JeIPA/j3S/in8ErL4naJf+F/EGm3GlasrfFj4Ei11ayvEtLh7jTte1DxNez6bfxW+pxhri2jY/3x0hAOMjpXK+DMPQUv7NzXNsvUk06UMQq2Gknpy1MPOMfawe0oVJyjNNqV02e5D6TGc5lVoT418P8Aw84wlh6lKrTx+Iyaplue0qlKSnCrhc3w1er9SrQklOnWw2Dp1aU0p05Rkkz+Er/gi7/wXB+FP7DPwWvf2UP2q/D3xPPhLQvH+va78OPG/hjRrbxI/gjRPFckGpa74R8VeGpb/SvECWll4pbWfEltd+HtL1e6d/EWo20ujwJbWxl/sS/Zx/bZ/ZQ/a40r+1f2dPjz8PPiiyQC4vdC0TW4rXxlpEW1WLa74G1ddO8Y6EFDAFtW0OzQkNsZgpNfh5/wUw/ZZ+CPhz/gqv8AsQfHv4xfCjwT8RPgP+2Paav+xv8AHHRPFeh217pEPxLubS4vvgr4wa6kjSXSvFWpX02naPZeINOurHVrPSPBt1awX0K3bltP48/8GzP7KXiTVh47/ZP+LXxf/ZL+IunTvqHh2XR9dv8Ax/4Q0e+XMlu2nR6xqulfEnRWEuFW50n4mwi1QhorOQxiN+fKnxJlsMRgKVPBZth8prRwcaNSo8DjZUPYUa2FnRqP2uGlSlQrRjGNWXPCdKpR537NSfvcfx8D+OcRlPF+YYjijw5zrxAy6rxFWzLCYWjxXwnTzZZljcrzrCZjgqKwWeUcdRzLAVa9WvgKLo4nDY3D5i8JCeK9kv6VAc0V/KJafGn/AILr/wDBKkBP2gfh7Zf8FI/2XdDOb34i+Bb/AFDWfin4a0K3XzJ7y+1e10T/AIWJaGztQ015cePfBHj7RIyhhk+IFjEpul/ZT9hf/grB+xp/wUB0+Gy+DfxEj0P4ow2bXWt/BD4gi08NfFDS/s8e6/m0/STeXWn+MNKsmDi41vwVqev6faIFGpyabcMbZPo8HneExVVYWtCvl+Oa/wByx9P2Fafd4eTbo4qKf2sPUqaayUT8V4l8LOIciy+pn+W18r4x4Tg0nxTwli1muW4bm1jDN6EYU8yyKuouKnSzfB4SKnJU6dWq9TrPCPiiPQf+Cm/xv+HUTBY/iD+xh+z/APFQwDgf2p4G+MHx58A6rfBc48260vxF4Ts55Mbmi0yzjY7YYwPnf/gsZ/wS58J/8FH/ANn64Xw7Y6Ro37TXws0/U9W+CXjW6ENouqu6i51T4WeK78gF/B/jMwJDBcXLMvhbxGNP8R2x+yJren6vF4a8THX/APgvF8S9FtX32/gL/gmH4N0nUwpysOp+I/2j7jxHaRSY4Ej6dMk6A8mNyR8pr9iKmnh8PmeDzHBYmCqYaeNxtGS2aarOblB68tSnXlKUJrWFSKktVc0xed5zwJxPwXxTkGKqZfnmE4Y4UzWjWjflcv7KpYaFGvSvFVsJjMto0aOKw8/3eIw1apSmnCoz+Zf/AIN4P2+vFnxD8A+L/wDgnx+0dJq+jftEfsppeaT4VsfF++18Taz8LfD+pp4au/CWqQXeLp/FPwZ1wQ+E9ShkLSnwtd+F3RZjpup3jf00V/KL/wAFvP2b/Gf7Gf7RfwX/AOCzn7LeitB4h+G/jbwzpn7TXhnSVeysvE2lXpg8K6f4o1cWwVV07xx4eu5/hJ48uXBAn1HwNraQm8t9U1Cv6aPgh8YfBH7QPwh+G/xt+G+qJrHgb4o+DtB8a+Gb9SvmNpuvafDfR215GhYW2pae8smn6rZMTJY6la3VnNiWB1HPkNbEUPb5JjpupissUFQrS0eMy2pdYTEK7u5U+WWGrW5uWdOPNOU5tv3vF/Lcozj+x/FbhXCwweQcevEvN8rotSp8N8cYJU58Q5O7fw8NjHWpZzlbqcjr4XGVXSo0qNGNOHqVFFFfRH4kFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRSAg9CD9DmloAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooyD0OaKACiiigAooooAKKKKACiiigAooooAb1xgcYzz+gxzznvjp606mjtgcYHXtjoO/Oep9B606l+P5aP56r8/wAooopgFFFFABSE4BPoM44yfYZwMn60teMftF/Gfw7+zr8BfjF8ePFjIPD3wh+G/jD4halC8nlG9Twtod7q0GmQuSP9K1W6toNNs0GTJd3cMags4qZzhThOpUkowpxlOcntGEE5Sk/JJNvyRvhcLiMbisNgsJSlXxWMxFHC4ajDWdbEYirGjRpQXWVSpOMYrq2kfwl/wDByD+15P8AHz9tuH4DeHtWN18O/wBk7RG8KyW0EzPZXvxe8Y22n638QtQYDEclxoWmJ4X8GFWQvYajo3iGGNgLucP/ADyyusMUkrkKkSNI7MeAqAsSSfp+HXIAzXYeNPGHiX4k+MPF3xF8aXsmpeMPiD4p8ReOvFeoyFme98SeLtXvNf1u5YsScSalqFyY1JxHHsRcKoFfXX/BNz9lY/tnftt/s/8AwBv7WS68IeIvGUfib4mBCUVfhd4Ct5fFvje3lmU/6ONd03TF8LW8/IXUNfslGXZVP864qvXz3OKlSKbr5jjIwowlf3FVqQo4ek2r2VOm6UG9lGDkz/azhvK8n8JvDbA5fWnCllfBfDVXFZpiKaS9vUweGq5hnGNhFtc1XG4t4rEwg2nKpWVOO8Uv2W+Bn/BGLwT8M/8Agk78f/29/wBo6xufFXxu8VfsueM/iR8Evh5ftc2vhf4O6BrXhmW+8J+LdU02OdG8QfEzUdHuLbX7STVDJo/gyK/tra20ibxLZPrNv/MMjngE7unfPbnn3OMdvpX90f8AwcAf8FTfhr8Evg541/4J+/B2LQvFvxg+Kfgw+Efin9kMMnh34H/DLWrKGGXS72CzKRf8LA8T6K4tvDfhxCn/AAjuiXI8T6rHAsvh2y1f+FdOBjB69/oOvOf/ANdetxVQy3BYnC5flzhL6lhVRxdSKTlUxfPKVSVWpe86zTj7SzkqSUaEeSNL2cPg/o+5zxzxRw3xBxlxvTxOHXFfEVTMuGcHiJuMMLw5HCYajgqOAwto/VsvVRVXhqkqcKuY+9mdR1njI4rEaVra3GoXVnp9nZXOpX+oXlrZadp9laz319f6hdzpBY2VhYW0ct1e311cyRw2lpbxSXE9w8ccMbysin+nX/gnh/wbd/F742RaN8Uv24NR1/4B/DO6SC/0z4N6G1pF8bvFdo6pLGfFl7dQ32mfCrTZ0ZRNpc9nrPjZkE9ne6b4PvFium/Pf/gg7rWi6N/wVY/ZW/t23sbm21a7+J2g2X2+3huI7fW7/wCEXjibQ7q2E6OsN/FqNpAlncxhbiGaQGB1dgT/AKKH7RPxVsfgX8AfjZ8aNRaNbL4T/Cn4gfESYSkBJf8AhDvCuqa/Hb88FrmWwS3jX+J5VUcmvX4O4eyzMMNXzXMZSq08LXqUnhr8lFKlSpV3VrSi+eorVPdppwh7suf2qlyx/NPpLeNXHHB2d5P4fcF0aOX4zPspweP/ALftHEZi5ZjmWOyyll+V0atN4bBVPaYLmq42ccTXf1ik8IsDVo+3q/5gP7e2jfBfwn+2T+0b4J/Z78K2Hgz4MfDL4i6l8KvA+kWGpaxrKXEHwwt7XwX4g8Q3es6/qOravq9/4m8XaP4h1671C+1G5eY30ccBgtYre2h/cG3/AOCgVr/wSt/4JSfAX9mD4Aajax/to/tOeEtR+P8A8RtfhNteSfAzw38Z3/tbwv4k1O3IkSL4i6r8Nk8H6b4G0O+R5dLtLB/GWr2y2h8PWeu/zEX2oahrMt5quszyXur61dXmsaxdTMZJbzVtZuptQ1S5mc5Z5Lm9urmaVmyWd2JOTUeo6lqetX9zqus6hfavql40LXeo6ld3F/fXLQQRWlv591dSSzyLb2kFvaWyM5W3tYILaEJDDEifK4fN6uDrZhicJTjh8RjoVaNOdNRgsHRxFZVqyw8IRiqVRQhChRlBRVClKp7O0+Vx/oTN/DfL+Jcs4MyLiPF1c3ybhTEYDMMfhMa6uKqcT5nlGWvA5dPOMRiKtSpi8K6+IxOZ5jQrurLMsbTwixUqmH+tU65e6hqGqX19qmq317quq6rfXep6pqmqXdxqGqapqeoXEl3qGo6jqF1JNd32oX91NLdXl7dTS3FzcSyTTSSSOzH+pz/g3+/4JEWnxm1TQ/26v2m/Ci33wp8Oambv9nj4deILLfp/xG8T6TdGM/FXxFp90hj1DwT4Z1C3eHwXptxE9p4l8RWsuv3Kvo2i6bHrv5mf8Ed/+CaOq/8ABRP9oxbbxdaajY/s1/CCfSvEPxv8QW3m239vvPI1z4f+Eui38ZRo9Z8afZpZNcuraRZ9B8HwalfJJDqWoaCt1/pN+HvD2heEtA0Twr4X0jTvD/hrw1pGnaD4f0LSLSDT9K0XRNIs4dP0vStMsbZI7ezsNPsbeC0s7WCNIbe3hjijRURQPq+CuG1jKizfH01LC0ptYSjUV1iK0HZ1pJ3UqVCStG91UrqV7RpOM/5z+lP44T4awtXw34Sxjo5/mGGh/rJmOFqKNTJsrxNNSp5Xh5w96lmOZ0JxqV6kXGeEy6pHkvVx1KrhfGPj1+yr+zh+1D4ck8KftB/BX4dfFrRjDJDbL4y8NafqWp6T5p3PN4f18RxeIPDd3nlb7QNU029Q8x3CHmv5rP2wf+DXX4b+II9T8V/sR/FnUPhrrLedcxfCT4x3WpeLvAFy7M8gs9C8f2sNz478LRqoEcR8QWnxDV3Kq0tpGGkH9aVFfpGY5HlWaxax2DpVZ20rxXssRHty16fLUst+WUpQbS5os/h3grxV4/8AD2tCfCvEuYYDDKanUyqrUWNyavreSq5Vi1WwXNNXi69OlTxMU26VanK0l/lHftTfsM/tW/sWa6uh/tJfBfxV8PbW5u2stH8aCKHxB8NfEk2AUXw/8QNBlv8Aw1d3M0ZWRdKur6y1+BHAvdItJAY6x/2Vf2xf2kv2JfiEvxK/Zr+Jur+BNUuJbf8A4SPw42dW8AeO7O2bK6b458F3T/2Rr9vsLRQah5drr+lrI02i6xptyROP9Wbxb4P8J+PvDmr+D/HPhjw/4y8J6/ZyafrnhjxTo+n6/wCH9ZsJhiWz1TR9Vt7rT7+1kwN8F1byxsQCVyAR/MN+3t/wbSfCD4kQ618Qv2GNftfgf47cXF/L8G/Fl3qep/BnxDcFfMa18OaoRqXib4ZXU7iTyYoF8S+Eo3eGztPD2gWnmXcX51mXA2Y5dUWMyHFVK/sm5xpOaoY2k11pVIOFOq92+X2E9oxhVbP7P4I+ldwhxjhJcM+LORYLLIZhTWFxOOhhp5nwtjlNx93MMuxEcTi8uhKai1JvMsPGf76tXwkIKUfrX/gmb/wXh/Z8/bfk0H4T/FyLS/2fP2nL3ybG08IatqhPw8+Juo7FUv8ACzxZqTRFtUu5Azp4B8RvB4mj3rb6Ld+LkiuL5P3nBz+v6cf57jvzX+SD8f8A9nb42/su/EfUfhN+0B8NvE3ws+IOkN9qTSfEFuiRanaQ3Bjt/EPhPX7Ca60TxRoMtxFmw8Q+GtT1CwFxH5Iuo7uKSGP+hX/glX/wcKeO/gVP4a+Av7c2sa78S/gshtdF8MfHSRLrXPiX8L7b5YbW38drGs2p/EjwTZrsRtYVbnx54ftVLMfFllHb2Gn+hkHG8vaLLuIIvD4iElSWMnB0rTVo8mNpWj7GalpKsoxgr/vadJRlUfyHi19FejLAz408Ha0c4yjEUfr8uGaGKWYTeFmuf6xwzmEalV5nQcbuGX1qtXFyUX9TxWNqVKWDh/dTR6+3+ArlvBPjfwh8SPCfh/x34C8S6J4x8GeK9Ks9c8NeKfDepWmr6Druj6hEs1lqWlanZSzWt7Z3MbBo54JGXIaNtssciL1P9a/Sk1JKUWmmk007pp6pprRprZrTrqfxBUp1KVSdKrTnSq0pyp1KdSMoVKdSDcZwnCSUozhJOMotJxkmmk00fmH/AMFiPglq3xq/YA+NsvhGGRviZ8FLXR/2k/hPd26l77T/AB98CNSh+IFm+nKAX+3anoela94fgEZWRv7YZFJ3bT9z/Ar4o6T8b/gp8IvjLoTRto/xW+Gngb4i6b5TB0Sz8Z+GdM8QwQ5BPzQpqAhdScq6Mrcg16RqWn2eradf6XqNtFeafqVnc2F9aToJIbqzu4Xt7m2mjb5XingkeKRGyGRyDwa/OX/glDBeeE/2RbT4FapPLcav+yv8Yvjx+zLctOxaUaN8KPit4n03wCzFiW2XPwyu/BV7bE4D2lzbyJ8jrXm8nsc3VRK0cdgHCo+ntMBXUqPX46lPHV7tK7hQSbtGKX2SxLzDw+lhKj5qnDPFUMThFvP6lxZlkqWYX0bjh8LjOF8s5U2oxxGZ1HGPNWm5fpPgV+Q37bv/AARb/ZC/bE1SX4m6NpGo/s3ftK2V6mu+H/2hvgWE8J+KU8TWrtcWOteLtE0yXTNI8ZXUV1sml1mRtH8cosawaX430hCWr9ea+Q/29v2mdL/Y8/Y9/aA/aK1CWBLz4c/DzWLvwrbTuirqnj3WFj8PfD/RwrkeZ/anjPVtDspVUMy2800pXZGxG2Y0cDWwld5jRpVsLRpzr1fax5lTjSg5yqRkrSpzhGLlGdOUZxavGSepx8GZpxXlnEWWR4MzHH5dn2Y4zC5Xg/qNWUHjK2OxFPDUcHiaLUqGMw1erVhTq4XFUq2Gqxk41qM4to/k/wD+Cdf7ZnxE/ZH/AG5/21vjL+2JffEL9pj4Z+HNb8E/sd/FX9uLwb4duNY8P/De/wDhbq2u6P4W8RePvD2nWUviB/B/iW30RLTXPFqJqF/p2paRZ3moz+ItQ8RRz3P9qvgvxr4Q+I/hPw/478AeJ9B8aeC/FemW2teGvFXhjVbLW/D+vaTeIJLXUdJ1bTpriyvrSdeUmt5nTIZCQ6so/Dj/AIN4/wBn0+CP+CaOh+MfH+nW+t+IP2r/ABr8QvjN4yXXbOG+PiDQfEdyngzQ49YgvI5ItQsPEHhjwxB4gkt7lJbe6j8TXRdZEuXDeq69+yT8Xf8Agnl4v1v44f8ABPXRdQ8afs+63qd14j+PH/BPRb9E0q6W4c3GufET9kG71O5Sy8AfEu3QSX158J7ia38D/ESKI6Tpcvh/V4fD8SfP5H9ewGWYTEVIzxWDxcZY2rTXPUx+C+tzliOe75qmYU+Wop1lNvGwqe0lB4tShRpfsPizU4U4v484hynB1sNkXEPD1ehwtl+NcqGE4U4njw1g8PkioOlCNLCcJ46dfA1aWXVcOocM4jDvC0cTDJJ0q+Y479W/ir8MfBXxq+Gvjz4R/EfRbfxF4D+JPhPXfBfi3RLniPUNB8RadcaZqMKSYL21yLe4eSzvYdtzY3aQXlrJHcwRSL+AP/BDHxJ40/Zd+JX7YP8AwSR+MOrXOoeJf2VfHl38Svgdq+oDyn8XfAX4jX0F8mpabCWKxWUOo6voHiya2hMi2N/8SL/TGdTpTqv7wfAz45/DP9o74Y+G/i58JPEUfiPwb4mhnEMrW9xp2raNq2n3EljrvhbxToV/HBqvhnxf4Y1WC60XxP4Y1m1tNY0HWLS60/ULaKeEg/jh/wAFNfCy/swfty/8E/v+Clvh9P7N0W1+I1h+xx+09dwKqW918JPjbPe6Z4J8S63s2BrLwT4t1G+uZ7u4Zybu58MwBlFnAo9DM+SnPL86oSjJYWpGnXnBqUK2WY6UKdaTlF2lDDzdHHRldpRoTtpN3+S4DniMXhOMvCzNqNahPiDCVsblGExVOdKvl3HvCtPEYzLKcaNWPPQxObYWnmXDFenyRqVKuZYWNS31eHL+9dFNQkquc5xg57kcE9uD1BwMjsKdXun5EFFFFAHJePtcvPDHgXxp4l05IJL/AMPeE/EeuWMd0jyWz3mlaPeX9qlwkbxO8DTwRiZUkR2jLKrqxDD+F/T/APg5O/4KIXllY3beH/2Y1a6sbS4eNfhh44KrJPbxSuqlvizuKqzkAlskDPHQf3EfGAbvhL8UF9fh540H5+G9SFf5OGktt0vSx2Gm2H1/484cY6d6Ur2Vt9fw5f8AP7rh1/r8tn/Xdn9C6/8AByL/AMFDif8AkX/2Yu33vhf46/Hp8XRx/L1rc0b/AIOUf2+NPu4ptY8AfsveILNWBmsR4G+I+jySpxuWO+tfirdm3cjO12s7hVJyYnA2n88/2J/+CYv7UH7ffhbxx4x+AJ+GQ0b4eeKLHwh4iPjzxlf+GbwavqGiWuvwNY2tl4Y14XVj9hvIVe4aWBxcb4kgdUaQeiftS/8ABG39u/8AZI+Gur/F/wCI/gTwf4p+G/hqNLrxb4k+FXjMeL28Iae8ixHV/EOiX+keHPEEWiWzsp1HWNN0vVLDSYCb3V5rCxjluUi8nrey0vpe1rapK91/wU7WHZed3/wLfrtvof0SfsY/8HGHwQ+NnivQ/hv+018Pv+GcfEmv3Nrpmk/EK08TjxZ8ILvVbt/Jgg8Qapd6XoeveAUvLh4obe91Wx1nw7bySB9X8S6VAPOr+kGOWOZI5YnSSKVFkikRg6SRuu5JEZchkdSGVgSGByCQQT/klMqsrI6qysCrKwDKykEMpByGUgkEHIIPcV/oEf8ABAr9pLxF+0H+wNoOi+M9Vudb8WfAHxtrfwSuNVv7iW51HUfC2iaXoXiLwDNezTPJJNJpvhHxJpnhhJnYyTR+HRNKzzSSSO4yu7N+a28tNFr1a7JO7bsK3VfP8Pv8uvTbU/bGvwS/4Laf8FQfjb/wT1l/Z18P/APTfhpqnij4rH4k6x4qHxH8P634it7Dw54NPgyx0s6ZbaJ4q8Ly21zqGqeJ7kSz3Mt3G0OntHFCjlpF/e2v4Rv+DlT4h/8ACV/t7+CvAsM2+1+FX7PXhG0mhDZWDW/G/izxd4mv8rkhJZtGg8MM44LRrCxGNpFSdk2Frv5bd3dW/UaP+Dkn/goTgD/hGf2ZM45P/Cs/HXX6D4tAf57V9x/8E1v+C5/7Vv7T/wC2p8Hf2fvjpo/wRs/APxSXxroovPBHgrxN4f8AEFt4m0vwVrvirw4YdR1b4geIbL7NdXXh+TTbi2bTHkn+2xmKaKSNd/8AI8CDjnkjIB64+lfTH7F3xGX4Rftifsq/EyWb7PaeDv2hPhNqGpy7iipod94y0rRPEO9gRiNtB1XUklyQvls275cg5KTbSb6rbfddv6ezuH9dT/UgU5VTzyAeevIzz715d8cvGerfDj4KfGD4h6BDZXGu+A/hb8QPGeiwalFNNp02reF/Cera3p0WoQ281tPLZSXljCt3FBcW80kBkSOaJysi+oqMAD0Ht/TAx6cDjsK8D/au/wCTXP2k/wDsgXxi/wDVd+Iq2F0V/Lfe+m/zP4vLX/g5P/4KE3FraXDeFv2Y0ee0tp3VPhr47Kh5oY5GC7vi0x2gsQMsSfWpG/4OSP8AgoW3C+HP2Y0z3Pwy8dNj06/FvHHfINfz76d/yDtO/wCwfY/+ksNfpL+xn/wSy/au/bw8BeKPiV8A7b4ZyeF/CHjSfwFrEnjfxxceGNQHiG20PRPEUyWtjbeHtbaaxXTfEGmMt48kW+4kmhSJvs8jhJ7eav8Al/mP+vu/rXv1Pv8A8Nf8HKv7eOlahHP4l+Hn7Mvi3TdwM+nReD/iF4ZumQEFlt9VtfiVq6W7soKrJNpV4qFtxikA2n9tf2Ef+C+n7OH7VvirQvhP8W/DV3+zX8XfEd1a6V4Zi8QeILXxH8MfGmtXTRw22j6D47TT9Dl0jXdRuWKabovizQ9HivpWi0/S9a1XVLiCzl/lE/a7/wCCVv7an7EnhW3+IPxs+HWkXPw2mv7PSrn4h/DvxRaeNPDGianqMqW+nWXiVUttL1/w8NQupIrKx1LVNCt9Dur+e202HVX1G5trSX86ZAjqVYnnGCjsjqQQVdHQho5EbDo6FXRgGRgRkZ8zi3u+6fV9/LureXTQe+iX9d/6sk9fJ/63YOefXn/Pf86WvzB/4I6/tL+If2qP+Cf/AMFfH3jXU59a8f8AhaLXPhP461i7fzb3WNe+G2qS+H7XXNRmJL3GqeIfDcWga/qlxKTJcajqd1OxPmA1+n1a72fdJ/eI/nE/4LOf8FdP2gP2Cfjj8KPg78AtH+FGpy+JfhVe/EbxpdfEbw34i8SXVs2o+Lb7w74ZtdLXQ/GPheKzjaPw7r814LuO9knL2phaBY38z8cv+Ik3/god/wBC5+zH/wCGx8c//Pbrwv8A4L1/EU/EH/gp38bLOKc3Fl8MfCvwq+GFkQ25Im0/wXZeM9WhXkhTFrvjnU4pFB4kRg3zDA/HPvjvjOO+PXHpWUpO7s9n+Wn9d+pajZJ2bbff0+66X4uTd2f2df8ABJP/AILT/tLftlftcWn7Pf7QGh/B6z0HxP8ADfxpr3hXUPh94U8SeGtYTxb4TfRdVW0u59Y8ceJ7S80+68NnxDM9tFY21ylxaW8y3flRywy/1HV/ml/8Eo/iGfhb/wAFHf2PfFDTi2tr74vad4BvpGfYhtPijpOrfDnZKeB5ZuvE1o53fKGRSQSFFf6WlVB3Tvvf9F934dbKwmttLbq2vTrr62+QUUUVZJyfj3XLvwx4G8Z+JbBIJL7w94U8Q65ZR3Ku9s93pWkXl9bpcJG8bvA00CCVUkRmQsFdWIYfwp2v/ByT/wAFFbyzs7r+yv2a4mubO1ndE+Fvi4qsk0EcrhTJ8UWYqCx25JOOcg8D+5L4xZ/4VJ8Usdf+FdeNv/Ua1P8Aznt1r/Jw0zjTNMA4A06xxjt/okNHZer+7l8vX9LdVu35Pu+yfe39Pu7/AOgv/wAES/8AgoT8ff8AgoD4B/aC8RfHy3+H0Gq/DHx/4R8O+HD8P/DWpeGbR9K17wo2sXQ1K31LxH4je6u0von8qeKe2RYGEZhZhvrgP+C3n/BTH9o7/gnvqX7N9h8AbL4Y3K/Fez+KV14ol+InhbWvEzxt4Nm8BR6SmkDSvFfhpLJXHiXUTfNcrfNNi1EP2fypDJ8sf8Gt/wDySj9sX/sq3wy/9QG8/wAK8e/4OoBjXv2JW/6hfx8X/wAmvhHn8s/rU3tG/W1++u/5/h5D3t6r+uh8kJ/wcif8FC9oB8P/ALMzMAMsfhl425OOuB8VwBnnIB4ORjGK/oV/4Iwf8FJ/iF/wUI+HHxmT40WHgfSvix8JPG2ixT2/gLS9S0HRNQ8A+MtENx4X1EaVrGveI74X8OuaD4w02/uU1I20kdrp5FvBI7eZ/n4p1P0/z/Wv3M/4N7/jyvwi/wCCg2j+AdSvBbeH/wBov4e+KfhnKksnl2x8XeH4h8QvBlw4yFa5ZPD3iXQbHcCzXHiPyUwZeS9pWb6bebtp+uvf7w/uh+MnizU/AXwh+KvjrREtJNZ8F/Dfxz4s0iO/iknsX1Pw54Y1TWLBL2CKWCWa0a6s4hcxRzwySQl0SWNiHX+HO1/4OSf+CidzaWly2lfs1I89rbzOifCzxeIw8sCSMF3/ABTd9uWP8ZOB1Hb+2X9poZ/Zu/aDHr8EPiwPz8B6/X+VBpi/8S7TsZ/48LHHvi2jH+H4/jQ3a2tvu7rvddddGB/pl/8ABLr9pv4kfthfsR/CL9oP4tweGbfx943u/iHBrkXg/SrvRfDwXwx8SfFnhXTDYaZfaprV1bE6To1j9pEup3RluvOmVo0kWJPxJ/4Kt/8ABaP9sL9jH9tbxn+z78G9L+Ck/gTw74J+Guv2k/jbwP4j17xDJqXi/RZ9S1T7RqOm+OtBtGtUmWNbWFNNSSNAweeZjlf0w/4IJf8AKLX9nf8A7Cfxj/8AV0+P6/li/wCDg7/lKP8AFT/sl3wMP/lqXA/p/nu3sraXUPxSv+fr5iS/Xq/18j2df+Dj/wD4KIdDov7MxPTP/Cr/ABpyfoPisMfp16eky/8AByB/wUORgzaB+zHKoOWV/hj45UMM9CY/iyrDPTgg/jzX40fs+/Ajx/8AtMfGbwL8B/hcmhS/ED4j6jqOl+GI/EmrtoWhyXemaFq3iO6S/wBVFnfG0U6bo16YCLSdprkQ26oGlDD9a7//AIN3f+Ck9pYXN7Do3wK1We3gkmj0jT/i9KupXskalltbOTVfCGl6QLmYjZCb7VbG03kGe7gjy4huT1T03032Tt5/8On2H/X9fcfcfwA/4OdfF8Gs2Ol/tTfs5eHr/wAPTzQQ33jP4D6xqVjq+lQswSW9b4e+Or3UrfWlRSZZIbXx/pUyjK28Fy5SFv6mvgB+0L8H/wBqD4W+HvjJ8DvGul+O/AHiVJVs9W00yxXFjqFoVTUdC13S7uO31LQfEOkzsLfVdE1a1tNRspWjMsHkzW80v+XL8Rfh545+E3jfxP8ADb4meFtY8EePvBerT6H4p8Ka/bC11bRdTgCSm3uY0klhljnt5YL2xvrSafT9S0+5tdR026vLC7trmT9wP+DeP9qvX/g7+2cn7PGo6tP/AMKz/ac0bV9OGjzzsbDTPiv4M0O98S+GPENnC5MVtea14c0jX/CmotCivqbTeHVuGf8Asm0CNS2u99HdO6kktvm9b/J6NNW6/wBdP8rbX7H94VfK/wC3D8f7/wDZY/ZE/aI/aE0e002/174U/CvxT4o8M2OsJNLpF54rhsXtPClpqkNtc2dzPp9z4ju9LhvLe2ura4nt3khguIJXSVPqdeg9xn8+a/Dv/g4g+In/AAg//BMb4k6DHMIrr4s/EX4R/DS3XdhpopvGlj411SJQDllfRfBWpCQAEGMsG4NU3ZN9h7n4DL/wcj/8FDRgt4c/ZiYlVyB8M/HQUMQM4x8WM8ehZu/PSorr/g5M/wCCh0VtcyxeF/2YpJIraeSOM/DTx5h5Ehdo1OPi0G5cAHB78V+BVHHQ9DkEHoQeCDweo9jWfO9unXe/na+uvnr5jS1S80j/AFVf2d/ilD8cPgH8FfjLb/ZgnxV+FPw/+IbR2YItoJvGHhTStfubaBWeRljtbi/lt1RpZWTytrSOwLH2OvyM/wCCFvxEHxD/AOCYH7NYkuPPv/AGn+MPhTqILbngb4e+N/EGg6VC/dSPDkGiyIpxiKWMgbSK/XOtE7pPuk/vF6aLoux/Jv8A8FQv+C2X7Yn7Hv7bHxX/AGevhJo3wPufAngnS/hze6Rc+MvBPijW/Eks/iv4feHvE2pre6hp3j3Q7GWKPU9TultFi0uB4rXy4pHmkQytzX/BN/8A4Lkftn/tV/tr/A39nv4p6F8CovAfxJ1HxjZa7ceEfA3inRvEkC6F8O/F3iqxk07UL/4g61ZQH+09DsluBPpd15tq08SbJGQ1+VX/AAXpXP8AwVN/aI9tA+CZ/E/B7wfx/PH864v/AIIkf8pSv2Tf+w58Ssf+GW+I/wDTr7ZzgZIL/O0o+X8vb+ujutBLVK+un331+7y7aWtof6Oo6D6D/PU/zP1Nfzh/8Fr/APgqn+1D+wB8Zvgn4A+Alp8Kp9E8f/C/xF4y8QP8QPCGs+Jb8atpni620S1TTrjTfFvhyK0szZyyNNFLBdPJNhlmiA2n+jxeg+g/lX8T3/B0SM/tP/svHsfgF4vH0/4uPb5/PI/Sh/qvxaBapei/T+n3ON+Hn/BxT/wUA8SfET4deGNV0L9nF9K8UfEHwN4Y1U2vw28YW94NM8ReKtI0XUWs5m+J8kcF2LO+na2mlgnjin8t3glRTG39ylf5R/waUn4z/BgEcf8AC4vhTn6f8LA8OZ/nj61/q4DoO3HT0p/0vT8u+w/63f8An+O/mFFHr7/4Af0qvd3MFla3F5dSxwW1rDJcXE8rbI4YIUaSaV2/hSONWZzxhQT2oA/OL/gon/wU6+Bf/BOzwXpd544gvPHvxa8Y291P8Ovgx4av7Oz8Q+ILa0cwXHiLxBqV0lxB4P8ABFrdgWNx4jvLK+uLq98yy0DR9cvLTUILP+ST4v8A/Bwb/wAFHviVrN5deCfGfw9+A/h2V2Fj4d+H3w88P+I7y3tw2YRf+KPiXaeL7y/vlTaJ7vTrDQbSaQM8WmWqMYh+ef7cP7S2v/te/tV/Gj4963f3V5YeLPF+p6f4DtLiVnj0H4YeHby40j4f6HaRE7LeOLw/b22pX6RKi3euanq+pSqbi+nduq/YX/YB+Pn/AAUD+JWt/D/4J2/h/S7DwfpllrXj74g+NLu9sPB3gzTtUnubbR4bxtLsdS1TU9c12ayv00TQ9MspZ7pLC/u7yfTtOs7m+iycpN2V99LafPvrvva1tN2xJW1eumlt7W1urbv7l+P0p4N/4Ll/8FP/AAdqcWoS/tIReNbdZFebRPHnwu+F2qaPdKrKxhkfQvCnhrXLeJ8bWOn61ZShT8kinBr+in/gmr/wXr8C/tV+MfD/AMB/2lfC+h/Bf42eJ7q30rwN4n0C+u3+FHxK1u43JB4etRrM9xrHgfxdfuFj0fRNX1LW9M1+5P2PTfESaxPY6JdfhX+23/wQi/aY/Y1+DOt/Hm3+IfgD42+APBdva3vxDi8J6RrvhbxV4R0m4uYrSbxGmh6xc6ra694b0ue4hbWbyy1i31XTLJ21STRJNMtNSvLL8QlaaGWKa3uJ7O6tpobm0vLSeS2u7K8t5EntL2zuoWWW2u7S4SO4tbmF0lgnjjlidXRSFeUXrf0f9f195T5Wk0rer9Oje3m/w6/621fxr/twf8F5/wBuH9nr9sH9o74F/D/R/gFL4J+E/wAUNU8HeGZvEfw+8Vapr8ulWemaReRPq2oWfxE0u0u7sy30waW302yTYEXyiylm/o3/AOCZH7SGrftYfsL/ALPPxp8TXgv/ABtq/g1vDPxAvM/vL3x54A1XUPA3irVZ16Ry67qvh+fXzGuERNURUCptUfwQ/wDBVIY/4KS/ttH1+Pmv/wDpi8OY/wA+5rRvSNvtNfc9f8vvJP6Nf+CTP/BZX9rr9tf9sTQ/gL8ZdH+C1t4J1P4afELxdNd+B/BfiXQfEKar4WXQX01EvtT8d+ILIWcg1K4W7hOmGSQiMx3EO0h/2F/4Kq/tT/E79jH9ij4kftB/B+28J3fjzwl4g+GmmaZB420i/wBc8Ota+LviJ4a8K6qbzTdM1nQLyaVNN1e6e0aPVLcRXQhlkWZFaJ/5IP8Ag3cXP/BSrwu3cfAv4yfqvg4f1/ziv6UP+DgdSf8Aglp8dSP4PFnwNb/zNfgRf/Zqavbzt172/rYXf7t32X3b9D+eH/iJD/4KHj/mCfs0E+o+F/jMD8v+Fq5/X8a/Tj/gkn/wWt/aC/bB/azg/Z4/aO0z4S2Gm+Mvh54s1b4eah8PvCuveGdQfxx4QbT9butJ1GXWPGXia3vLS/8AB0fia/hit7a0niuNGU+dIkjIP40a+hv2SPjdN+zb+1H+z58eUmkhtfhb8WfCHiPXjEzK8vg6XUF0bx1afKQSt54L1XX7Ug8Hzeh6UPRejW79Frqunyb6D3/A/wBTKv4v/wBsz/gvj+3T8Df2sv2jvgt4B034BL4L+FHxh8aeAfDDa78OfE+q65Lo3hzUmsbObV9Rh+IunW13fyojSTzW2n2MRZsJbqACf7OLO7tdQtLW/sp4rqyvbaC7tLmB1khuLW5iWa3nhkUlXimidJI3UlWRgwJBr/MZ/wCClS7f+Chv7bY65/aZ+Kh/PX5WA/8AHqG9vN2/z/BMLfh/Wv8AwT+x7/giP/wUW/aB/wCCgvhr9o7Uvj7a/Dm3vvhT4o+HOleGW+HnhnVfDUEth4t0LxFqGof2rDqnibxK13cJdaRD9mlgltEjiZ0eKRiHFX/gt3/wUc/aF/4J76L+zXefAGy+G11d/FvxH8SdM8UyfEXwxrHiaKGz8I6X4SvNM/siLSfFHhk2ksk+u3f2yS4e8EsaQJEkBV3f4U/4NaCB4W/bbTpjxd8C2x6bvDXj9Tx2+6Prz6VX/wCDqBf+KV/Yhfnjxn8b1H4+Hvh6f6DPpimttN2tL93/AF8umyF9+6+drdd32ffZnwYP+Dj7/goiMhtH/ZoJHf8A4Vd4z/kPiqMfr+VSj/g49/4KH/8AQF/ZoP1+FvjT/wCewK/AzaS4UYUvIkaljtXdI4RdzfwoCQWbB2qCcE4B/cq3/wCDeH/gpDcQQ3EGm/AF4Z4o5om/4XBffNFKgkRht8CspDKwIIbBByCeCc1KT1smm/Py+at92+4/6+7+tTsE/wCDjz/goYwOdE/ZmH/dL/GxIPrgfFkfz/E4Of12/wCCNn/BV39qD9vL9oT4m/Cz456Z8I7Tw74R+DU/j/SJ/h74Q8Q+HNUbW4fG/hfw75V9c6x418T29xp7WOtXLeRDZ20ouVik+0FFMbfjAv8Awbv/APBSZeujfAM/91hvcfXjwIT37AnGcAnCP+wH/BFr/glt+1n+w3+0f8T/AInfH3T/AIbWfhXxX8E7rwJo7eC/Hc3irUW8QS+OfCHiCNLuyl8O6MttZDTtI1Am6S4uCbhUhEaRtHcXdJvmtZ8vdprt1er/AOC73Qn/AJdfNef9X21s/aP+C2//AAUw/aM/4J7ah+zbZfAPTvhher8W7X4sT+KJPiN4X13xI8DeCZPh6ukDRxo/i3wuloJB4o1L7b9qW+87Za+V5HlyGX8JP+Ikf/gop/0CP2aOcDn4W+MeD6/8lV/nmvtT/g6dB/tz9hw+th+0QPyl+DJP9P5d6/k7tLaW9vLOxgCm4vry1sbcO2xDPeXEdtAHcg7E82VN74O1ctg4xSlNqTVlZW8un9dAt6/e/L/L8+7v+/kP/ByF/wAFEw4L6L+zLKBgmNvhb41RW5GQWT4sBgD04IPOR0r6H+Ev/Bzx8etJ1S1i+On7Nnws8b6DuVL28+FPiHxP8P8AxDBGSBJc22n+Lbjx7o+pTINzx2UmpaFFMcRNqFuG81fma4/4Nyv+CjlvaSXML/s6X0yRM62Nv8WPEMdzOwXPlQvd/Di2shI5yqGe8hhyRumVcuPx2+OXwL+LH7NnxQ8TfBr43eC9R8A/EfwnLbjV9A1GWzu0ktL6EXOm6zo+q6bcXmla7oOrWx8/TdZ0q8u7G5VZYfNS6t7mCEk7a3fkunnfdff2H/XX+v8Ahz/Se/Yy/bm/Z7/bu+Gs3xI+A3iie+/si5g03xp4H8Q20ekePvh9rFzG81vpvi7QVubxLZb6KKafSNX0291Tw/rUEFy+katevZ3sVr9g1/m6f8Eif2mde/Zc/b4+BXiC01Sez8GfFXxZovwO+KGmGaWPT9X8L/EfVLbQtFvb+FWWOSXwl4zu/D/iWxuHVpbdLO/to2EGo3cc3+ih8UviFoPwk+GfxD+KniqVofDPw18EeKvHviCRGVXXRfCOh32v6n5Rf5fNNnp8yxA53SFVwScGou6v16/mn9zXXe4WS28vlotF/Xofmj/wUn/4K5/A7/gnpZ2ng6bSrj4t/tB+IdJGr+HvhHoOq22lxaNpM8kkFl4l+I3iSSC/TwloV5LDcDS7aHTdW8Qa89tKNO0kWCXOq2f8rPxS/wCDgP8A4KV/EPVrq88M/EX4f/BfRppCbXw78N/hh4Z1JbSIH92kuufEqDx1rF5OFAEtxFLp8Mr5eOyt1IiX8qPjf8ZfHH7RHxf+I/x0+JN9LqHjf4qeKtS8X668kryxWH9oSD+yvD+niQkwaN4W0aPT/DmiWiYjtNK0u0gjUBK+vP2Av+CZf7RP/BRDXPFqfCWbwr4P8B+AZ7Cy8Z/E7x7cajF4e0/WNTge8svDWi6bo1nfav4j8Rvp6/2jc2cCWWnaZZS2cmravp8mpaVDe5uUm7L5LVb630a6W3dl0trcS79O/XVdvv021se/+AP+C9f/AAU48EalBean8a/C3xMsY5Ukn0L4jfCjwJJp92gYF4XvvAul+BvEECuBt3W2sRlc7gOK/pP/AOCaf/BcT4Uftr+JNJ+Cfxb8NWXwO/aG1OKRfDenx6u+ofDn4pXNtA9zd2ngfWNQjt9Q0nxKkEU10vgnxALi8ubWCaTQ9e8QzRXNvbfzcft3/wDBEr9pj9hf4XTfG/UvGPgP4y/CrSL3TLDxnrngix13Qte8DHWL620rTNW17w1rgu4p/DV1q97ZaS+saVrl7cWV7eWrahpVpZSPex/j3pGr6z4c1jSfEXhzVr/QPEnh3VdP17w5r+lXElrqeh+INGvIdR0bWNOuoiJbe+03Ura2vLWaMhkmhQ8jILcmrfK6+S2/HXXXfoD1021T77NPq/Ly+4/1p6/kC/4KH/8ABc/9tX9lz9tb4/8A7Pvwz0b4D3HgT4X+JPDeleHZ/FXgLxTq/iKe11j4feEPFFydU1Gx+IWj2dzKmoa7eJC1vploEthDE6yvG0r/ANJv7C/7Qr/tWfshfs+ftAXS28es/Ef4b6JqPiuC0VEtbbxxpay+H/HVrbRJhYba28YaRrcNtD1igSNDkrk/wQf8FnAT/wAFR/2xj/1PHgZR/wCGa+G/+A/+vVN6JrZteWn9fhcD90/+CXn/AAWu/bA/bC/bT+F37PXxb0P4IW3gfxnofxF1HVbvwZ4K8U6J4jiuPCvgbWPEemCzv9R8f65YRQvf2MEd2kulztLbtIkckLlZB/V5X+ef/wAEFUx/wVI+AR9PCXxqx/4anxD/ACGc1/oYURd1+uuui7/p1u+ofL8/8woooqgCiiigAooooAaO2Bxgde2Og7856n0HrTqb1xgcYB56cdMD19T7U6l+P5aP56r8/wAAKKKKYBRRRQAV/PL/AMHMnxyl+F//AATkm+Gmm3pttX/aM+LvgL4bTRRvsnk8KaDcXfxL8USLghjbSDwXpej3gwVeHWvKfiXB/oar+JP/AIOwfihLqHxd/Y/+CkM/+j+Fvh98SPirqNqrZDXXjbxJoHhDRJ5UH8cNv4H8QxwM3Krcz7MB23fOcW4p4Th7MqkXaVSlHDLzWKqwoVErdfZVKj+XQ/bfo6ZBDiLxk4JwtaCnh8Bj6+e1rq8YvIsHiM0wrkrNNSx2GwsNdLzSe5/KeFJyOmdoGfbr0+n48V+lX7Av7ZFr+wN4N/aQ+OPgSLT9T/ak+InhLS/gH8BRfWsF/p/w30DV7tfFnxV+Lut2c6tHczaa2k+BNE8E6RL/AKPrviCXUJNRhudC0HWLO8/NjnP+f8f6U+2sr3ULy007S7C81PVNSvLTTdN0vTraW81LVNTv7mKz03TdPtIFee8v9RvbiGzsbWJHmubmeOGJWd0WvwnC4mtg68cRh5cteCqKlU3lSnUhKn7SC0/eU4zlKlLenUUKkbygj/WvP8jy3iTK6+TZzD22VYurhKmYYVyjCljcPg8ZQxzweKbTvgcTUw8KWPo3UcTgpV8LNqnXm19Ifs4fs5/Hf9vn9pfRPhN8Pzqfjb4qfFHX9R8UeNvG/ii9vdRi0XS5r9L3xx8VfiHrsxuLtrDTTfNe6hcO02pa3q13Y6JpUF3rOradZy+J/F74b618G/i38UfhB4lbzPEHwp+I/jb4ca3MIHtVuNT8EeJdS8N3V0ltIzyQR3kmmtdwwu7vHFOitI+3e3+jD/wRg/4JpaV/wT9/ZvtdR8b6VYTftOfGiy0nxP8AGrWwIrq48MxeQ114e+Eej3yhgui+BobyVdXktHaDXfGNzrmrme5sf7Fjsf4/v+C//wACW+CP/BT74z39pZG00D46aJ4L+OugkJtimuPEulP4Y8YujDCtLN468H+ItQuAMsDqSO/MgJ+pzThmrlOQ4PMcRzvHVsSli6d3bD0q9KUqVOSd71YSg1Wm7r2tVQjdU+ef4L4fePOB4/8AFziPgrJ1h48L5VkNV8P4yEYKeb4/Ksdh8PmGKotJKGBq4fEt5bQhGzweAljKnLPEvD0Pzz/Y4+LSfAf9rX9mX4zTzG3sfht8d/hf4o1mXcVUeHLXxbplv4nR3BG2OXw3c6rDJkgGORg3y5r/AECv+C+nxMPw6/4JV/tItaTmO8+IkPw/+FtlJE/Elv48+IXhnTNcjDL9+Obwv/biMB8rxs2flPP+bHLb+fBLCSVMscke5Tyu9Su4Y6EZyCDkEDHPFfvX/wAFT/8AgrG/7ZP7K/7FP7NXgq+nuLTwr8Lfhz8Rf2mtUkjlSTVPjrovhmTwrbeDYpJ4YXltfDk0eveLtVmga4sNQvfFXhqKKX7V4cuiyyHOaWAyTiLCVanLUxOHisJFfFOtiKc8JU5dVrCMqVVvpCnPW6jF14ueGOP4x8UPBXiDAYX2+EyPOa8uJK8oy9hhssyjE4HP8B7aooySjia+HzDBUoyt7TE4yhC8YynOH4TMdx9uOuB/nkmvTPgt8G/iJ+0L8Wfh98EfhPoT+JPiL8TvE2n+FPCulKHWD7besz3OqapcIrfYNA0DTob3XPEGqSDydM0XTr+9k+WAg+Z46fTJOeAP6YHWv7fv+DbT/gnfH8Mvhhfft4fFLQgnxB+M2k3Gg/Ayy1G2H2jwr8G2uI2v/GMEUyl7XVfilqNok1ldKiSr4G0vSJ7Oc2nivUYn8jIMoq51mVLBxuqKbrYqqt6WGhKPPJNprnk5RpUtJL2lSLkuWMmv0bxd8SsF4W8EZlxLXVKtmMr5fw9l9R2WPzrEwn9VpzimpPC4WEKuNxvLKLeEw1WnTnGvUoKX7tfsG/sZ/Dn9g39mfwD+z18PEjvX0O1Os+PPGD2yW2pfEP4kaxDbyeLvGuqBcur6neQR2ulWUkk39i+HbDRdChmkt9Lidvsaiiv6DoUaWGo0sPQhGlRo04UqVOPwwpwioxir3eiSV223u23dn+NGaZnj86zLH5vmuKq47MszxeIx2OxleXNVxOKxVWVavVm0kk51JyajFRhBWjCMYpRRRRRWpwBRRRQB8yftV/sd/s7/ALanwzvfhV+0T8ONI8deHpVuJdF1ORW0/wAW+DNWmiEcfiDwP4rsvK1nwvrcBWIm5065SG/hj+watbajpc1xYzfwVf8ABTr/AIIfftBfsDza38UfAD6t8eP2WoZpblviFpumqfG3wxsGkHkW/wAX/DumReVBp8G4W6/Ebw/bDwtcFBLr1h4OuLuy0+5/0cKr3Vpa31tcWd7bwXdpdQS211a3MUc9vcW88bRTwTwyq8U0M0TtHLFIrJIjMrqVJFfO57w1l+e0260PYYyKtSxtKK9rG3wxqx0Vekv5Ju8Vf2c6bbb/AGXwp8cOMfCjGRjluIeacO1qvPmHDOPqzeArczXtK2BqWnPK8dJL/ecPGVKrKNP67hsZTpxpr/Ng/wCCV/8AwV/+Mf8AwTl8UQeFNUTVPin+yx4k1b7X4x+Er3iPqfhK5vpA1/41+Ed5eypaaNrzA/bNY8MTTQeGfGmxvtR0rWng8RWv+h5+z1+0N8H/ANqb4T+FvjZ8C/G2lePfh34utTNpusaY7LPZ3kO1dR0LXdNnCahoPiPRrhjZ6zoOq29tqWmXSmK4gCtG7/y+/wDBWj/g3p0vXrfxT+0b/wAE+vDNro3iVFvde8dfsv6aI7PQPEwy11qGq/BNJHjtfDfiDiW5k+G7PD4c1klo/B50HUorfQ9c/nT/AOCeH/BR34//APBMz43XniDwjFqmseANV1mPSfjr8APEkl3o9j4pTR7hrC+dbLUIvM8F/FPw0EubbSteexjureeF9C8R2l9o8k9inxWW5rmnB+MhlOeRnWyyo2sNioc1WNKCaXtMPK3NOjFte3wrXtaKaqU43fJW/qHjPw/4E+knw9ifELwsrYfLuPsLTjLPchxHssHVzDEuDl9Vzeipeyw+ZVY05rLs9pSlgsx9nKhjqz5KmIyv/UZr4n/Z+0M+Af2pv23vBUMYt9K8b+Jvgv8AtH6XAOI/tHxH+Gq/CfxI8K8AmfxB+z7d6ndlRzc6qXcmSVifUv2Wf2o/g1+2P8FPCPx6+BXiiHxP4G8WW7KySBLbXfDGvWixrrXg/wAXaSJJJtC8VeH7mQW2q6ZOzjDQX9jPe6Vfaff3U02jnTv2p9P8QIAq+L/gFq2i3TdPOb4dfELRr/TYz/e8lfihq7pzkedLgYya/S5yp1lgsTSnGrS9rCrCpTkpQnTr0KtKEoyV1KEnWhJNOzsn2P4cw9DGZXU4myTMMNiMFj5ZfXwOJweLpzoV8LjMrzTAZliKVehUUZ069KnlmJouE4qUXOcWldn0BX8iX/Bxd8dPEX7SHxx/ZO/4JLfBS9a78XfE/wCI/gjxd8VjYv5q6VfeJ799A+F+j6okQ3RwaLpl34n+KXiC3nOyDTNN8JaoQI2DV/TJ+1j+0z8Ov2Pf2evih+0X8UrwQeFPhr4budW/s+KeKDUfE2uzslj4Z8H6J5wZZdc8V6/dadoOloUeOO5vkuLnZaQXEsf8qH/Bvv8ABP4h/tn/ALZv7Sf/AAVg/aEtv7U1S18TeIvDngG4njkfTG+Knjextx4qk8OefvEWjfCj4Y3Gj/D7w/EpKW9l4mFvG63OkSgeBxHXli6uC4dw7fts0qKeMlF60Msoy58RNtfC6/JKlTvaM+WpC6co3/XPBbK6fD2C4o8Zs3pQ/s3gHB1MNw3TrxvTzXjzNKP1XJcNTjLStTyv6zHMcZyXqYZzwWJUXThUcf6+fhR8OPDPwe+GHw7+E3guzGn+Efhn4J8L+AvDFkAoNvoPhLRbLQdKjcqAGl+w2EBmfG6SUvIxLMxPfEZBHHIPBpenSivqYxjCMYQioxioxjFJJRikkklslFLRLorH4JWq1cRVq169SdatXqTrVqtSTlUq1aknOpUnJ6uc5tylJu7k273PgD4m/BjxH+z78Vdf/ay/Zz0O/wBQg8XT211+1Z8APD0AaD4z6RYW62y/F74e6KjRW1r+0b4I0uJC62qwj41+FLJ/BGumXxVaeB9b0jW/bc+EHhn9uj9gb44/DfwbqNj4jsvjD8GNR174Wa9YN51rceLLGwg8a/C7XLCYqksXleLNK8P3YcCK5hUPFIiSB4q+6CAQcjORj/62f8+vWvD/AAt4cT4U+ONT0LS1EHw7+JOrar4k0OwViLbwj8Rb57nWfF2kWMZyttovj1zf+M7O1iCQ2PiyHxjI8mPEmk2Vtw1cHT5cRQavg8dCrTr0V8NOeIi4VJ019mOI5pe2gvd9tJVlFSqV5y+pwXEeNjiMnzWNVriLhjEYDGZVmLb9tisNlNWlXwmFxc9HWrZSqFN5fXm/arLqc8unVnRweVYaj53+wb8bpf2jv2M/2Z/jZeyGTWvH3wc8Ean4qDH54fG1no1vpHji0kBAZZbLxdp2tWkqP86PCyP8ymvrWvzz/wCCdHhpvhj4J/aO+A6xfZdO+CH7Y/7QWheGLHkLZeCPifrun/tE+C7SFOAlrZ+HfjPY2FsqhYwlmyxKFWv0MrTL51KmCwsqzvXVCnCu9f8AeKcVTr766VYzV389Tk4tw2EwvE+e08uhyZZPM8Vicqjo7ZVjajxmV7aa4Cvh3pproFFFFdh86eefF3/klHxN/wCyfeMv/Ud1Gv8AJs0v/kF6Z/2DbD/0khr/AFk/i7/ySj4m/wDZPvGf/qOalX+TZpf/ACC9M/7Bth/6SQ1FTaPrL8ogf2i/8GuLf8WK/a0j/u/G7wa//fz4a6WP/ZK/pA+OPh7TfF3wV+L/AIU1m3iu9I8T/C7x/wCHtVtZ0WSC503WvCeradfW8yMCrxTW1zLHIrAhlYgjBr+bj/g1vb/iyf7XSHgr8afAzY9j8OLNc/8AjnWv3W/b3/aJ8A/sv/skfHP4q+Pdf0/R4rL4eeLNE8J2NzdwQ6h4s8fa9oGo6b4P8I6BayOs+o6zrWtT2sKW1pHNJbWSXuq3Kxabp19cwONuVdra/qPqv+3fyXfT0uf5gdsu22tlyTi2txk9WxDGCx4HLHJJ5ySTk1/Zh/wa7Xcr/A/9rSwJYwW3xp8F3cYOdolvfh5awzYHTcU0+33d8Bc9q/jQgRo7e3jcgvHbwRuR0LxxIjEexZTiv7nf+Da34S6p4K/Yh8dfE3VrOW0/4Xb8cfEut+H2lQoL3wp4H0TQvAVrfRE8tDL4m0bxbFGwG10gEiFlcE5wWq62Wv5X+9r7xaa/h/wfkf0QV/mtf8FgPiJ/ws//AIKYftfeIEn+0WuifEmz+HFkwfekcPwt8IeG/AV3DGR8oVdY0HVHIU48ySQnkmv9JnUb+10vT77U76Vbex06zub+8ncgLDa2cL3FxKxJACxwxu7EkABSciv8nn4meObr4ofEz4kfE29dpLz4kfETxz8QLl3YszTeNPFWreJGJJyTgamF5J4UcnFVU6L1/T/P+rjS31t0V791/X4n014G+CZ1z9gT9ov9oD7D5lz8Pv2mP2a/A9vqBgUtbaPr/hD4wr4kt0uCC8Uc+r+JPh+bmJWCSypZNIC0cIr41uZ7mGGaeydory2ja5spUJWSK8th59rKhHKvHcRxuhHzBlBBBFf07fst/AP+3v8Ag3C/bO18acJNU8YfEbxr8adOuDGTI2n/AAN8R/DS3MsWBuKww/C/xLGrA4C3NwOATX8w2/k91OR6ZU/nnj69TUNNW6aX/Hv6WfS3ru1r21Vk72V1p83tof6sn7PPxEh+LvwD+CXxVt5kni+JPwl+HXjsSo25WbxX4R0jXJBkZ5WS+dGHUMpB5FYv7VY3fsvftIr/AHvgH8YR+fw88RCvhX/gh18Rv+Fkf8Ewv2Yp5rj7Rf8AgjQvFHws1DLbmib4ceNfEPhbS4X5JBHh6w0Z1DYPlyIQApWvu79qUbv2ZP2jF9fgR8XR+fw/8Qitlqk+6RJ/lbacudN04jr9gsv/AEmiH9K/ty/4Nij/AMYffHxe4/ae1U+/zfCj4W9fwFfxI6bj+zNN9fsFnn/wGi/z+df22f8ABsXn/hkL9oA44P7Tupgfh8KfhgD/AE/yKiDvo+i09NNAP2I/4KH+DdH8f/sIftg+Ftds4b6wu/2cfi9qEcM8ayLFqnh/wRrPiLQr+MMGCXWma5pWnalZzAb7e7tIJ4yskasP8vyKVpIopSTmSKOQ893RWP6nn9c1/qKft9eKNK8GfsPftfeJNauYrXT9P/Zr+NSPLM6or3N/8PPEGm6fbKWIDTXuoXlrZ28Yy0s88cSBndVP+XRboYreCM9Y4YkP1RFU/qKKnT5/oNaa9T+6X/g2Zv5bj9hD4mWTsTHp/wC1F48EKnOEW88AfC28dV7AGWSRzjA3Mxxk5P8ARTX8/X/Btj4SvdA/4J66x4gu4JIYvH37Q3xP8QaY7qVFzp2kad4R8EmeMkfNGNT8K6pAGGQWhYZyDX7T/tA/EGH4TfAf41fFG4lWCL4c/Cf4ieOWldgoU+FPCOr64vzHgFnsVVfViAOTVrZei/IHv8l+SP8ANA/bY8fr8WP2xv2rPiSkwubXxf8AtDfFu+0ycPvV9EsPGWq6H4f8t8ndGuh6Vp6REHb5SIB8oGe3f4BsP+Cbmn/tNLZL56/t3ar8HJL8xATHQrr4BaX4ggiM+3cbNPEOnTIke7y1uppMKJGNfG0UlxdQx3N47S3l2BeXkrnc8t5eH7TdyuSAS8k8sjuTyWJPNf01XXwDa3/4Nj7TxT9lzqf/AAty2/aOfCAyrbXX7Qf/AAr1L3HXH/CCTxys+T/oZJJ8vOMdXd9bN+pV1pbq0mm97W1267P8tz+bbwh4sv8A4feLvB/xB0tzHqXgHxb4W8dac6EqyX3g7X9O8SWhUjBDedpiYwcjPbNf6u3h7WrDxLoGh+I9LmW40zX9H0zWtOnQhknsNVsoL6zmQgkFZLeeN1IJBDAg4r/JrljWWKSJwCkkbxsOxV1KsMehBIr/AEuv+CXvxLf4uf8ABPX9kDxtPP8Aab2X4GeCvDOqTltzy6z4B08eAtZeQ5JMzar4avDNuO4ybi3Jqqe789fTZWQnqrt9dvktfyPvKiiitHt81+aJPOfjEcfCP4pHpj4deNuv/Ytan/n+fFf5OGmf8gzTf+wdYf8ApJDX+sZ8Zf8AkkPxU/7Jx43/APUZ1Ov8nLTOdM03/sH2P6WsQoejv2Uv0Et36/oj+zP/AINbx/xaj9sQ+vxX+GQ/LwBdnH1G4Zrx/wD4Oof+Q1+xIf8AqHfH3/0r+D4P8/f+Rr2H/g1vOfhL+2J/2Vr4aj8vh9OP6V4//wAHUIJ1r9iUDn/iXfHw/wDk58HqW0V6R+7S++hT0f8AX3fLY/lMyFJyeBgZ4x2HPPXGRxz147V6F8Kfidr3wT+KXw0+M/hhnXxD8JPiB4O+JWkpGxVri58Ga/Ya81gxHWHUrazn024TlZbe6ljYFHZT7L+w/wCAdH+K/wC2B+zv8K/EKK+g/E74k2Hw81fdGkvl2HjbTNV8N3FykbgqZrSPU2u7duqXEEUi7WRSPnfxP4V1zwJ4o8VeAPFdq1p4m8D+JPEHgnxNZyKVe317wrq934f1q3ZWAI2ajp9ymGAyuDjms27W8krPzsn/AEnffzGk3ez/AODqvw6/kf6gfxl8W6H4+/Y/+K3jvw1dpf8Ahvxp+zZ458W+H75CCl7ofiP4X6prGlXaEEgpc2F5BMpBIw4IJFf5ZWlD/iWacfXT7Mflbx/41/eZ/wAEvPjq3xs/4Il+JNOvrw3fiP4G/B349/AbXi8okmjg8CeDtbn8FCQEl1X/AIVzrXg5FZuHeOQqeCF/g00r/kF6b/14Wf8A6Tx05u6i+6v+RPT+rn+h9/wQTAH/AAS3/Z5A/wCgp8Yv1+NHj7/P/wBev5Zv+Dg4Z/4Kh/FI+vwr+Bh/Pwvc/wCFf1Nf8EFP+UW/7PB9dU+MX/q6PHw/pX8sv/BwZ/ylC+Kf/ZK/gb/6itzVt+6m+ij+FhK9n6yv/wCBf5nkH/BHf5P+Cm/7IDevxB8SD/vv4Y+PF/QH65z26f6QNf5v3/BHs4/4KZ/sgnv/AMLC8QY+v/CtPHX5461/pA0RVk/V/lF/qF9beV/x/wCGP4VP+DlLwvo2hft7eBde02xt7S/8bfs2eC9W8RTwRrG+qapo3jn4i+HLS+vGUAzXSaJp+l6YJn3P9i06yt93l28ar+W3/BOvWrjQv2/f2LNUtXaOWP8Aad+DtixQkM1rrnjDTdAv48gjiaw1S6hcdGSRlOQSD+s//BzY3/GbnwbX+7+y7oP/AI98U/ib/wDWr8fP2BDn9un9jPP/AEdN8CMfX/hZPh3HbHYdhUte830Tj97tf+v8yl+N1Z9v0+/b8v8AUQAwAB2GPyr+Uz/g6X+If2T4W/shfCKK4G7xP8TvH/xKvrUNz5HgDwrp3hjT5ZUHVGuviXP5bHjfC+ORX9WQ6D6Cv4Wv+DmP4ijxP+3H8Lfh5BcGS0+Fn7PuhTzwB8rb678Q/GnijVb8FeQkkuieHfDDtwGKGInKkVU/hfy/MUVZei/S39b2Pyq/YE+Ddn+0F+2j+zl8GtStku9I8c/ENLPXIJI/OibQtJ0PWvEOsNLGQweJNP0i4ZwwI2jJHGa+TdQ0u90LUNR0LUkaPUtC1G/0PUY3BEkeoaNeT6ZfI4PIdLq0mVgeQwIIByK/bX/g3p8AP4z/AOClXhTxB5HnW3wr+EHxY8dzSMgdbe41PTtK+HFmxJyEdj48uPKPXdGxXlSR8Af8FCPAA+Fv7dv7X/gWO3NpaaR+0N8TNR0y327BFovi/wAQ3PjfQ1RcACP+x/EliY8DaUKleMVm9Un/AFoo/rf/AII07Xfb/NH9SX/BsP8AEb+2f2YP2iPhXLNvm+H3x7h8VW0JbLQaV8S/A+gmIIuflil1vwfr8owADM8x5Ysa/plr+Kn/AINiPiMNG/aa/aR+FU1wI4fH/wAFPDfja0t2bAn1D4aeNP7Im8tc4aX7B8SWdjjd5UB7JX9q1aQ+Ff1Yct+2i03toj/PA/4L0DH/AAVN/aHPXPh/4JH/AMw/4RGPzWuJ/wCCJAz/AMFSf2Tv+w38Sj/5hf4jdun6HHUYIBHbf8F5zn/gqZ+0P7aB8Ex/5iDwkf61x3/BEOMyf8FS/wBlIAcLq/xPc9sBPgr8Rz/PAqV8UvWO9u6Xl/W77yf6N69B9B/Kv4o/+Dodf+Mnf2XDjg/AXxiPy+I9kf5H8a/tcU5VT7D+VfxUf8HQ2D+0z+y2B1/4UR41J+n/AAsOxI/kaqWib7W/NCWiXoj+e34ODHxn+DBP/RYfhVg+x+IHhyv9Wqv8pz4Of8ll+DP/AGWH4Vf+rA8O1/qx0obNdm1+Qwrxn9o27vtP/Z8+Ot/pnmf2lZfBz4nXmn+Vu803tt4J1ye18vZ83meekezHO7GOcV7NWdq+mWetaVqOj6hAt1p+q2N1pt/avgpc2V/BJa3du4IIKTW8skbAgjDHINWJ9PVP7mmf5JunnOnacR/Fp9kfztYv8/8A16/sx/4NdrrQG+C37WtlAIB4qg+MHga71Yjb9qbw7d+BDD4a8w/fNsup2fi37OD8oma8K/Mz5/lH/aU+BXiT9mL4+/F39n7xXbzQav8ACbx1rnhOKWeN4v7V8PW9x9s8HeIrdXAJsfE3g+80LX7J8ANbajHkBgwH25/wSG/b8tf2Bv2qIfEvjWW7PwM+Lel2XgD4yLaxT3MugWMN8154V+ItvY26STX0ngnU7m8/tK2t4prufwtrXiJbCC41JbK3kxT95Pskr/hd6/K/boV3+70f9J7n9/f7UHhNPHv7NX7Qngh9Nm1keL/gj8VfDQ0m3tXvbnUZNb8Da7p0Vla2caSS3N1cS3CRW0ESPLLO0aRqXKiv8zCw/ZR/awksLJp/2WP2mVm+x2vnK/wC+LSusxhj8wOG8IAhg+4NkA5znmv9Sbwz4m8PeM/D2ieLfCWt6V4l8L+JdLsdc8P+IdDvrfU9G1rR9Tto7vT9T0vUbSSW1vbG9tZY57a5t5HimidXRiDW5Wko8zTva1/ne35fqwT+a30du3b0/U/D3/g308IfEPwJ/wAE/wA+F/iV4L8aeAtb0/47fFaWx8P+O/C+veENbTR9Rfw/qUF4mj+I7DTdRWwu7671B7e6FqLe4cTtFI5VzX8ef/BVM5/4KS/ttD/qvev/APpj8Oj+lf6Z1f5mH/BVQgf8FJv22sd/j1rvH10Pw4CfzzSasoa7NK7/ADf3C/r+v62+8+3f+Ddz/lJR4Z/7IX8Y/wCXg6v6Uf8Ag4F/5RY/Hv8A7Gf4H/p8bfAJ/kK/mw/4N3R/xsq8N+3wM+Mn/unCv6Tf+Dgc4/4JZ/Hf38U/BAf+Zo8Cn+Yp3dm+tr+nupiW8vX9Ef59XTrTJY0mikhkXMcsbxSKRjKSKUdSCOMqxBBH4VX1HcunX8gyCljduCDgjZBI2R7jGRX3n/wUf+CcPwJ/ay8WaDp1obPw38QfBHwq+NvhSMRiKH+yvip4B0XXdXitUACC10/xxH4u0qARgIsVgigLjFQ5NaPXv1XTTTbZ3XX8Rn903/BIL4+N+0X/AME6/wBmbxrf3wvvE3hrwPH8JvGcjPvuf+Eo+Ed3cfD+8uLwklvtOsWWhaf4gYv80kWrxTHPmAn+D7/gpQwb/god+2ww/wCjmPiqPxGvSjr3wMV/RL/wa+fHLz/Df7Uv7Muo3p36D4j8K/HTwfZSPktp/i7Th4I8ci3Un5IbDVfCnhK5mVRt+0eITIwDykv/ADsf8FH+f+ChX7a5I/5ua+LX5DxJcBf/AEE/r602/dT+Xz5WvzGuvbS/po9Py/OzP6J/+DWoY8Oftuc9fFXwIP0z4d+IfFJ/wdPDPg79iT28b/G0/wDlt+AP58Uv/BrV/wAi7+25/wBjV8CP/Uc+If8A+ql/4OnMf8Id+xMD/wBDp8byPw8OfD8f1ql8Kt5d++vn30+Qj+Rpxxj0dPzEikfqK/1jfC7bvDXh1v72haQ356fbn+tf5OsxBEhHUEEduQ/rnqeMHn+lf6w/hRl/4Rbw0cgA+H9GIJOODp1t60076+S+btr8tl8mLqvR/nE6Cim70/vL/wB9D/GnUxn8gv8AwdOc6z+w97WP7Q35NL8G8/8AoIr+UbQOfEPhz/sY/D//AKeLKv6uv+DprP8AbP7EPoNP/aE/9H/Bwf1H61/KR4dGfEfhv28R+Hz/AOVmxx/PNRZXcn0at8kn+OwH+tbHyiH1Rf5Cv4zv+DovwrpFh8av2RvHNtaQxa94k+GPxU8K6teogWa90zwd4q8G6toME7gAyLp9z408QtAGz5f9ozgYDcf2Yx8RoP8AYX+Qr+NX/g6S8Q6dc/F39jrwpFcxvq+kfDj4xeIr+0VgZrbTvEfibwDpekXEqZ3JFe3PhnW47diAJH0+5CkmJgHP4X8rff8A5X+RVO2l9bLT1Vtu5/NR4BvZtN+IHw+1O3cx3Gm/EHwLqNvIpw0c9j4t0a6hdCCNrJJErKQQQRxiv9G7/grhqN1pf/BND9tO6s5Ghmk+BHi2wZ1JDfZtWjt9LvEyO0tnezxN2KuQeK/zsvgp4Vv/AB78aPgx4H0qB7jVPGXxd+FvhWwgiUvJJd6/440HTYlVV54Nzub+6iljwDX+iB/wWA/5Rk/to/8AZFNd/wDS3TaUNn6/1+QSvdbJbW03tHr13Z/m5NHuLEZ+9jjH+cdM/wD66/vM/wCDcrSNP07/AIJxWd/aW8cV54g+O3xg1PV51UCS7vbTUtK8P20szAZdodI0XTbRMk7YrdFGAMV/B4wAZgP7x/nX96f/AAbrH/jW3oA9PjV8ZwPx8SxMf1JpQv125Xy/JxT/AAJP0H/4KLaHpviP9gj9srSdXt47mxm/Zo+M9y0cqqyrc6Z4B1zU9PuFDAgS2moWdrdQOMNHNDHIpVlBH+YtGrSRxOerxxu3B6sik/qTX+rD8dfhZafHH4K/Fv4MX+s3fh2x+LPw28bfDi81+wtoLy+0S28aeHNR8Oz6rZ2lyyW91c6fHqLXcFvO6wzSRLHKwRmNfzRJ/wAGuHgWNFRf20viAQiqg3fBzwhnCgAdPFYGeOeDnuegFSTe1uz9NPy3/ID77/4N7NUuNQ/4JlfDW1nlaRND+Jfxt0m1DNkRW5+JWu6oIl/uqs2qTMF4xuPHNfyU/wDBZdt3/BUP9sg+njrwR+O34O/DnH8sV/dp/wAE/P2MNK/YJ/Zx0j9nnR/iBqnxNtdM8W+MvFj+LNX0Gx8NXd1ceMNZk1aW0GkaffajbQQ2AdLaOQXkr3GwzOEZyi/wjf8ABZM/8bQP2yvbx94NX8vhB8OwP0xSa0iuzje33B/X9f8ABPaf+CCy4/4Kj/AT28I/Gz68fCvxAv8AjX+hTX+e1/wQXGf+Co/wHPp4Q+Np/wDMXa+P61/oS046K39dH+v33D+vuCiiiqAKKKKACiiigBvPGBwQDz0GOg78579MAU6m9cYHGAeenHTA9fU+1Opfj+Wj+eq/P8AKKKKYBRRRQAV/nbf8HKHi+XxL/wAFQfE2iPIXi+HnwJ+DPhOGMlmWFtRTxL48lCg8IX/4TGJ2CkA/Kcen+iTX+ad/wX0v5L//AIK0/tWCQ7hZL8FNOjz/AAxW/wADfhxIE57b7h27DLH1NfC+IU2sjpQW1TMKEX5pUMTO3/gUIvZ7X6H9Z/Q1wsK/ivmNaUVJ4LgrOcRTb+zUnmWSYW683TxFSN+za6n5KqeD1wAOe+cc/wD1hz+WAP6Jv+DcD9i2x/aC/a41z9orxvo6al8Pf2ULLSda8PQXcIksdU+OHio3kfguVlfKTnwLodjrXi1Qp82w8Qy+DNQGNiB/52RgEj3H06ZHc+n48Z9v9EP/AIN0Pg9YfDT/AIJl/D3xhHbxJrPx28e/Er4ra1chFE0saeJrn4feHYnkADPDD4Y8CaRLChYojXU5QAyvn4TgvL4Y/PaDqRUqeCpzx0otaSnRnTjQV+8a9SnUs01JU2mrXP64+k9xjieEPCbNlgasqGP4nxmF4Ww9anJxnSoZhSxGKzOcXGzXtcqwOOwikmpU6mJhUi1KKP3XACgADAHav5Nv+DqL9mqbxF8H/wBn39rTQ9PMt38J/F+o/Cbx9dQRFpF8GfE37Nf+FdQvZAPkstF8b6AukQFyFW68chVIaUg/1lf/AF/5/wCf/rV80ftkfs5eHv2uP2Xvjh+zj4laGGy+LHw+1vw3p+oToXTQ/E4hGo+DfEqqFZml8M+LbHRNfiVQS8mnKg+8a/X88y/+1MpxuBSXPWot0L6JV6Uo1qF3pZOrThGX9xyR/mt4U8YvgHxD4V4qlKUcLl2Z06eZKN25ZTmEJ5dmloK/POGAxVepRi0/30KbVmkz/J1wPQUtbfifwz4i8E+JvEngrxfp8ukeLfBviHW/CPinSZxiXTPEfhnU7rRdbsJOuWtNSsbmAsCVby9y8EViV/OzTTaaaa0aaaafZp6p+TP9p6U4VIxnTnCpSqwjUhUpyU6dSE1GUJwnFuMoTTTUk3GSs1dWZ+gv/BML9ibUf2+/2w/hx8DJorqP4c2DP8Qfjfq1qXifTfhP4YvLL+2dPhuk+e21LxlqN5pfgnSpow0lnPrx1RUaLTZ8f6g2haHo/hjRNG8NeHdMstF8P+HtK0/Q9D0bTbeKz07SdH0m0hsNM0ywtIVSG1srCyt4LW1t4kWOGCKONFVVAH8V3/BqLYwy/G39tLU2iVp7P4YfBewhnKgvHDqHijx9czwq+CVWaTT7d5FUgO0EZYHy1x/bNX7PwFgqNDJvrkY3r46tVdWbSuqeHqzoUqSaS9xOM6uurnVldtKKX+Yn0v8AinMs18T3wzWqOOVcJ5Xl0MDhYyfJLF51gMJmuOxtSL09vVhXwuEulZUcFScUpTqORRRRX3B/KIUUUUAFFFFABRRRQAEZBB6Hg1/O/wD8Fiv+CHngv9tnTde/aC/ZysNE8AftcabYPd6nZ5t9H8HfH63sYf3ejeMpFWO10fx+tvEtp4a+ITBFnIg0Txo11o/9n6v4a/ogoIzXDmOXYTNMLUweNpKrRnquk6c18NWlPenUj0kt1eMlKLlF/U8G8Z8RcBZ9g+JOGMxq5fmWElZ8t5YbGYeUoyrYLH4e6hisHX5IqrRntKMK1KVLEUqNan/mP/8ABO39vv4+f8Enf2mtes/EHhzxZb+CZvEcfg79pz9njxDBLpOsSyaLO9ncarYaTqDxxaJ8UfBiSTzaHfOYbbXtPaXQdRupNI1O11Cx/wBEHwN8WPh38eR+zj8e/hH4n0/xl8OPiJ4Z8af8Ix4l0x2a3vtM8Q6Lp+ttbzRsqzWWo2d74NksNX0q9jhv9J1bTrzTL+3gvrO4hj/Lf/gsz/wRy8J/t7eC7/40/BjT9J8KftgeCNEK6RqOYNM0f426DpcJa3+Hvjq5Jit4dbghj8jwH41umEmi3Ji0PWp28MXIm0X+Kf4Wft8fte/sj/A74+/sbeHtd1XwN4d8b61qemeJNG8QWmo6f46+DPiqP7f4X+J9v4Ile5t5vBms+NNDkv8Awh42t5LeZoCsmraQuk+IVfVpfzqhi8dwVXq5bmCqY3KKvNiMurw3jOlJVXSSd1TdWSVOtSXuUqtSGIp3pzqc39rZlwxw19KfKcDxtwZUwHDPiVl31XJ+N8oxMn7GvgsfSeXLM5OnD2uLhgaM6mKy7GRiq2MwWGr5NXti8PgI0f1r/wCCxH7afj//AIKsftnfDT/gn/8AsjzP4p+F3hH4lx+D9Al06eSXQ/in8ZibrTPEnxK1G5tDJDJ8N/hTo39uw6Tq37y0Om23jHxfHPcWWo6Gbb+z39jz9l/wH+xp+zb8J/2b/h1EraD8NfDFtpt5q7wJBe+KvFF28mpeLvGOqhM51PxT4kvNT1u6UvItsbxbKBha20CJ+D//AAbrf8Ev3/Z2+Fo/bQ+NPhw2Xxr+NnhqK0+Fnh3VbTy734YfBXUvs19aX0lvMu/T/FfxOWKy1i/UItzpfhCDQNJL21zqPiKxP9O9fTcM4DEuWKz7M0/7RzWzhBpr6pgVZ0MPCL1gpqMJyi3flhS50qqqX/B/HTizIqH9jeEfAlRS4I8PXUo18ZCcZPiTiuSnTzbOsTUp3p4h0as8Rh8PVhej7Stj3hJPL54KNMooor60/ngKyNd0mPWdNmsmby5g9vd2NxjLWmpWFxFe6ddp33W17BBNtyBIqNG+Y3YHXopNJpp7NWfoxpuLUotqUWpJrdNO6fyaPln4U6NNoP7Sv7TrlDDb+PND+AnxNkh7f2xdeF/FPww1JwejOmn/AAo0C3kYDpFGCx4C/U1ed22kLB8VtX1xFIbUfh94f0mVs8MNF8SeJr2BcdP3Z8QXJHp5hxjJz6JWVCHs4Sj/ANPq89f+ntepV/8AbzvzPEfWsRSrdsvynD27fUsrweBS+7DJ/MKKKK2PPPPPi6cfCj4nE9B8PfGZ/Lw5qVf5Nml/8gvTP+wbYf8ApJDX+sj8YOPhL8UP+yeeNP8A1G9Sr/Ju0v8A5Bemf9g2w/8ASSGonb3b3estNv5f6YHuXwv+P3x2+DFnq2n/AAd+Nfxa+FFjr15b6jrth8N/iL4u8E2OtahaW4tLW/1Wz8Oatp1tqN7bWuLaC6u45porf9zG6x5Ws34jfF34s/GHUbHV/i58UviN8U9U0uKSDTNQ+I3jjxN42u9MhmIM0WmzeJNT1JtPjmIHnJZ+QsuAZAxFfrR/wSm/4JGeHP8AgpF8O/iz461r48eJPhHN8MviBpngqPStD8C6N4ri1e31LwrpviIalNeanrulyWc6SX0lqLdLeeIxwpN5gaQov3D+0T/wbLfEPwP8Ote8Xfs7ftGH4veMtA0+71OL4ZeOfh/ZeDbvxbFZQSXEml+GfFmi+JNUsrXxFdrGYNHsNZ0SHS7++kht73XdHgdryObS3V7brX9PLpp6XD+uvp/wex+E/wCxH8AvhV+0x+0T4H+E3xl+PXhf9nvwPr2o2UV94o8Q/aodR8SSy3sEEfgnwZqMthN4V0fxZr5k+x6bqvjXVdI0ayeTzrWPX9VW08P6h/pjfCv4YeBvgr8N/BHwl+GegWnhfwD8O/DWk+EvCeg2Ycw6do2jWsdpaxvLKWnu7uVYzcX9/dSS3uoX01zfXs013cTSv/k/SxNiW3ubd42Blt7q1uoTHLFIjtFcWt1byjdFNFIrwzwyLvjkV43GVIr+8n/g3x/bR8WftL/ss+KPhD8TNcvPEnxE/Zh1zQvCdt4h1W6lvNZ8QfCzxRpt3d/Du51e8uHe5v8AUtBk0TxJ4PkvpWea50vw/otxeyzX9xc3Ezg+lls9evQbVvR7fh+HW/nrbVL9Mv8AgoX8Sv8AhUP7C/7W/wAREn+zXfh39n34pNpUwfy2TXdU8J6lomgeW4IIkbW9S09IsHJkZAMkgV/l62yLb28MQ4W3hjj+iwxqv5AL19q/0Ff+DhT4iHwN/wAEzPiXocU3lXXxW+IHwm+GtuA21pop/Gdj411WFecssmh+CdTWVRkGIuG+Umv8+xbW5vsWFmjSXeoMmn2caglpLy+dbS1RAOS7zyxooHJYgDmlN627f12/z/Qdrr0ffTovv89NL66H+iP/AME9/gEmo/8ABFf4S/BK7s1SX4u/sn+OJL6CSMAy3Xx60nxd4oaSVSOZD/wm8ZDEEjahB4Br/O4gjnighhuUaO6hijguo2GGjuoVEVzG4PIaOdJEYHkMCDyDX+sD8FvA0Pwx+Dnwn+G1uixwfD74a+BfBMUagKqR+FfC+l6EqgAAAAWPTFf5iP7Yvw7Hwj/a4/ah+GKQiC28EftA/FzRNOiC7VTRh441m+0LYuBiN9EvdOkjwApjdSuVwS5q3L81+QLWL8mn991qn/w/c/rh/wCDYn4jf27+yT8dfhhNNvuPhv8AtAXet20JbLQaN8RvBXhjULbav8MUuuaD4lkGAA0pmPJ3Gv3l/agG79mj9ohfX4F/Fsfn4A8QCv5Kf+DXv4if2T+0H+1F8J5bgJF44+EHgr4gWdsz4El58OfGF94evnjQnmT7J8SLLeQM+XEpPCiv61/2oDj9mn9oc+nwM+LZ/LwD4gqou6X3fcH2l/27+SP8q/T2J03Tx2On2Rx/26xGv2b/AOCb/wDwWG8Zf8E5/hN43+FHh34DeF/irZ+NviVe/Ee413WfiBq3hK7sri88MeGPDP8AZKWNl4U8QQTwQQ+GY7uO7+0QSPJfTRSQFYY5D+Menf8AIO07/sH2P/pLDX118Af2GP2u/wBqbwxrXjX9nr4DeL/ir4U8O+IJfCms674fv/CVnZ2PiODTdO1ifSGXxF4k0S5muodM1fTLyVraCaBI763VphI5QT72iiui1tdu9rv8tNX17WlK+h9rft8/8Fp/2mv28fAEvwb1Lw14O+C/wbv7+w1HxN4P8D3usa3rfjiTSry31LSbDxb4u1cWRudB07VLW21SLRNI0LRoLvULa0n1abUUtLWGL86f2bv2ZvjB+1p8XvDHwS+CHhe68SeMPEt3Atxd+TONA8H6EZ0i1Pxj4x1KJXi0fwzokLm5vLmUie7dY9N0yG71W8s7OaL42fs4fH39m3W7Dw78fvg58QfhDq+rJPLo0Pjfw/cabY67Fa7PtT6BrkTXWg68LTzI/tY0bVL5rQugulhLKD6X+xr+3B8df2E/irD8UfgnrcLW98+m2/j74ea2Xn8F/EzQNOuJZ4tD8RWqAzWd5bC5un0HxLprQaz4dvbhrm0lmtpb7Tr6dW/e8l2tf1Xb8dSldeW1r+um/wDwdr9Lr/SC/ZU/Z38Jfsn/ALO/wk/Z48EyyXeg/C3whYeHzqs8SQXXiDWmaXUPE3ia8hRnSK88TeJL3VdeuoVd0gn1B4Y3aONDXxV/wW3+Ih+G/wDwTA/atvorg2974t8H6H8MrEq215W+JnjPw54Jv4lPUk6PrWpuwGcpG+RjNfdH7Nfx78F/tQ/Ab4VftA/D5px4T+Kvg7S/FWnWl2yNf6Pc3UbQax4d1QxARf2t4a1u31Hw/qwizEupabdLESgUn8MP+Dmz4hjw9+xR8Kfh3FNsufid+0R4YeeEPhptG8CeFfFvia8JUHLRxayPDjsSCqyGLOCQa0ekXbTTT+t/66biWjT7a/dqfxF3VwLe0ubgDi3tpp8cYxFEz4GD/s+3Ff6JGsfs1Rn/AIIoXX7Ni2J/tK2/YBTREtPL/eN44sPg/H4gSTy8E/aH8a263OQC/ntvwXr/AD8vhp4KuPiT8SPhp8N7RDJc/ET4i+A/AcEaDLNJ4x8WaR4dVQB1I/tIkjB4ByMCv9WV9J099IbQmtozpT6a2kmz2gxHT2tTZm22kY8v7MfK24xt4xipgrqXnp/n+gbP0eqv2ttp11/A/wAmS3lE9vbzjpPBDMPYTRJJj8N2K/vF/wCDcv4it4x/4J3R+EJrjzbn4Q/HD4qeCFhLFng0/W7vS/idYDBJKxN/wn9wkXQfuXAHyk1/Dz8U/BNx8Mfih8TfhreRmK6+HPxG8d+ArmNgQySeD/Fmr+HcEHkfLpykdMgg4wa/qT/4NdPiGCv7ZPwjnuDmG/8AhF8UNKtC/BOq2Hi3wf4guETPY+HPDSSsBxviDHDKKmGktt1b9f0HraW7XfzuvP8Aze2x/W3RQeh//X+nek/x9Pb/ADz6cVpayS7cq694/wBd+3Uk84+Mn/JIfir/ANk38cf+oxqlf5OOl/8AIM03/sH2X/pLFX+sb8Zf+SQ/FX/snHjjp/2LOp/5PtX+Tlpf/IM03/sH2X/pLFSnfT0d/S6A/s0/4Nbh/wAWj/bDPr8XPhuPy+H8x/rXkf8AwdOAHW/2Jc/9A74+f+lnwfP9K9b/AODW0/8AFo/2w19Pi38Njn6/D+YdP+A15N/wdOEDWv2JfX+z/j4c+wu/g/8A40P4O+i/NflsN/5ben59/M/CH/gmwxj/AOChP7FLjj/jJX4WJ9A/iCJD+YY5+p619L/8Fy/gQ/wL/wCCkPxmuLSya08OfG+x8OfHnw423bHPP4xtp9I8bFGA2tK3xD8NeKb+ZR8yrqduz8ygt80f8E4Fx/wUF/YpI/6OY+FBx/3MlsD+GD+GK/pB/wCDnn4CjWfhJ+zr+0zplkrXvw78dax8IvFt1En75vDPxL07+2vDlxdyDpa6T4s8IHT7YudqXXi5kX5pwGm14N9U/wALJf16AtHvbz7f15HwP/wQg+OS6R4B/wCCjX7N2pXYS18b/syeMfjR4Xgll2omreDfCWueCvGi28ZIVp7/AErxL4NuJQoLi30KSRjsiYj+cnSv+QZpv/XhZ/8ApPHX1f8AsbfGZvgT8fdD8Z3F2LPRNd8GfFf4W+KJHfy4P+Ee+LHww8VeBJZbkkqDBpur6zpGtktxHJpccoBZFFfKlgjR2NlG42ulpbIykYKssKKVI9QRg+4qW9Eu1/xs1+vcFa69VftbT+mf6Hf/AAQT/wCUWv7O3/YT+MX/AKunx/X8sv8AwcFjH/BUL4p+/wAK/gaf/LUuR/Sv6mv+CCZz/wAEtf2dv+wn8Yh+Xxp8fiv5Zf8Ag4M4/wCCoXxSz3+FfwMx/wCErdD+daP4PlH9Bd76/wDD9f63+48d/wCCPhP/AA81/Y+/7KLr/wD6rXxyB+Y/+tiv9ISv83v/AII+5/4eZ/sf46/8LE17/wBVp46r/SEpxVk15/ohaX87fgfw3f8ABzX/AMnvfB7/ALNe8P8A/q0viZX4/fsB5P7dX7GeBnH7UnwJP5fEnw9/TNfsF/wc1f8AJ73wfH/Vrvh8/wDmUvibj+VfkF+wAv8AxnX+xoDx/wAZRfAz8x8RdAYD8eB+OOtLrLveP5r+vmM/1DR0Hfiv82v/AILL/EM/E7/gpx+1nrEcwms/DXjfw/8ADaxw25YY/hr4G8L+FNQgTBIUL4g0/W3dR/y2kkJ+Ymv9I+WaK3gkuJnWOGCJ5ppHOEjiiQvI7E8BURSzE9ACa/yifjZ49l+K3xq+MvxRnkM0vxK+LXxL8fGRm3Fo/F/jbXNet/m5yFtr+FF5xtUY4xSqbLzb/D/hxq617dfP/Prb8LH9MX/Brr8P/tnxM/a9+K0sPHh/wT8KfhxYzlf+WninWvFninWYUY9wnhXQHlAOcNCW/hNfAP8AwcE/D4+BP+CmXxI1pIPItvir8OPhJ8SbfapVJpYvDk3w5v5B2Znvfh5JJKRnMkhJ5Nfuz/wbLfD8aD+xn8YPiLLDsufiT+0Rr1tbzFcGfRvAng3wfoNsQ38UcWtXHiONcHCyCYDBzXwl/wAHRfw7aw+Lv7Jfxaih/d+KPh18Sfhve3AHHneCfEnh7xRpMLsOrNF471t4lY5Kxy7R8rUNL2evk/nfQqNr/LTfeyfTzv8A1Y/Nr/gh18RR8N/+CnP7O7zTmDT/AB/H8QfhbqGW2pMPFXgXWr/R4HJ4bzPE+gaAsak5aXywoLFa/wBFCv8ALK/Zc+IH/Cpf2nP2cvieJjbR+Afjv8JfFF5MG2hNM0vx1ocmrhmyMRvpJvo5ecNG7hsqSD/qag5AIwQRnIOR+B7j3pw2+f5JEvXX+uny69PuVz/O/wD+C83/AClM/aI/7APwT/8AVPeEK/Nb4FfHD4n/ALN/xU8KfGv4M+JE8IfEvwVJq0nhrxDJo2ia+mnPrmial4d1QNpHiPT9U0a8Fzo+rahZ4vLCcRfaDNCI5445E/Sr/gvOP+Npf7Q3voHwTz9f+FQeEv6Yr4I/ZJ/Zt8Tfte/tE/Df9nHwd4k0Hwh4k+Jl5r1ppfiPxPbajeaFpj6B4U17xZO9/baQj6hKLm20Ge0g8gfLc3EDzMkKyMJfxO2j92z+7b87rXTzEfdv/D9T/gqWf+bl7QcHgfBz4K8/n4BPPPGPTmviz9qL9sf9o39s/wAR+E/Fv7SXj+D4ha/4H0PUPDnhi/i8I+DvCR07R9U1CHVL61kh8H6FoUF+Zr23glE9/HczwiPy4ZI4mdG/cH/iGE/amwMftM/s/tnnP/CNfEUD8MW56jH9K/Jv/goP/wAE+fiN/wAE6viF8P8A4c/Evx/4I+IOp/ETwZqXjbTb/wAC2HiCwstOsNM10aDLZ3yeIIYppbqW4Imie2zEIsrIFfbuuXwvfVJb37W6vqkvXy1A+Wvg6f8Ai8fwbI7fF/4WMPw8feHiP5V/qyV/lOfBsD/hcvwaHb/hcHwsH4f8J94er/VjoirL8QCjr6j/AD/n8RRRTd+ndfmv0vcD+cX/AILv/wDBLbXf2nfC9r+1j+z54cl1r48/DLw9/ZHj/wADaRb79W+Lvwz0xri9tZdDt4hu1H4h+A2nvZ9G09VN74q8O3d74etpLnVNL8K6bN/DztyTwwKMyMrq8ciSIxSWKWNwskU0Tq0c0MirLFIrxyIrKwH+uBX82P8AwV1/4IhaJ+0J/wAJT+05+yLouneGf2gHS7134hfCy1+zaX4V+OUyK095rGjBjBYeGPizcqrM18xg0Lxzc7E8Q/YNbnl8SSxKO7W/VfK2n6rrr82n0dt7r103v6NdV1fl+I3/AASn/wCCxPxC/YS1LTfhF8Vl1r4jfspanqbPJoNuTfeLfg7c6lc+bfeIPh0szr/aHh6a4llvtf8Ah9LNFb3E73Gq+GZtO1ia/s9e/vN+GfxN8AfGXwF4W+KHwt8WaL45+H/jXSbfW/C/irw/dreaVq2nXG5RJDJhJYZ4JkltL+wu4rfUNMv7e607UrW0v7W4tov8pHUtL1HRtR1HRtY07UdH1rRtQvdJ1nRdXsrjTdX0fVtMuZLLU9J1XTbyOK80/U9OvIZrS+sbqKK5tbmKSCaNZEIr9nf+CM//AAU51v8AYj+M2mfCj4m+IZ5P2Vfi/wCI7Sw8V2uoTyS2Pwl8ZavJDYaf8UtGDlxpukTz/ZLD4kWluq295owh8SNFJqfh9EvVGT0T9PTt/X3balu2l/8Aga+Svf576pt/6Bdf5l3/AAVUP/Gyf9tj/svOvD/yj+Hq/wBM+ORJUSWJ0kjkRZI5I2DpIjgMjo6kqyMpDKykhgQQSDX+Zl/wVUH/ABsl/bY/7L1r366N4dJq57W7tJf8HyEfb3/Bu5z/AMFK/Dp/6oV8Y/5+Dq/pN/4OBxn/AIJafHUf9TX8EP8A1c/gb+tfzZf8G7n/ACkp8N+/wL+MY/L/AIQ0/wCNf0of8HAmP+HW3xzz/wBDX8EP/Vz+BsVK+GXp5/yr+uy9AW/XdfPRbf1uf582qIP7K1MDqdOvR9P9Glzj0/wr+m3/AIOAPgM0Hwb/AOCef7UWnWblLr4PeHPgB41vET5EkXwbYfET4biVxz1T4mw7pP45raNSSwA/mX1P/kGal/2Dr/8A9JJq/wBAz/gpd8CH+PX/AARr8TaLYWH27xJ8N/gN8Lfjb4VVE3zw6l8JPD+g+LNXFqoDMbi/8G2fijRkVPmddTeMZDlWmKupei/O/wCn9WDc/lT/AOCIPx0/4UX/AMFJ/ga95eNaeHvjFF4h+A3iL5wkc58fWUV34OSTJ2kn4jaB4QgQnlRdSKpBcmvmj/gpBz/wUJ/bZK4x/wANOfFvGOm0eKLsfy49jxwa+SvC/ijWPBXiXwt488L3LW3iLwX4j8P+NPDl1GxBh1vwxqlnr2jTKV5Hl39jbPkc4yO9e5/tffEHR/i5+1X+0R8WfD8sc2ifFD4s+K/iFpbxuJESy8Y3S+IIrfeCcvZ/bzZzAklJreRG+ZTSvpbzv+n+X3j038tNt9L38t/J/LT+mj/g1pB/4Rz9t09v+Es+BI/H/hHPiHSf8HTpx4P/AGJM9D42+No/PQPh2B/Onf8ABrV/yLf7bo/6mz4Dn8/DfxDzUP8AwdQnHhD9iL/sdvjb+GNB+HJz+laWfJ20v8t/xQt2/wCtld/jex/JCRkc+xz6EHIPPHBGecj1BFfpjb/8FkP+Cm9rBDbW/wC1x4wigt4YoIYk8E/CArHFCixxovmfDuQ4VFA5JLYyxJJJ/MyRtqMwG4gHA9T2H09fav6T9K/4NlP2mtT06w1OP9p34ERw6jZWt9Ch8IfEJmWK7gSeNXzKnzBJAGyo5GcL0ELne19H3tr9+4afP09Ov9bfd+bt7/wWU/4KeC1uZF/a98bK8dvO6Mvgz4PjayxMynB+HBU4Kg4xz+Nf6Df7O3iXW/Gn7P3wL8Y+Jb99V8R+LPg58MfEuv6pLHBDJqWt674K0TVNVv5IbWKC2ie8vrqe4eO3ghgRpCsMUcYVB/Idd/8ABsL+1BLb3EUP7TvwEZ5YZY18zwp8Q41BdCoLFPNIHPOFOOuG6V/YN8E/A+ofDH4M/CT4a6vfWep6r8Pfhj4C8D6nqWnpNHYahqHhPwrpWg3t9Yx3IFxHZ3dzp8s9slwBOsEiLL+8DVcVJN3v9/8AX3+QWVl3/Jaabfl5H8q3/B0yM6z+xGP+of8AtBf+j/g7n+Vfyf6fcnT9Q0/UEjWV9P1Cw1BIXYosrWN3DdrC0iqzIsrQhC4VigbcFO0Cv6wf+Dpf/kNfsRH/AKh/7QY/8jfB3/Gv5OYIpJ54LeFGlnuJ4beCJBl5Z55VhhiQcAvLKyxoCQNzDJA5qZNpu3k/y/yX9MpJaXenXvsvXq/wP6o9U/4Oi/ic+l3EOhfsbeBrHV2t2SyvtX+Nmu6tpttclCI5rvTbL4b6Pd30Eb4Z7eHVdPkmUGMXcLMJl/nR/ah/aZ+L/wC198aPE/x3+OOv2+u+N/Eq2ljHb6ZaPpnhvwt4d0oSLovhLwlpLz3baX4e0dJ53himu72/vr+61DWNXv8AUdX1G+vZ/ofxF/wSx/4KO+FdOudW1f8AYx+OLWFnC9xcvomh6T4ruo4Y1LyOul+FNb1vVrgooJaO1sZ5Rggx5BA+CLuzmt7i7sb61uLO8s7mex1CwvbeW0vLK8tZXt7yxvrO4SO5tLy1mR4Lq0uYo57eZHhmjSRWUEm9L7WXlfRX+f5feC030XfV9nunvp52e6P6Tv8AggV/wTZ8e/Er40eFP22vi14Xv/DnwY+E813q/wAG7fX7Keyu/ip8SntrjTLDxXo1lcrHNJ4I8BR3N3qFr4gZEttZ8Ypo8ehyX1toetSRf0if8FgyB/wTH/bSJ6f8KT139b3TR/WvwL/4IK/8FSPiUvxV8O/sQftC+MtT8a+D/GmmT6f+z74w8U3smoeIfB3ibw7pU1+nwvv9cvJHvNU8K654f067/wCENTUJZ7vw9rGlQeG7CWTS9b0+00r98P8AgsQcf8ExP20j/wBUV1kfgdQ0sH9DVQSS06u79bL+vz1uJu717L8vl/W2h/nBP99v95v5mv70v+Ddb/lG3oH/AGWr4z/+pLFX8Fr/AH2/3m/ma/vR/wCDdY5/4Jt6D7fGv4zj/wAuSE/1pQetuyfzu09RHxX+1j/wcQ/Fj9m/9pv47/ALS/2XPh94s0z4QfEjXfA1h4l1D4oeI9Iv9ctNJMBi1G80y38GX9vY3E6zjfbw3tzGpXKyEHA+ev8AiKO+Mo5P7HfwzOP+qxeKB+v/AAgJ/lXxl/wU4/4J2/tu3/7WH7aX7Rdn+zp40u/glJ8RvH/xNi+IdvqPg+TSG8AaZp8epX/ic2Y8TDW0sbTT7G7u5on0tb4Q28jLaN8ob8OshsMOjAEc54IyMe2Onp0pybi12evTvrrv0893YX9b+n9f8Of6YP8AwTO/bP139vf9lbQv2iPEfgLSfhtq2reNPHvhSfwtomv3niXTrePwd4huNGt7yLVr7S9HuZXv4Io7maJ7GNbeV2iR5VUSN/DR/wAFlP8AlKF+2V/2UDwf/wCqh+HVf1gf8G6LZ/4Jo+Fh/c+M3xtX8/GMrf8As1fyff8ABZP/AJShftk/9lB8If8Aqofh3TfwrXV8tvW6fb9Bnuf/AAQV/wCUo3wJ/wCxO+Nn/qsNdr/Qkr/Pd/4IK/8AKUX4F+/g/wCNf/qsNer/AEIqcb2s+lrfcv8AhvkAUUUUwCiiigAooooAbzxgcEA89BjoO/Oe/TAFOpvXGBxgHnpx0wPX1PtTqX4/lo/nqvz/AAAooopgFFFFABX+ah/wX1097D/grT+1XvGPty/BTUo8j70dz8DPhzHke2+3cAj+6RX+lfX+d3/wcneD5fDX/BUHxNrjxFIviF8Cvgx4sgkIwsx06PxL4EmYHjcUPhCKM9SMKCcEKPhfEGDlklGX/PvMaEn5J0MVC7+clvpr3sf1l9DXExoeK2ZUZSSeM4KzihTT+1OGZ5HirLzVPD1JW7J9Ez8KsfieMnp0P/6/5V/oj/8ABut8ZNP+J/8AwTI+GnhKOaFtb+BPjb4kfCTXbdWXzohH4ouvHnhyWSIHciT+E/HOiKkjALLJBPsLGOTH+dzX9FP/AAbf/toWX7P/AO1tr/7OXjXV00/4f/tW2WlaV4dlu5hFZab8bvCS3sng6IO4ZIH8c6Hfaz4TAXa+oa/b+DbDcSYxXwnBmYQwGe0I1ZKNLG054KUm0lGdWUJUG7/zVoU6d9kqjk2knf8ArX6TvBuJ4u8Js1lgqUq+P4YxmH4pw9GCcqlWhl9LEYbM4xS1fssqxuMxailJ1J4WFOC5pRa/vvr5j/bO/aQ0H9kT9lr45ftH+IUguLb4U/D/AFvxFpem3D7I9d8VvEumeC/De4MjBvEni2/0XQ1ZDujN/wCYASmK+mx0H58+/wCf9a/lD/4Oov2kX8M/A79n79lPRNQ8vUfi/wCPL34oeNrWGUrIfBPwtS2tdCsb1AebTWfG3iOx1K23Aq9x4NlK8wnH7BneP/szKcdjU0qlGhJUb2t7eo1SoXT3XtZwbX8qZ/mz4VcHvj3xC4U4WlCc8LmOaUp5koXUo5TgITzDNWpL4JvL8LiIUp30rTppatJ/xceKfFHiPxz4n8T+OPGGpS6z4v8AGviLW/F/irV5sebqniTxNqd1reu6g4+UKbvVL66n2ABUDhVAUAVz6kk8nt/WpT1J55PemKMf48fiOnTj69e9fzs3fnbbk27uTu223dybd3d7u7u2/M/2pp04UoRp06cKdKlGnTpwpxUIU6dNRjGEIJJRhGMYqMYrlirJaLT+sX/g1B1GCL4u/ts6O5Aurz4e/BDUoVP3mg07xD8SLWcqe4WTUYMj3Ff2u1/mFf8ABJj9uiT/AIJ//tleC/itrs8g+EHjmBPhb8dbZI2mNt8P9f1KyuI/GMEKAu974B16003xMyxK091olrr2l24EuqAj/Tn0zU9P1rTdP1jSb201PStVsrXUtN1KwuYbyw1CwvoI7mzvbK8t3kt7uzureWOe2uYJJIZ4ZElidkZWP7RwHjKNfJI4SMv3+BrVo1oOyajiKtSvSmu8JKc4JvVzpTVrJN/5efS74ZzLK/FOtxHXot5XxXlmWV8uxUbunLEZRluCynH4ScmlbEUHh8PiZw1XsMbh5KTbnGF6iiivtj+WAooooAKKKKACiiigAoor+c7/AILH/wDBczwb+xZp+v8A7PP7Nd/oXj39rO9tZLDXNW/0fWfB37P8V3D8uoeKYVL2uu/EUwyCfQPATs0GnOYdZ8aLDpyWWh+IuHMcxwmV4WeLxtVUqUNEtHUqzfw06ULpzqS6RWiScpOMIykvq+C+CeJPEDP8Jw5wvl88fmOKfNOTvTwmBwsZRjWx2YYnllDC4OgpJ1Ks05TnKnQoQrYmtRo1PRf+C0H/AAWJ8L/sG+B7/wCCfwW1TSfE37X/AI60Q/2ZZD7Nqel/A/w7qsJSH4g+NrRvMgl8QXUEhm+H/gy7Utq90I/EGuQL4YtEt9d/i5+FH/BO/wDa+/au/Z5+PX7aXhfw9qfjLwn4B1m9v9Xv9futR1Hx58ade82/1z4pal4Gjmhnn8Zah4G02K88TeM7ye5jl1O4N/pOhf2z4isr7S7f37/gmX/wTo+OH/BWL9ovX/GnxE8QeMX+Eem+K/8AhJ/2kfj3rt7c3/iTxPrWpyJqV34M8O65fiX+1fiT4st5A1xe4nsvA2gTR6xd2+9/Dmjav/oa+E/h34D+Di/Aj4J/CzwvpHgn4e+AfDniRPCvhLQrcWum6RoPhjRbLw9DFFHuaSeUz+LUmvb+7kuL7UL+7uL+/urm+u7i4m/PKOBxvGlapmeZOpgsppqeHyzD03eTnVape3XMkp+zm41KtRxSrVKcaEb0qcor+0814u4X+izlWD4D4FpYDijxHxtTB5vx7nmKpv2FLC4GH1/+x2qcnUw31vDqrhsDhIVJVMtwWJrZtXUsfi8NM/nl/wCDcf8A4KeP8cPhwn7DPxo8QtefFj4PeGxqPwT8Rareia8+IXwb01YYD4We4nYzX/iX4WxyWtpbZd7nUfAE2lXAid/DGuX0v9TNfwNf8Fjv2JvH3/BKv9s/4bft7fslW7+Fvhd4u+JcXjjwgmmWzx6H8K/jVA9xrHiT4Y6ha24S3T4e/EzSRr17oejjybOTRbrxn4LhtrbT9I0o3n9o/wCxt+1N4B/bQ/Zr+FP7SHw6lRND+I3huC+1DRmuI573wl4rsXfTPF/g7VTGRs1Lwx4jtNS0iZmSMXkVtBqNuptL22d/ouF8diaf1jIMzf8Awo5VaNObu/rWA0VGtCT1mqacIOTSl7OdHnvV9rb8Q8euFMhxSyTxh4DpW4L8Q3Vq4zCQjBf6u8WwUqma5TiKcPdw8sVUhicRSpL939ZoZj9VtgFgXP6eooor68/nAKKKyNb1aHR7IXDlWnuLm10/T7ckBrvUtQnS1srZBkMQ08ivOy58i2Se5fEUMjKm0ld6JDjFyajFXcmkkureiRytprC3HxR1jQ1cN/Z3gLw/qroAcr/a/iTxTYxvuPGHbQJ1AHUxknpXoNfKHwm11vEH7T37UdvG7TWnw+8Pfs//AA2MxOV/tdPDfjD4makh+UBZm0/4m6BcSqGJxNGzKpOT9X1lRnzxlK9/31eH/gqtOlb5ch35lh3hcRSotWvl+VYhdNMblmEx0XbpeOJTt09QooorY8884+MZx8I/iken/FuvGv8A6jepV/k4aX/yC9M/7Bth/wCkkNf6xvxl/wCSQ/FP/snXjX/1G9Sr/Jy0sZ0zSwP+gbYf+kkNS0nZPZXf/pIl18n+iP7TP+DXXA+An7V49Pjl4TP5/DPRRn9P0r+ohhlT+f5HPb6V/Lr/AMGuh/4sP+1kPT44+EPrz8NdJ5+nGB7g1/UWen6fnx/n17URVor0v9+pT1+5fgkj/LE/au0220j9qn9p/S7SJILXT/2jvjpa20MahI4YIPip4rWGJFUAKkaBURQAFUAAAV+9H/Br/rF3bftNftReHkkYWOr/AAI8GazcxchHvPD3xAuLGzkYDALxw+J75ASC22RhnGc/gf8AtRa7p/ij9p39pLxJpFzDe6Vr/wC0D8atY0y9t5Flt7zT9S+Jfie7sruCVSVlgubaaKeKRSVeORWUlSCf3w/4NgdNnm/ad/ag1dY2Ntp3wH8H6dNKASqT6z8QZbm2jY9A0seg3bKCQSInIBAOM4/ErbXdvTUNUmumjfztb81/SPrD/g6P+IJsvhH+yT8KIpwG8U/FPx78RLy2V/mNv8P/AAbbeHLWSRB1Q3XxKfyyRjfE2ORz/I/8H/EHhfwj8XfhP4t8b2Gpar4K8JfE3wB4q8X6Xo0VrNq+peGPDfizSNb13TtLhvbmysptQvtMsbm1s4ru8tLaSeVFnuYYy0i/vn/wcz/ET/hJP20/g/8ADiCcy2vww/Z6s9UuIQ25bfW/iV448RXF4pQfckk0bwb4dlOfmMbofula/nv8I+DPGPjvWY9A8C+EPFfjjX2t7i9XQfBnhvWvFettZWew3d4ukaDY6hqDWlr5kX2m5FsYYPMj8103rlyT5m15a+dk/wDhvMH09O3f8z+3JP8Ag5m/YfZsH4R/tRqv95vB/wAM8/UqnxZcDvgb2+vev5NP+Cg3x0+Gv7T/AO2V8c/2gvhJpHivQfAfxU1vw34hsNK8bafpWl+JLbVrbwR4a0HxI19ZaLrGvafFHda5o17e2jw6rcvNb3KSTiCYvEPMf+GYP2nM4/4Zp/aJyen/ABYz4pnP0/4pPn8K4Xxr8MfiX8Nn0yL4k/Db4h/DuTW0u5NFTx/4H8U+Cm1lNOa3XUH0lfE2laWdSWwe7tFvTZCf7Kbm3Fx5fnxhnLbV66aPdaK/k3qt1s2CWiunbq/60/4J+nv/AAQl+I//AArf/gpz8BYprj7Pp/xL0b4l/Cq/Jfak39veCdR8SaNC/IDGbxL4O0WKNTyZZFABYiv7zv2pTt/Zk/aMb+78CPi6fy+H/iE1/mjfshfEEfCf9rD9mP4ltL9nt/A/7QHwh16/m3bFTSIPHWiW+th26COTRbnUI5QeDE7g5BIr/S2/aoP/ABjB+0cR/wBEF+L5H/hvfEVOG3z/ADSYX95fL7lZdWf5XGmpnTNOI6/2fY/l9li9uua/t2/4Niz/AMYdfHpT2/ag1lsf73wn+FQ/9lr+JHSgDpWm8f8ALhZc4GcfZ4vT24r+2z/g2N/5NB+Pw9P2ndU/9VT8L/w/WlB3dn0Wn4f5fn8kfpF/wV5+BHhn49/8E8v2mtH1zSbO+1jwB8NvEXxi8D6jLbpJfaD4x+FmmXXjCwvtMuCpktJtQsNM1Hw7fvCVa40XWtTsXJiunFf5sIYOquOjqrj6OAw/Qiv9S79tbH/DG37WeRkf8M0fHXI65H/Cr/FORX+WZagm2tQOT9mg/H9ymabS5o9N7/LVXH09OnbbX5/of3qf8G3PjC+8Rf8ABO288O3lxJNF8O/2gfir4X0tJGLC20zVofDHj7yIwT8sf9p+M9UlCjC7pWIHOa/NL/g6R+IZvvij+yH8JIpsr4d8D/E/4k39uD/y18Xa/wCFvCmjTOoPUR+D/EEcTEZG+UKeWr7u/wCDZFs/sQfGFc52/tS+L+PTd8NPhSf1r8Jf+DhH4iHxx/wU08eaClwJ7X4T/C74R/DuJVcskNxc6Le/Eq/jA6K4n+ICxzAc7osHoKH8HyX6Bp26K3rpr89fvPzt/Y/+KvgT4IftTfs/fGb4naZ4h1nwJ8J/il4b+IevaV4UstO1HxFff8InPJrGjQ6ZZatqmi6dcSjxBbaTLMt1qlmi2sU7rKZVjjf+v+L/AIOX/wBhx8eZ8K/2n4s46eC/h5JgcenxSGe546+ua/iZ8G+AvHvxEv7rS/h74F8a+P8AVLCzXUr/AEzwN4S8Q+MdRsdOaeO1XUL2w8OadqV1aWJupYbYXdxFHbm4ljgEhldUPqKfsw/tNDj/AIZs/aGz1/5If8UR/PwoM+v41PNZLltrdtb22W+/T8RW/r+v61Oi/bQ+K3w++OX7V/7QPxn+FVj4j07wB8V/iZrvxA8P2Hi3TbHSPEVq/ilbXVdci1TTdM1TWrG2kHiS41h4Bb6pdrNaPbzu0ckrwx/qV/wbk/Ej/hDf+ChuoeDpp9lt8XvgF8QfDUcLNhbjWfCOseFfHunYBwGlh0jRfE5j6kRyThcZOfxL8cfDv4hfDi/stO+IvgDx18PdR1OzbUNN0/x54P8AEfg2+1GwjmNvJfafaeJNN0y4vbKO4DW73VrHLBHMphaQSfLX1v8A8EwfiUfhJ/wUP/Y68Zvci0tJfjf4b8D6lOzFI10v4qW9/wDC+9845A8lU8XrK+eB5Sk9KnqvVNvXra/Xp3KV7paa27uylbbX7+vmf6ZlJ3P19enA/wA4980iDCqDknaAc8k4AGT9cZOaXHP4+h9B/h1+orV62fT594vt5f1raTzf4y/8kg+K3/ZNvHI/E+GNUAr/ACctL/5Bmm/9g+y/9JYq/wBYz4zf8kf+K3/ZN/HH/qM6nX+TzpI/4lemE9f7Psj/AOSsQ/lSk0rXV9Hp9wlu/X9Ef2V/8GtvHwn/AGxR2/4Wz8NMf+EBdf4V5N/wdOn/AInf7Ew/6hnx9P8A5N/B/P8AT8q9Z/4Nb2/4tZ+2On934q/DBv8AvrwFfj/2SvJf+Dp3H9t/sTf9gz4/Z9Mfa/g9/wDXzQ/g07L8bDf+W3p/V/M/Cn/gm6M/8FB/2KB/1cv8Kifw8R25/mAK/vo/4KbfAJ/2mf2Df2nPhJZWf27xDqXwy1fxR4KgWLzp5PHfw8kt/H/gyC2AVnSa+8ReGtP00tHhmgvZoySkjA/wMf8ABNz/AJSD/sU/9nLfCv8A9SK3r/TTIDAqwBUggggEEEYIIPBBHBB4IoitGn3Tafmk9v62A/yRIpFmijlUHZNGsqhuoSRQ6gg9wGAIPI6GpK+t/wBvX4Gf8M1/tn/tL/BOG0ax0jwb8WfEtx4TtmUoE8C+MJIvHXgRYweDHD4S8TaPaAplA9tIo+6a+SKhLWN/LTyT1v8Aj6JdrAf6F3/BBEY/4Ja/s8f9hX4xn8/jT4+Nfy0f8HBvP/BUP4pn1+FfwNI9v+KWuv8ACv6lf+CCDbv+CWv7PPfGrfGRfy+NPj7+XSv5a/8Ag4NH/G0H4on/AKpV8DPw/wCKWvB/T9a0afKls7R1+4Dxz/gj3/yk2/Y+H/VQ/EB/L4Z+Ov8A69f6Qdf5v/8AwR4Ab/gpx+x8P+qgeJW/75+GHjtv5gV/pAVSW77v9F/X9arq35L8L/5n8Of/AAc0p/xm98G2x9/9l3QR067fin8TePfr/wDrxX4+/sFOIf25v2NZW4Ef7UfwJznjr8SPDq8H8f1r9Yf+DlDxTpmuft8+B9AsbiGe78E/s2eCdN1qOKRXez1DW/HHxF8QW9pcKpJinOlXmnXojfa32e9t5cFJo2P5Zf8ABPnR7jX/ANvH9jLSbVWeaf8Aab+DNxhQSRBpfjjSNXvJDjkLDZWFzM56KkbMcAEjJ/H84/oV8vTyP9Fz9tX4lD4O/sfftPfFAT/ZrjwP8Bfipr+nyhgjDWLTwXrH9iojHGJJdWeyijxyXdQoLECv8s62i8i2t4M5MFvDCTnOTFGqEk9ySuSe+a/0N/8Agvr8Rh8P/wDgmL8bbGOYQ33xM174Z/C+y+ba0qa/490PVNagXkbvN8MaBriyLzmHzcjbmv8APKLgMcnAXdkkjgALnv6+3POOac+nkr/1/X5iP6t/+CZH/BbT9jX9i39jX4V/s8eO/h98fLjxn4Ql8Zan4r1fwh4R8Gaz4f1nXfFvjbxB4omvNPvL74gaLfyQx2mrWdiPtemWsqfY/L2yIqyv88/8Fkf+CqH7KP8AwUM+CXwp8G/B/wAJfGfRPiF8Nviyni6HUfiF4T8L6Joj+E9S8I+ItC8R6fFfaP438RXpvrm/ufDl1DbNp8dvMmnzNJco0cSSfiLbfs4ftGzwQzW/7PHx9uIJ40lhng+CnxOlhmikRXjlilTws0ckUiEOkiMyspDAkEGo9Z/Z7/aB8O6PqXiHxF8BPjh4f8P6LZzajrOva58IfiJo+iaRp1upe41DVNW1Lw3a6fp1jboN813eXENvEnzSSoOaavJWasrJeelv08uwfP8ArseUXYla0uBAxjnMEpgcEho5ghMLqRyGSQKwI6EA1/qf/sxfEZPjB+zf8Aviqky3B+I3wa+GnjWaVG3A3fiXwbo2rXiE5PzxXd1NE4ySHRgeRX+WQOg6Hge4PH8q/wBD3/ght8Rk+Iv/AATI/Zy33H2i/wDANp40+F2ogtuaBvA3jnxDpWkW7ckrt8M/2E6KTxFJGR8pFKD1a+f9f12D+v6+4/kx/wCC8yj/AIemftCjjB8O/BNvfP8AwqHwkD+OV/yK4r/giYuP+Co/7KBI/wCY58SAPfPwZ+Iv8uuK7X/gvIc/8FTP2hf9nw98FF/8xF4Sb+TCuO/4InAn/gqN+yfjtrvxIJ+g+DHxFpP+J81+geR/o0r91f8AdH8q/im/4OgR/wAZQfswH1+Aniwd+3xGj/DjcPz/AD/taX7q/wC6P5V/FR/wdAjH7Tv7L59fgL4vH5fEa1P9auXwv5fmg/r+tz+fT4OnHxk+DZ9Pi/8AC0/l4+8PV/qx1/lPfCE7fi/8Hm6Y+LPwwOfp478PGv8AVhpxfMr/ANdACuc8YeL/AAz8P/Cfibx1401uw8N+EPBmgav4p8U+IdVmFvpuheHdA0+41XWdX1CcgiGy07T7S4u7mXB2QwyNg4wejr5c/bg0efxB+xh+1tolrG011qv7NPxysLeJVLNLPcfDPxNHDGqgEszyMqqAOWIHemC1aXc8XH/BWP8A4JtEAj9tD4DEMAwYeM7UqVIyCGEe3BHfNfWnwZ+Ofwg/aH8FR/Eb4H/ETwv8UPAs2qanokXirwhqMeq6NJq2jyrBqmnpdxgI1zYzOsdzGOY3baTmv8qa1mElpaSbuHtbZ+ueWgjOffr1/wDr1/eJ/wAG4uq2d9/wTrewt5o5LnQfj98W9P1CFGBe3nu38Pa5Akqg5Uy2GrWk6ZA3JKrDipUru3ld+um34h/W1j4n/wCDiX/gnf4cTwt/w358JtDg0nxBpWqaH4d/aQ0rTIEhs/Emjaxc2ugeE/ilLbxKip4h0TWJ9K8LeJ7tVd9Z0XVdHv7ryn8N3M97/IS6JLHJFKiyRSo8ciMMq8bqVdSPRlJBr/TC/wCCpjaAn/BOb9tFvEvkf2Z/wzz8R1T7Tt2HWH0K4Xw4E38faT4ibSxZ4+f7X5HlgybRX+Z6mSq55O0Z+uATUTVn662/X5j7f18/x/A/0b/+CMHx71X9ob/gnL+z34m8R6hNqnizwPpGr/BzxRf3Mhmury9+FWs3nhLSb68mYmSe91LwnY+HdTvJ5SZZ7q8lmkZmkLH+Hz/gqmc/8FJv22vb49a7+mheHR/Sv6xP+DaxLtf+CfHilp932eX9pr4pPYbs7fs6+Gvh1FN5ZP8AB9vivM44EvmfxbgP5OP+CqIx/wAFJv22/wDsvevH89F0A1Tfuxb7xfz6/hcGrfcn96ufbn/Bu+cf8FLPC/v8DvjIP/IfhI/zUfpX9KX/AAcCnH/BLb45e/i34Hj/AMzP4HP9K/mv/wCDd4Z/4KV+F/b4HfGU/wDjnhAf1r+k3/g4JOP+CW3xvP8A1OHwP/X4y+Cf1pR1g/R/LT+v+HJW79f0R/n46l/yDdR/7B99/wCks1f6pvwk0fTPEP7PPwy8P6zZw6ho+ufBjwXo+q6fcoJLe+0zU/A+m2V9Zzoch4bm1nlhlQ8MjsD1r/Kz1D/kH6h/14Xv/pLLX+q/8Cv+SI/Bz/slfw9/9RHSKcVa/on+Ydfk/wBP+Cf5f/7RXwd1D9nn4/fGr4E6msn2n4R/FDxn4DgllUq95o+h63dQ+G9TAPJj1fw22karC/SSG9jkGQwJ8bAA6DH0r97/APg4v+BZ+GP7e1j8U7CzMOh/tF/Cvw54qmuEi8uCTxv8PSvw+8UQKVVUaYeHbLwBqFwwJd5dSeRzuYk/ghWbVm0N+fXU/r1/4Nagf+EY/bcPr4u+BY/Lw38Qf8fzzVf/AIOof+RN/YlPp4z+OH/qO/D0/wAxVn/g1rP/ABS/7bQ9PFvwLPbqfDnxDH5fL+JBqH/g6eG7wd+xMMZ/4rL44/8AqOfD39a0XwLqtG/S9393XuB/I3KAY3B6Ef5/z+df6xPg/wD5FLwt/wBi5on/AKbLWv8AJ4lYBJG9m/XpX+sN4N/5FDwrg5/4pvQ+fX/iWWvNUvSzdm+39K2vyF1Xo/zidJRRRTGfyEf8HTX/ACF/2I/+vD9oP/0f8HK/lF8P5PiHw7zg/wDCQ6CM/wDcXsl/ka/q5/4Omj/xOf2JF/6h/wC0Efzn+DoP8h+dfyleH1z4g8OY6nxF4fH4nWLL+fH+Sah21XVtJaX6Rv8A15At1Y/1q4/uJjpsX+Qr+HD/AIOUPgV4O+Gn7XPwo+LfhLR7LRLz4/8Awx1q88dxWECW8OteNPhtr2maS/im5ijCxtq+reGvEug6ZqNwFVrtfD1pcTmS5knmk/uOj/1cf+4v/oIr+O//AIOldo+IH7FjY+YeD/jyD67TrXwmx+uac/hfl/mVHf7vzR/OB8BPGmo/Df48/Az4haPNJbap4G+M/wALPFdjNExR0m0Px1oN+yBgQQs0MMlvKuQHileNso7A/wChT/wWIGf+CYn7aQ/6orrP5f2hpef0r/Oc8Kkf8JZ4QIP3fF/hQ5B6Y8Q6afw6V/o5f8Fc9MvdX/4JnftpWenwPcXC/AnxVftFGpZvsuki11W/kwASVhsLK5mc9AkbE8A0obP1/r8idbpd7v8AL87/AJH+bm/32/3m/ma/vP8A+DdT/lG5oft8bfjN/wCpDbn+tfwXsQWYjkFifzOf5V/eB/wbkanZ33/BOaGxt545LnQ/j38YNP1KFHBktbm6vdG1uCKZQSUaXTtWsblAQN0U6MMg5qYbv0/VAfpt+3pg/sP/ALYYbkH9mH47g/Q/DHxOK/y64f8AUw/9cYv/AEBa/wBP/wD4KHazp+gfsHftkapqlxFa2cH7M3xrheWV1RPOvvh7r9hZwgsQDJcXl1BbxIMtJLKkaAswB/zBY4ysUangrFGpB9VQAj8MVU3tp3/NP9AP76f+DdFcf8E0vC/+18Z/jY3/AJd8g/pj8K/k/wD+Cyf/AClC/bJ/7KD4Q/8AVRfDuv62v+DebTJ9P/4JkfDe4mRkTWPib8bdTtyQR5kA+I+taZ5i+qmbTZlBHGUIzxX8k/8AwWR5/wCCoH7Zfb/i4PhL/wBVH8Ocfnin9mP/AG7+n6Ae4/8ABBb/AJSjfAj/ALFH41/+qu8QV/oSV/ntf8EF/wDlKN8B/wDsUvjZ/wCqt8Q1/oS01sn3Sb+4AooopgFFFFABRRRQA0dsDjA69sdB35z1PoPWnU3njA4IB56DHQd+c9+mAKdS/H8tH89V+f4AUUUUwCiiigAr+Jv/AIOvfhZNYfFn9kH43QQE2/ifwD8R/hRqd0qEBLrwZ4h0LxloUEsgAG+4t/GniWSBWYsyWc+0AI2P7ZK/n8/4OUfgVL8V/wDgm/rHxD02y+061+zn8UPAvxV3xpvuV8L6jc3Xw58XxrgFha2+neNYddvsfKkGhee/ywkj5vi3CvF8P5jCKbnSpRxUbbr6rUhXnbzdKFRaa66H7Z9HXiCHDnjJwTi601DD4/MK2RV3J2i/7eweIyrDczeijDHYrC1W3onTTdtz/PqPt7fy5/WrFlqF/pN/YarpOoXmk6vpV9Z6ppOq6bcyWep6Vqum3MV9puqabeQss1nqGn3sEF5Y3ULLLb3MMUsbK6gipvGOOvT1HTrxnI9Pz56V+of/AATx/Yw8P/8ABQXwf+0j+z/4WvdN8OftT+BvCul/HX9nnVNQu0sNL8e6ZpFz/wAIt8TPhL4nnlYRJZarLqXgPVfC+tkGTwprLalfTsdB1DXY6/DMHhauNxEMPh1zV5qo6UE7SqTpwlU9nB/8/KnI4Ul9uq4QWsk1/rRxHn2W8M5Ric6zmUqeU4OrhaeYYlU/aU8HhsXi6GCljcRDf6jhZ4iFfHVYxn9XwUK+JcKkaMoy/tM/4I0/8FNND/4KEfs9W+n+MtS02y/ac+D+n6XoPxn8NxmO1k8RwmM2mifFrQLAEB9A8ai2kfVobRTD4c8Wx6rozxw2MmhzX/8AIT/wcD/HJvjZ/wAFPPi3pVpfG88PfAfw34H+CGhhX3Qw3uiaa3i/xkqKCVSeLxn4y1vS7kjDM2kIj4MWF/PD4GfHH9oP9gj9pXTviP4IbWfhl8bfg74l1Twz4r8JeJrC6tPPFpd/YPGfw0+IXh2R7d73RtVFs9hrGmyvHNbXMNlrej3Vpqdjpep23lfxd+Juu/Gn4t/FL4yeKUjj8S/Fj4jeNPiTr0EM01xb22reNvEWo+I72ytp7ktcTWtjNqDWlrJOTM1tBEZCXya+nzbiermmR4XLa6msbRxMfrVWV0sRTo05RpzlfWNWU5/vovTnpKpF2m4Q/C/DvwFy7gDxZz7jnJamFq8K5rkFX/V/B0pwlLKMfmuNwtfG0MPytxq5fTwtCccsr05PlweOnhKjm8PDE4vhLiX7PbzSqhdoonkWNRlpHCsURB1Z3YbVUAkkgDniv6CP+CtX/BJfTv2O/wBlH9jX9pvwDYtpU+o/Dr4U/CL9qHw5+88pfjHqPghNXtviTZxSSSGCTxHrFn4h8MeLI0aCzGpWnhK8tLQXmr6vIfyR/Yq+Fcfxz/bE/ZZ+D9zB9q0/4g/H74W6HrcO0yB/DcfizTtT8U71Gd0SeGtP1Z5QRjylbd8ua/v8/wCC93w3PxF/4JUftQQ28BnvvAmm+BfijYhE3NEnw/8AiL4V1/WZhjlFj8N2+tb2HSMsDhSTT4fyeljsk4jxdWmpVMPh4vCTsuaFbDU6mKqKLs2nUiqNKVtHCcotaprDxh8Ssw4Q8VfBTIMBi5YfC5xnNePEdDm/c4rLM7xuXZDg/bwvyyjhqs8wxtJyT5MThqFRaQlGX+bQQGBDAMpBDA9CDwQfYjg1/cT/AMG3v/BRtfit8MLj9hL4teIDN8S/gto0mrfA/UtUu1a78Z/BeCWOKfwjFJMfOvNb+E91cRWVtAHeaXwDfaJ9nhaDwtq9yv8ADv1J446j6HGP516V8G/i/wDEP4AfFb4f/Gz4T69J4Z+I/wAMfE2n+LPCWsKpkgj1GxZkm0/U7Xcq6hoWuafNeaF4h0uVhBquh6lqGnz/ALq5avHyDOKuSZlSxkbyoP8AdYukn/FoTlFTSTsvaU3FVKWsf3kFGT5JzT/SfFzw0wXinwVmHDdd06OZU75hw9j6issBnGHhNYeVSSjKSwmJhOpgsbFKb+rYipVp03iKdCUP9dbI9aK+N/2C/wBsr4fft3/sy/D/APaF8AtDZS67ZnR/HnhL7Qtxf/D/AOJGixW8Pi/wZqTDDk6ZfSrdaRdyqh1jw3f6Jr0aJBqkSj7Ir+gqNaliKNKvQnGpRrU4VaVSPwzpzipQkr2dnFp6pNbNJn+NmaZZj8lzLH5RmuFq4LMssxeIwOOwlZJVcPisLVlRr0p2bi3CpCS5ouUJK0oSlFpsooorU4AooooAKrXl5aafaXV/f3NvZWNlbzXd7e3c0dtaWdpbRtNc3V1cTMkUFvbwo8s00rrHFGjSSMqKzD5h/a1/bR/Zx/Yh+Gtz8Uf2jPiNpXgrRmFzD4e0JWXUfGvjrVbeISjQfA3hO2f+1fEerSFolkFrEun6Yk8V5reoaXpwlvYv4Hv+CnH/AAXD/aG/b/uNX+GPgqLVPgR+y3JO9vH8NNI1Qnxh8SbSOXMF38X/ABHpskcd9ZzsqXKfD/RHHhWzbyk1a58WXlpbapH87nvE2X5HTaqy+sYxxvTwVKS9o7q8ZVpaqhSd0+aacpK7p06nLK37V4TeBfGXixjIVMvoPKOGaVZU8fxPmFKSwVNRlarQy6k5U55rjopNfV8PONGjPlWNxWDjOEpfsT/wVq/4OG7DS4fE/wCzj/wT48Sw6nrb/bdB8d/tRaaYrjSdExvttQ0j4HOweHWtZU+ZbTfE10fRNKIkl8GprF61p4j0r8G/+CZX/BLT43f8FNfi5e3gudb8KfAzw94ha6+NXx51aObUbiXUbuZNS1Pwx4SudVM3/CXfFDXUuDdXc91Jd2Xh1Lxde8UyySXGmaTrfrv/AASV/wCCOPxS/wCCh3iiy+IfjYaz8M/2SPDmqmHxL8Q44PsmvfEi606bZe+CPhKl3C8M8vmI1j4h8cyQT6J4YHnW9kmr+IIzp1r/AKHHwb+DXww/Z9+GvhP4QfBvwZovgD4c+CNMi0nw34Y0G38izs7ZCXlnnldpLrUdTv7h5b7VtX1Ge61TV9RuLnUdSu7q9uZ55PjssyrMuLcVDN89lKnlsPewmEi5U4VotxfLRhfmp4duK9rXk3WxFlGMmkp0/wCmeOfETgf6OHD+K8NvCOlQxvHGJhGHEXE2IVHGV8uxCg4+3zGv7NUcXnFJTn9SyinCOXZPzzqYqg6062GxmL+z3+z58JP2WvhD4N+BvwQ8I2Pgv4deB9OWw0jSrQGW5u7iQ+bqOua5qMgN3rfiPXL1pdS1zW7+SW91K/nlnmkwURMIa4+q/tWP4cibdF4F/Z+j1q+QcrHL8VPiI9lppbqFeRPg/qm0HDFFJ5U19C18R/s3ao3jj9pX9urx8kvnad4f+Jnwq/Z70aTgqbX4UfCDw9481tIzkjbbeNvjh4ssJQOFuLKZG/eI4H6PVjCl9Rw1KMadN1o0406cVGMKVChVqwjGKsowjKlTgklZXSSsz+HsJVxOYf6z5zjq9bGY6OXVcXWxmKqzr18Tjc0zfL8BiatetUcp1cRXoY/G1pznKU5yjOo22pM9Q/a0/Zk+HX7Yn7PPxQ/Z0+KNoJvC3xI8OXGmJqUUMU2peFvEFs6ah4X8ZaGZcLFrnhPxBa6drumMWWKa4sRaXYlsri5hl/k//wCDf743/ET9if8Abb/aK/4JVftB3B0m81vxL4i1TwTZTzSLpVt8ZPAthHJ4gPhw3LxKdC+L3wvtNO8b6FOEC38HhrTZLWPz9YlMn9plfyG/8HGv7P3iT9nz4x/sv/8ABWD4H2RsPGXw1+IHgfwt8UZ7JDGt1rXhPUD4g+EniTVPJIZ7fU7ay1/4Y+Ibuf5J9OvvB+jnMZCN4HElB4SeC4iw8X7fKqkVi4xvevllaXJiKbS+KVJTlUp83uwUqk7OUY2/ZfA/NqPEOF4o8Fs6rQWU+IWCq1eHKleSVLKePMto/WckxdOTX7qGYyw1PA4tU3GpipUsDhuaNOdVS/ryorzn4QfEzw38aPhT8Nvi94OuFuvCvxP8CeE/H3h2dXVy+jeLtCsde05ZGT5RNHbX8cc6DmOZJI3AdWUejV9TGUZxjOMlKM4qUZLaUZJNSXk0015H8+16FbDVq2GxFOdHEYerUoV6NSLjUpVqU3Tq05xesZ05xlGUXqpJoK+f/AviZfjB401Xxrpcnn/DL4f6hq/hTwNfoS1p4z8aWklxpHjjxrp8oxFd6F4blS+8A+Gr+EmDUNRHj29hN1pcvh7UJvm/4n/F7Xf2n/in4i/ZK/Z41y+svCvgu/j0z9r/APaC8N3Tw23w40+aKK5uP2fPhjr9sQlx8ffGunTJb+KdW02WT/hR/g68uNZvZYfiDqnhHT7fX/b8+NWg/sO/8E+/jt8RvBlhYeHF+GPwem8GfCPw/pUUdnaWfi/XbWz+Hfwp0LR7KJf9Ta+JdY8Pww2lujOtnbybRtjZhwVMZTccRiHL/YsDCrUrVlrGpUw8ZTqQpvaUMPyP2so6OulSU1KjXgfV4PhzGfWMnydUl/rHxTiMBgsuy+X8XA4TNq1GhhK+Mgk5UMTm3t6f1ShUtUhlc5Y6pSVPH5dXMT/gnD4hHxN8FftI/H+Jxc6Z8eP2xfj14i8K3/3hf+Bfhlq2lfs8+C7uF8Ye0vNE+DkGo2pUtGyXxdCVfJ/RSvlD9hT4Gt+zX+xx+zT8DbiMx6r8Ovg54I0XxMW+/P4yl0a21LxreSHq0l94svtZvJHPzO87MxLEmvq+tsDTqU8Hho1Vy1vYwnXX/URUSqV//K0ps4eLcVg8ZxNnlbLpOeWLMsVh8qk7X/snB1HhMqWmnu5fQw0dOwUUUV1nzp5x8Yxn4R/FEevw78af+o5qVf5O2kjGlaYe39nWOOn/AD6Qf4D2r/Wf+ImiX/ib4f8Ajnw5pfk/2nr/AIP8S6Lp32mQw2/27VNGvbK0E8oVzFCbieMSyhHMabnCsVwf4ObD/g3Q/wCClltYWNrLo/wCZ7a0toHK/GG7wXhgSNiv/FEYxuU4+bpz14qZptKy73+fLb8V/nYVt/N3/BL9D5b/AGFf+Co/7R3/AAT48LfEHwj8DdC+E+saV8SvE+meLfEEvxF8OeJNbvrfVNK0WHQreLS5dD8X+GoILN7OGN5orm3u5jcAtHcRIWjP0Z8bv+C+3/BQj41+ANf+HY134YfCjTPE9hc6TrOv/CbwbrGjeM30m9he3v7HTPEXiPxb4pk0Bry3kkgk1TRLWx122Ry2natYzYlG8f8Ag3b/AOCliZ2+H/gQ46/L8Y5R2/2/Bq/z/HHTS0j/AINz/wDgpFqN1HBf2/7PmgQMyh73Ufi1q11DEpI3MYdH8A6jcvtGThYsnjFR79ra/gu3Xf8Ap9mN6/dbX+v+G2PwkRFRVRAFVQFVR0CgAADqeAPc1/bb/wAG1n7NGufDX9mz4r/tF+KNLm026/aN8YaJZeBxdwNFPffDL4X22rafpmvwBxuFj4g8XeI/GJs3+5e6fpWnalCZLW8t5X8r/ZE/4Np/CHhDxFpHjL9sn4s6f8VYdLuYbz/hT/wusdX0HwLqs0DpLHbeLPGusPZ+K/EGjSEFbrR9H0Xwd9qUeVdajdWbzWs39R2i6Lo/hvR9K8O+HtK07QtA0LTbHRtE0XR7K203StH0nTLWKy03TNM0+0jhtLHT7CzghtbOztoY7e2t4o4YY0jRVFRjZ3fy/wA/u/4bQPLzV9O1mtfXfpp16f5yX/BZf4j/APCz/wDgpr+1bqyS+dZ+FfFvhz4YWADbkhi+HHgjw54b1OBOwC+JbfXpJFHHnSykgMzV+jf/AAbG+Axq/wC1T+0P8R5LcPD4G+BWj+FIJyoIhvviL46stSO1uodrL4eXCMFzhJMOyCSNLjgPjR/wQZ/4KafFj4zfF/4q3WifAhp/if8AFT4h/EN/O+MN0s0a+M/F2seIYYZh/wAIW+JIINQihYB3CiMKGbbz+5v/AAQ//wCCdPxz/YH8H/tBv+0FbeCrXxl8VfF3ghtGg8E+JpPFNmnhTwXoOqrayXl8+k6T9nupda8Ua4otPKmVIollV1aeWS7lJ8ybT3bfbuv6f+aQ9Ov8q381pre/byfkj91sfX8z/jX8xP8Awc//AA4bVf2cv2aPizDCXfwB8cdY8GXcoGTFp3xP8D6jdMzt1CPq3w/0eIZbHmPGoBYqK/p3r81f+Ctn7Jfj39tP9iD4i/BP4U2uiXvxQl8RfDzxh4EtfEWqx6FpM+reE/Gmj6hqMNzrEtvcpp7T+GW163hnaIq880cDsizF1uSbi7Xvo9N9GmGnX+n0/E/zb5GuEhmltGaO7hiea0kU4aO6hHm20ikchkmRHUjkMARzX+nJ4l+Ilv8AF7/gnV4k+K1tKk0HxJ/Yw13x2siMGUnxX8ErvXJFyCRuSS+eNx1V1ZTyDX8dC/8ABu//AMFKwBnw78CeQMgfGJyOR0JPg8E4JOcDHYEjmv6u/wBln9m/48/D3/glvo37KvxSt/DMfxu0X9n/AOKfwgt4tJ8SHWPDLyX9r4z0H4eL/wAJAdPtCtqPD194bhvZDYn7C0c6bZfJ+YV7ybVr2/Ba/n/VnYuk4/5ej/4fS17a7H+b1pPGlaZ/2DrL9bWI1/bR/wAGxjZ/ZF/aBX0/ac1M/gfhV8Mcfpj8OehBb8XrP/g3e/4KV29jZW7+HvgYZILO1gfHxhJG+KCON8E+E+QGU4IyMcjPSv6Vf+CJv7EPx6/YV+AHxa+Hv7QNl4RsPE3jL413fjjRYPB/ib/hKbJvD8vgTwToCS3V6NP04W922paHqCm18pysSxy7j5pkmmCaeq6f5AfoX+2RCbj9kP8AaogA3Gb9nD44RAdyX+GfidQPqScY71/lgWh/0W1I72tuR+MKV/rR+PfCFh8QfAvjTwFqsjxaX428J+IvCOpSRKryR6f4k0i80a9eNH+RnW2vZSqt8pYAHiv4OX/4Nxv+Ckenu9ja23wD1K0spJbK0vx8V7+1e/tbSRoLW/a1n8Fl7U3tvHHcm1d3kt2l8l3LITRO7asns9ttbb+f6XLjy21/Ha2ny3R+0f8AwbD3aSfsb/HeyDAvaftPa1Ky55C3nwt+F7KxHUBzC2PUCv5S/wDgoj8Q/wDhav7ev7YPjtLg3Vrqf7QnxH0jTZy+8SaN4K1mTwJohRskNGNK8M2giwSNmMcV/Yx/wRW/Yb/a8/YI+G/7SvgP436D8PF/4TfXvDvjz4ZyeFPHf/CR2114ltfDGo+Hta0zWQ2jaa+m20v9l+FJILwpOrLLehkzAof+fi//AODeP/gp/rGq6nreraV8BbnVNc1TUda1W6PxjuD5+paxez6jqM5J8GbiZbu6nkJwSS2SSeKJJuMbJ6LXTqrL17/1qKL1abtpZdnot3+q+/ofd3/Brf4ES48V/tjfFCaHLaboPwa+Hen3BXodSu/HPinW4Eb1xY+HJJVBJH7guAGjLf2CV+M3/BE/9gn4u/sE/AD4q+Efjrb+FLf4jfET4x3Xi4p4O18+JdLTwnYeC/CWgaBFLqbafprm7GoWXiGeW2Nttt1uEKs7yyzT/szVRVorS3/Dila7ttovuVj+Sf8A4Oj/AAABYfsc/FiCDH2fU/i98NNUugvU6vp3hDxdoMLydfl/4RvxI8ak9WcqPvY/kl0bxNfeDdd0HxlpTsmqeDPEGg+MNMkQkOmo+FNYsvEFk6Echhc6dEVYYYHoQcEf6H//AAWg/Yf+Kn7d/wCyn4a+GvwRg8K3HxM8GfGbwh8Q9Hi8Ya7J4b0mfSbTRPFXhjxFbf2vHp2qGC4bTvE/2uGJrbZcPZCIyIxTP8uh/wCDdT/gpdKrRy+HPgQEkVo3H/C42YFXBU5B8H8jaSOh7ZU5NZuLUpNJ2bTW+mivb53ZcWkt9et7ei3t09evkf3r+CfFOn+OPBnhHxrpEiy6V4w8MaB4p0yVGDJJp/iDSrTVrKRGHDK9tdxMrDgggjiun/z+n+PFfLX7Efw/+Kfwn/ZF/Z0+Fnxrj0qP4o/DX4SeDfAHi9dD1b+3dKe+8G6Rb+HLaey1fyLU30V1p2m2V00rW8TiWaSN1LozN9S1qr2XTytb8Omn/DdDM83+Mgz8IfioOOfhx44HPTnwzqYr/J10lv8AiV6YOubCyH0xaxD+f9a/1ofiJoV/4o+H/jnw1pbQLqfiHwf4m0PTmunMVsL7VtFvbC0NxKqSNHB9ouI/OkSN2SPcyoxAU/wa2v8Awblf8FLLSztLc6V8AJXt7a3hZk+L96FZookRiBJ4IU4JUkZxwfXopLa6vvt6q3b8+/QVt/N3/BL9D9Tv+DW5s/Db9sxPT4n/AAqb8/AuqD+nX8q8t/4Onv8AkMfsUf8AYN+Pf/pX8If54r9I/wDghv8A8E/f2jv2CfB/7R+j/tEWPgiwv/ib418B6z4Vi8F+LW8Wwyaf4c8Najpeoy3850rSvschuruBLeExyNIiSOSiqobkv+C5f/BNz9pj9vy8/Zqu/wBni2+H12PhfB8VbXxbF448YT+E2i/4S+X4fTaLNprRaHrK36n/AIRrVI7tcwPbsbZgsqysYi1422dkvyv/AMHy77N/1tf8D+TD/gnCSv8AwUE/YqI6j9pj4Tj67vE1ouOOcndx154wa/02K/i2/Y9/4IUft6fBb9q79nD4xeOrH4K2/gz4XfGbwF478Uvo3xPvdW1ddC8Oa5bahqI03Tn8HWcd7em3jdYbZ7y3SR+GkK5jl/tJHQf5/wAf5miKtffpv6Lp5f8AAu7AfxKf8HMPwHPgz9qL4NftBadZ+TpPxt+GN14N1+4jX5JvG/wk1FPKuLlwABcah4M8XaJZ24cs8lv4Zl2nbCQv82Vf6Kv/AAWP/YV8a/t6fso2XgH4Tw+HH+MXgH4leFfiB4AbxRqjaFpN2irfeGfF2j3etJZag1hBe+FfEGo30ebWVLjU9I0yF9oIdf5a/wDiHf8A+CmQOD4Z+BJHqvxmP/s3g8H9B26VEk+ZtLzX4fr/AMNYN391+n9d36n9Mv8AwQKOf+CW3wAGc7dd+NC/l8aPHgr+XP8A4ODfm/4Kg/FEDH/JKvgZj6f8IvfH/Hp6cV/YN/wSj/Zp+Kf7In7Dfwo+A3xntNBsfiJ4R1b4l3ut2vhrWl8Q6PFD4n+JfizxPpAtdWS1s1umfR9WsXnAt4zBO0kDZaIsfxC/4K0/8EdP21v2wv23/G/x6+Cek/Cm++Huv+A/hjoGny+K/iNJ4a1oal4T0S50/VUm0pfDepqkAnkX7NP9qPnId2xCpFaLZadI/kv6a3W24H8wf7PXx48dfsy/Gr4ffHv4apoUvjr4aate6z4cj8T6dc6toLXeoaJqvh+4GpafaahpVzdQ/wBn6xeeWsOoWrx3AhlEhEZR/wBe9a/4OMv+Ci2qaRdadYN8AfDt7cQvFFr+k/CzVrnVLFnUgXNnb69451jQ3njzuQaho9/bbgPMtZFytYg/4N3P+Cl3fw/8Bh/3WSU/+6X/AIVZg/4N1v8AgpRK6rJpPwBtlJAMk3xhvmRB3LLb+BJ5Dj0VSaNF318n2Xlppb+rhb+v6/rfuz8ZviV8SvH3xi8eeKfih8UvFus+OviD411R9Z8U+LPEFytzqmr37RRW6PIY44ba1tbS0gt7DTdNsLe00zStNtbTTdNs7WxtYLeP9sP+Dev9ljXvjR+21Y/He90mZvhp+zFo+reIL3WZoW/s+9+J3i3RNQ8M+C/DVtMRsl1Gx0vVdd8YXSxlmsI9J0lrnyv7VsjN9P8AwG/4Nj/jRrGtWF5+0x8f/h/4K8KxyxS6j4e+C1lrXjPxdqUCupmsoPE/jHR/DOg+HpZo9yrqA8O+KliJDCyZhmv6vP2b/wBmv4NfsmfCXw78FPgV4PtPBvgXw6JZxBHJJe6trutXixf2r4n8U61dF7/xB4m1mSGOTUdWv5ZJnSK3s7ZbbTrKxsraVFNp2a669/xfrf5Arfhofz1/8HQ3xFOnfAf9lz4RxThX8b/GPxT4/u4Fb5nsfhp4Jn0ZGkTPMY1D4lWjoSMeZFlfmXj+R39n/wADP8Tfj58CfhusIuB8QfjT8KfBUkG0v5sHifx3oGj3SFACXBtLyYsADkAjB6H+yL/gt3/wTX/bI/b1+MvwQ174A6X8Or/wD8Mfhl4j0m8bxn4+/wCEVvv+Ew8WeKY7zVFtLBdF1UzWq6LoHh3F40kQkmeaDyz9n3N8DfsHf8EJf23/AIMftj/s6/GH406R8ILD4a/Cz4j2Xj3xFL4e+JcniHWWl8O6Xqd7oEVjpP8AwjNkt07+Jl0bzAbuFIYBPcOZUha1uk03LZ2ukntbVXav/wANu+4+1uh/aBGqogCABeoAxgA88Y4x6Y/M9a8K/al+HQ+Lv7NP7QXwuEAuJfiH8Ffif4MtoWBYNe+I/BWtaTZEKM5ZLu6hdcDO5QRzXu6jCgegGevXvnJY59csT6k9aRhlWBAIIIIIyCO4IJAII4IJwQcVoStlfsr/ANL9D/JPsmka0tjKpSYQxpMhGCkyKEmQg5IKSq6kHkEEHmv7Sv8Ag2L+JJ1n9mz9o34TzTh5vh78cdO8YWcJbLQ6T8TPBOkwRhEPzCJ9Y8C63LwAvmyyn7zEn8sPiP8A8G9P/BQK7+JPxIu/A2hfBeXwNf8AxE8dah4Km1D4qCwvpPCGoeKtXvfDLXunjwxcCxujos9iJ7QSym2mDwljs3H9ef8AgiT/AME3v2yv2C/i98cNX+POn/Dmy+HfxQ+HHhvTrYeDvHreKNQPjTwh4lnuNHa4086FpghtG0PxH4mEl59okKTJbQ+WRNuXKKae2ltfz/y/HsVpbfW+3l3PwB/4LxjH/BUz9of30D4KH8P+FQeEB+fyn/PA5H/gicwX/gqL+ygT31z4jr+LfBr4iKP1OB6nAAJIB/Yr/gqZ/wAEZ/22f2uP24/iz8ffg3YfCCf4eeMtG+Gljo0ni34j3nh3XGuPC3w/0Hw5q32rSoPCerpBGupafcrav9sdprcRzbUL+WvNf8E3/wDgid+3J+zD+2x8CPj38VbT4M23gH4daz4qv/ET+GviVqGu64bbWPh94t8M2qWGlyeDtNiupG1LW7MSq19bqlt58rM6xG2uberV4vRrXRde76a66WWva4vn+fS3W1v6Z/YGn3V/3R/IV/FX/wAHQfH7TH7Lp/6oP40/T4iWJ/rX9qo6D6D/AD1P8z9TX82//Bbn/gl9+1b+3l8aPgj45/Z9svhxd6D4C+FviPwl4hPjXxvL4VvI9X1Txdba1afYrePQtX+12psoX3zl4dk37vY2d4ck2nbfT8/MD+OH4SsR8XPhER2+K3wy/wDU50D+uP0Ff6s/XpX8K3gX/g3v/wCCiOgeO/AfiPUrP4Bx6d4d8c+C/EOoi1+LGqXF3/Z2heJ9J1a/FtC/gKKKa5+yWk/kRPNGkkgVGfaSr/3UDoPbjv2+pJ/Mn6mhbbW/rv1/MBazNb0mx17RtV0PVLdLzTNY0690vUbSQZju7G/tpLS8tpB0aO4t5ZInByCrnIPStOih36f1qv0uB/lmftX/ALPPif8AZR/aN+L37Pniy0uba9+GvjHU9K0a6uYniGveCrqZtR8CeKLTeAJbLxB4TutK1BHTIiuJLmzk23NrPGn05/wT1/4Kf/H3/gnVrfixPhxpnhrx/wDDjx/cWOoeMvhh40k1C10y41vTYDZ2nibw5rmlsb/w34h/s/bpt9OLXVNM1axhs49R0qe407Tbqz/tE/4KU/8ABKX4L/8ABRHw9pusalqc/wAMPjv4P02bTfBHxe0bS4dVkk0tppbweEvHWgyXNgPFfhJr2Wa5s4F1HTdX0G9ubm70TVLaK91Sx1L+Tj4r/wDBAf8A4KWfDbVry08OfDDwT8adEgkYWviP4Z/EvwrZrdwZ/dyy+H/iLe+B9etJ2H+tt4rW/iifMcd7cqBK+bUovS7Stbfy0fz087aDeu39baW+dtFr0Kn7f3/Ba/8AaO/bw+G8nwTuPBng74K/CDUtQ07U/FvhzwjquseI/EHjmXR7221PSdN8R+KNUg0uFfDlhq1paasujaVoNg93qFpaSalf3sFvFar+NQDEhI45ZpXZY4oYY3lmmlkYJFBBDGGeWaaRljghjVpJZGSNFZ2UH9W/Cn/BEL/gqH4s1GOwX9mC68LxvIqS6r40+Jfwo0bSrVWYAzTG08aarqc0aDLMthpl7OwB8uGRsKf6F/8Agmv/AMEA/C37NfjTw38ef2rvFXh34u/Fnwre2uteB/h34UtryT4U+A9ftWWey8RajqGtWdhqvj/xNpNwsdxo0l1o+g6Bod/EL2HS9Yv4dP1WzVpSevkn5bdHbv8APWwet9f+A/8Ahv8AgH6b/wDBKb9mXVv2S/2EPgR8JvFOntpnjufQr74gfESwlXZc6f42+I+qXfi/V9Fu1/5+vDUWqWfheYgkM+ikqSpWv4P/APgqnn/h5P8Attgf9F417H1/sPw9/Un2r/TRr+LX9uf/AIIWft8/H79sr9pX44fDrT/gpceA/ip8U9U8X+E5Nd+J95o+tHR73TdJtov7T0tfB99HZXQmspw0CXlwoXY3mfMQLknZJK9v+G/UOt7ddt/kfKv/AAbuf8pK/DB/6oV8Y/1Xwf8A4V/ST/wcHEr/AMEtPjcR/wBDl8Dh+fxl8EjP54r8+f8AgkR/wSC/bK/Yx/bK0f44/G+w+FVr4EsPhd8Q/Ccz+EfiDceJdZOs+Jn8O/2WE02TwzpcZtdmm3f2if7WGhIjAjk8w7P2L/4K1/su/Fb9sf8AYa+J3wC+CkPhy4+InirxF8L9S0eLxXrTeHtDa28K/Enwv4l1g3WrJY6i1u6aRpd69sos5fPuFjg+TzN6u3u2Stddf1/q4v6R/m5X/wDx4X//AF43v/pNL+Nf6r3wIO74H/BpvX4U/Dw9u/hHRz24/Liv4cL3/g3X/wCCks1ndwx6X8AfMntLmFB/wuC/wJJYXjXcT4D+7lsk4YgdVbG1v7pvhT4d1Pwh8Lvhv4T1oQrrHhjwF4Q8PasLaXz7Yalovh7TtOvxbz4XzoRdW0oilKgyJtcjLURTu732Vr9tdPVdfv6i6r0f6f18z8E/+DlD4Dnx9+xp4G+OWnWZm1n9nn4qaXPqdyibng8A/FNIfBOvqzAbhEPFp+H13IT8iR2kkjY28/w41/qZ/tZ/ArT/ANpv9mb46fAHUTBGnxX+GPi3whp93c/6nTPEGoaVcHwxrLkK5B0TxJFpWroyozLJZIyjcAR/EjF/wbs/8FMhFF52ifAFpPKj83y/jFdbfN2DzNpfwUDtD5wSORUyi27rW+/4L+vmM/Sv/g1qb/inv23U7jxR8CG9+fD/AMRh/T+dP/4Om8/8Ih+xMMdfGfxvA5/6lvwCenuB+lfav/BDb/gnp+0r+wTp/wC03a/tE6b4H06X4pat8KLzwgfBXjEeLY54fCWmeN7TWzqDHStKawZJdb0z7MjRy/aA87Ap5J3z/wDBc3/gnx+0j+3t4c/ZpsP2ddN8FanffCzxR8StT8VxeMvGC+EY47LxVonhey0p9PmbS9TF65uNHu0uYgkTQo0UgMgYqKS91K1tOv6/5fIP63v030/r1P4OXIkVkPAYYJ7jJ4PftX73ab/wcb/8FAdL0+w02Dw5+zU9vp9na2MJl+G/jZpDDaQR28bSMnxSiUuyRqz7UVNxbYiKVReK/wCIeb/gpj38IfA/r1HxogPTvz4SH4U8f8G83/BTD/oUvgh9D8Z4f6eFP61HvLbm1te66q239bAegj/g5F/4KCHP/FMfszj/ALpv459P+yqn0PH5V+uH/BGz/grH+09+3t+0P8TPhV8cNH+Een+HPCPwZuvH+kz/AA+8J+IvD+qvrcHjbwn4dEd9c6x408S28+nmw1u7b7PFZ2032lYZPtBRGif8TT/wb0f8FMR/zJ3wRP0+NEH9fC4r9iP+CKP/AAS5/a7/AGHf2k/ih8Tv2gtB+H2k+E/FXwQvfAujzeEfH0Hiy+l8Qz+O/B2vxxXNjHpOnvbWv9m6Lfubou6CVYodmZQQ4819b20v8vX73bcP6/L9V+m2/wA4f8HTOf7d/Yl9P7L/AGgMfX7T8H8/yFfyleHj/wAVD4d748RaAfy1ix/wr+6X/guV/wAE4f2mv2+dS/Zou/2d9P8AAV9H8LbT4sweLR428ZN4T8pvGEvw8fRDp23SNVN+HHhvVPtXEP2crb58zzvk/CDSf+Dd3/gpRaatpF5c6D8C1t7PVtMvJzD8YHkdYbS/t7iUoj+EFDP5cblVJwWwOehp9d909r6Ll/r7+w10s+v3f8D/AIJ/fPF/qo/+uaf+giv47P8Ag6XV18f/ALFspB8tvCPx0iU443jW/hQzDpjO1lyPQiv7FEBVVB6hVB+oAB6kn8yfqa/C/wD4Lgf8E1/jF/wUA8DfAfU/gFP4Ob4jfB7xX4thu9I8a65P4Z0zV/Bfj3TNIXVZrbWoNM1cJqWj614U0Ce3sZrWOK7srzUmFyk8EEM5JXTS8vzQRaV79V/k+vp/wD+Dbw1OIfEvhmZiAsPibw7MT2Cw61YyknrwAmSfQGv9WH4j+BND+K/w08d/DPxIhl8OfEfwP4m8D66iqrs+jeLtCvdC1HYr/Kz/AGPUJimeN+05HWv4SX/4N2v+Cl+xxHo3wIjlCt5MqfGKfMcoGY5VJ8FAhkfDqcAhgDx2/uz+FUfjSH4YfDmH4j2llYfEOHwL4Sh8d2WmX41TTbXxjFoNhH4mg0/U1igGoWMesreraXvkQm5txHMYYi5RVC60at1/Bf19/VBfbXz+fz6n+Wr8afhJ40/Z/wDi18Rvgj8Q7CXTfGnwt8W6t4N16CWN40uZtJuDHZaxZ7wpn0nxDpbWOv6LeIDFe6TqVndQs0cyvX2J/wAE/v8Agpr+0F/wTv1/xTN8Lrfw1408AePZrG88a/C7xwmoDQdR1fTYGtLLxLoeqaTcQan4a8Sx2Lf2fc3sCX2n6nYxWsOraTfPp2mS2X9i3/BTz/gj58J/+Cgsdt8RfD+uxfCD9pHQdITSNO+IsGlf2r4e8baPZh303w38TNCgnsrnUrfT3d4dE8T6bdweINBt7iS3ddb0mG30VP5WviV/wQb/AOCm3w81S6s9M+Cfh34raZBM8dv4j+F/xP8ABF1YX0Sk7Z49K8b6r4G8T2+8YPlXGhoVYlA8m3cRJLSz9Vdvp62u+m2nmH9av0/rf7jY/b1/4Lc/tIftz/C64+CEvgzwZ8FfhRrV3p95400TwfqeteIfEXjldKvLfUtP0fW/E2qx6dDbeGrfVLS01KXSNM0O1nv7q0t11HUrqyR7KT8cNJ0jWPEOraV4e8O6Xe654h8Qapp+heH9D02CS61LWtc1i8h07SNI0+2iDS3N9qWoXNvZWkEal5bieNFBLCv1W8Ef8EOv+Cn3jbUobE/s2HwVbSSpHNrfxA+JPwz0PSbJGYK09xFpXirxDr08UYO5l0zQ7+cqDshY4B/pT/4Jhf8ABDHwN+xp4r0j49fH3xPonxl/aC0eOSTwdYaJYXUXwv8AhRfXEUlvPq/h1NYgg1fxd4xW2kkt7PxbrVho8GjRXE50Tw5ZakF1l6+933urfp91lq/mxH6l/sI/s7H9k/8AZB+AH7P9yYH1n4e/D3S7XxZNasr29z451uS48S+Orm3lUkTW03i/Wdae1lyS9sYTX8D3/BZTj/gqH+2SOx8f+Dz+fwh+HJ/rX+ktX8bP/BRb/giN+3h+0x+29+0T8evhbpXweuPh78TPFfh/V/C83iH4mzaJrbWWmfD/AMH+G7k6jpK+Fr5LOX+0tFvhHGt3PvgEMxZfMKIPpbo1+Vl8lp6JAfn7/wAEF2/42i/APtu8JfGsf+Yq8RnH5iv9Civ5Jv8Aglh/wRu/bW/ZJ/bd+FXx8+MmnfCm0+H/AIP0P4kafq7+FviJL4h1sXHijwJrPh7Svs+mN4b01JozqN7Atwwu1MMJaUK+wqf62aUbq/rp6WVvW23X1AKKKKoAooooAKKKKAG89hxgdeMY6DHPOep7AetOpvXGBxgHnpx0wPX1PtTqX4/lo/nqvz/ACiiimAUUUUAFeVfHT4T+Gvjv8GPip8FfGUQl8K/Fb4feLvh7r48tJHi0zxdoV9odzdQK4Ki6sUvvttpJ96K5t4pFIZQR6rSMAwKnoQQe3BGDz1H4c1M4RqQlTnFThOMoTi9pRknGUX5NNp+TNsNiK+DxGHxeGqzo4nC16OJw9am7TpV6FSNWjVg+k6dSEZxfRpNH+Qj8Svh54p+D3xE8ffCTxxaNY+NPhb408UfDvxVasrL5ev8Ag3WrzQNSdA4DNBcXFi11ayYCzWs0MybkkVm+iv2B/wBqS/8A2Mf2vvgR+0bby3A0TwL4ytrX4gWdtln1T4X+KYpPDHxEsfKAInli8M6pe6rp8TIyjWNL02cLvhQj9ev+DlX9kC4+C37X/h/9pzw3pZh8A/tS6HGPEE8EIS1074zfD3TbHR9ehn8seVC/i7wbH4b8QWjSbZtS1PTfFt0AzQTPX84eFdGjcZV1KsOuQw2kYx0wf/15xX874vDV8kzatQjKUa2X4uM6FSXxShTnGth6ztvz0/ZVbXsuZq907f7U8K53lHix4b5bmmIpU6+XcX8Ozwec4ODjy06+JoVMuzzAJ2bg8Ni1i8PCo1zcsFVj8UWf3df8F5f+CZvwW/aQ/Z88bf8ABQP4Xajo3hL4w/Cv4Z/8LB8S+ItLhjm8MfHn4W6JpUWoQwa49lxJ4s0vw8qT+BfGcInnvNOS38K60t3pD6JfeGv4PVc4747Dp/jkV/Ql8Av+CyNvP/wS6/aI/wCCd37RcerHxHB+z9438Afs3/Fm2iuNUsdY0r+ypY/DXwp8dRQpLe6ZqelQBdA8GeKVjl0a90aPTdE8QPo9xpsWr6x/PbGNw/D0xz/nJ9/pXpcT4vLMwxWEzDAQhSli8LGpjqcdJQxanONSNWHSpZRvUjFQrpqsnNzlN/FeAXDnHHBmQ8R8G8ZYjEYzCcN8QTwfCWNrpTpYnhyeFo1cLVwWI1lLCSnKahhJznUyyp7XAyVKFGlRh+u//BCVfB7f8FVf2WbrxrrOj6JYafe/Eq60abXL610+21DxhcfCvxlpXhXRrSa8kihm1jUdU1OOPSLJWN1fagsFpZJNeTQRv/oq/tD/AAqsfjt8AvjV8FtREZsviz8KfH/w6naUApCPGPhbVNAS454DWst+lwjEfJJErdq/yOQrKRKheNopY5UmjZkeCZJFaCaOZCrwyxzeW0MiMsiTbDGwfaa/oj/4J7f8HEP7Sf7LsOhfDX9pq01f9qL4IWK2mnWmt3mpQx/HbwRpcQ8lBpXinU5YrD4jWNpCQY9G8dXNrrjLFHbweOLS0iis69fhLiPL8tw1bK8xpzp0cTWlV+tRTqQXtqNOjKnXhFOpGFqS5akFNLnalGCi5H5x9I/wR4x45zvKOPuCsZQxmaZBlWDwC4erThhMVL+zswxmZUcdleLqzWFq4h1sc1VweKlhfdoQlQxFetVjhV/PXdaff6LNeaVrUEllquh3F5pOsWsylJbTVNHuJdP1O2mQ/MktveWtxDIrAFWjOehAs6xpGr+H9Rn0jXtLvtG1W1js5rjT9St5LS7hh1CxtdT06doJVV2t9Q0y9stSsLhcw3un3lre2kkttcQyyfTH7bPib4QePP2tP2g/iD8BdXfWvhB8TviRrXxR8Eyz6TqGhXul2vxK8jxtrHhnU9H1OC3vNN1Pwl4l1vXPDV7asstt5ul+dYXd9p81re3H7m2X/BPuP/gqD/wSW+AX7TnwB0y3uv2yf2XPCut/AP4g+GrIQxT/ABw8HfB29n0/wv4WuWBjST4j6D8OJfCOpeA9SuSsus2d9N4L1KWS2l8M3mgfK4XKauMrY/DYSSxFfBQq1acKbVT63RoVo0qrw8otqpNxnGvSUW1WpRqKm5TcIy/fs+8RcBwvlvBud8R4arlGUcU4rL8tx+LxcKmHlw3mma5ZLHZdHNaVaMJ4bCxxGFxGW5hVrKnLAYythZ4j2dCGKnS/O3/gkH/wUv1z/gnR+0OmoeJZ9S1T9m74s3WlaD8cvC1r511Jo6W7tbaL8WPD2noXMniPwWtzKuq2kEZn8SeEptS0gCXU7bQJ7D/Sg8L+KPD3jXw3oHjDwlrWm+I/C3inRtN8QeHPEGj3kN/pGt6JrFnDf6XqmmX0DPDeWN/ZTw3Vrcws0c0EqOpINf4/k9vc2c9xZ3trc2V9ZXM9nfWV7bzWl7Y3lpK9veWN7Z3CR3FpeWlxHLb3dpcRxz288bwzIrowH9SX/Bv3/wAFbY/gp4h0P9hb9pHxULf4ReMdY+yfs++O9evdtl8NfGetXbu3wx1q/uZNlj4H8ZancNL4TupXS18N+LbyXS5iukeIYZdF+s4K4l+pVVlGPqNYSrN/VKtR2WGrzd3Sk38NCtJtp7Uq7baUK05w/nX6Ungc+KcDW8SOEsH7TiHLMLGXEWX4WnepnmU4akowzHD04XdXMsroQUKkEpTxmXU404P22Bw1DFf3H0V89/tA/tYfs2fsq+Gm8W/tEfGv4efCPRjFJLZ/8Jh4hs7HV9Z8vh4fDnhuNp/Efia7B4+xeHtJ1O8J4WAmv5pv2vP+DpH4e6HHqfhb9iT4Oap8QtYXzrW3+LfxpgvfCPgO3cFkF9ofw9sJ4vG/iiF1Cy2/9vaj8PjG4Hm2l1HmNv0rMc7yvKk/ruMpU6iV1Qi/aYiXbloU+aok20lKUYwTfvSSuz+G+CfCnxA8Q60I8K8NY/HYWU+Sea1oLBZNRs7T9pmmLdHBynBXlKhRq1cVJJ+zoTlaL/qy8beO/BXw08L6v43+Ini3w34F8G+H7R77XfFXi7WtO8O+HtHtE+9calq+rXFpYWcWSFD3E8YaRljTc7qp/lk/b8/4OZfh94MTWfhv+wR4ctfij4rUXOn3Hx68d6dfWXwx0aXa8TXXgfwlMdO8QePruEnzLbU9YPhzwuk8Uc0MPivT5dj/AMo37VH7b37VX7afiRfEX7SXxl8UfEGO2upLvRfCJlj0P4deGJXIwfDPgDRUtPDenTJGFjbU3sbrW7hEU32q3UgLlP2Rv2KP2lf24viEPh1+zj8N9S8ZXtpNbjxR4tvC+kfDv4f2dxll1Dxz40uIZNN0ZTCss1rpEC3/AIm1hYpI9C0PVJx5Q/N8y44zLM6iwORYarQ9tL2cKkYqtjq19LU4wU4UHa7fJ7WpFLnjUp2bP7Z4F+ilwVwRgpcU+LWeYDN/7OpLF4rBPESy3hLLlCz5sdjcQ8Pis15Z8qhCpHAYapN/V62CxcZx5vMvjd8dfjT+018RtQ+KPx0+Ivi34sfEbXpo7Q614lvJdQuIYZ5yLPw/4Z0e1jj03QNIS4lEOl+GfDOnWGmxSOsVnYea+G/pK/4JUf8ABu54o+Kkvhv4/wD7fGh6r4G+GbNa6z4U/Zyme50fx54+g+W4tbz4rTQPDqHgXwpcrs/4oy2ltvGeswtImtz+FrVfsWq/tr/wTR/4IXfs6/sLNoPxS+Ir2Px+/acs44byLx/rulrH4L+HGotHmaH4T+Ebwzpp11bu7Qr4311r7xbcrGJtNk8M2t1c6RX7nV6mQ8EONRZhn8vrGIk/aLBSm6sVNtSc8ZV5pKvNte9SjKdJ2bqVKyk4R+E8XvpUwqYOfBvg/S/sXJqFF4GpxLRwqy+tLDQj7NYbhnAKFN5RhFTXLDHVaVLHqLSwmHy+VKNetz/hTwn4Y8C+G9D8G+C/D2jeE/CfhnTLTRfDvhrw7ptno+haHpFhClvZabpWl6fDb2VhY2sKLHBbW0McUaABVAroKKK/SEkkkkkkkkkrJJaJJLRJLZH8QTnOpOdSpKU6lSUp1Jzk5TnObcpTnKTcpSlJtylJtttttszda1fTfD+j6tr2sXkOn6Romm32r6pf3DBLey07TbWW8vbudzwkNtbQyzSueFRGJ4Ffn9/wSye/8R/sfeGPjTrNrJaa7+0/8QfjF+1DqEUylZl0/wCOHxP8UeM/BMDg84sfhze+DtNhB4S3soY1+RFrif8Agsh8XNa+Gf7BvxP8I+Cp5E+KP7S+q+E/2T/hVawOVu73xh+0BrUHga5FpsIkFxp/hC98U6zG8fzI+mKwx1H6FfCj4e6N8JPhd8N/hV4djWLQPhp4D8I+AdEjRAippPhDQNP8P6eAgAC/6Jp8WRjrknmvOU/a5s6cfhwWBUqnVOpj637teU6dPAzbV7qGIg2rTTPsXhv7P4BjiqitV4m4odLDX0nHBcKZc3ipW3lQxmM4ow0Yytyyr5TUim5UZqPf18q/twfs1aN+2B+yZ8ef2cdZS3B+J/w91rSNAvLkKY9H8a2Uaa14D1/cVYodC8ZaboerMUwzJZvHkK5r6qr8gP21/wDgtP8Asl/slay3wo8HXmqftSftP6lfLoXhv9nj4ClPFviNvE07iG00jxfr2lQatpnhO5a4Iin0WG31/wAcLlZLPwXfRkuumY4jA0MJW/tGtSpYWrTnRqe1lb2kasXCVKEVedSc4ycY06cZTk3aMW3Y5uDMo4rzbiHLf9TMux+YZ7l+MwuZ4R4Gk5fUq2BrwxNHHYnEScMPgsNh6tKFSri8XWoYajGLlVqwimzwf/g3q/aAHiH/AIJpWng/4m6xZeHNX/ZI8f8AxJ+D/jO68S39vpcHhrw94fu08baXNrd9qEsFtp2meHdE8UnQHuryaK2s7fw3KskkcduSPU9T/ai+M3/BSvxHqvwl/YP1jxD8LP2TtL1S78PfGr9v4WEun6h4witJjba58Ov2N7PVbdDrfiC4Cz6Zq3xwu7WTw34O3XF14Zt9U1iLRrm8/EH/AIJ0fsaeLf2nv2+v20Pgv+3N4d8YfBfwtrF/4K/bY8c/sT+DPGM9r8MvGPiH4t6nea1oOmfEi90m/fVNX0fwRa69ardeEk1CFJNb1Oey1g2b6G2lN/aN4Z8MeG/Bfh7RvCXg/QNG8LeFvDmm2mj6B4c8PabZ6NoeiaTYQrb2Wm6VpWnw29jYWNpAiRW9rawRQwxqERFAxXz2QrHY/K8Lhq0p4XCYOMsDVac6eOxv1OcsPyS0hUwFJQpxhVWmMqz51F4WMVOv+xeLcuFeEePc/wA4y2jhc94i4iq4binA03HDYzhPhn/WTBYfOZV8POEq+F4rx/1nGVquAlFPhzBUPYTqRzytVnQy/hPgj8EPhh+zp8MfC/wf+D/hWy8IeA/CNm1tpmmWrTXF1dXVxK91qmua7qt282pa/wCJde1CW41bxD4i1e5vNX1zVrq61HUru4up5JD+Kv8AwUx8Vj9qn/goJ/wT3/4JpeHnXU/D+nfESw/bR/adtYistrbfDr4OPf6h4A8Ma4EDBLPxZr9hqkF3aXBXN1deELgRst1Ax/b74t/FLwV8EPhh4++MHxH1mDw/4E+GnhLXfGnivWJ2QLZaJ4e0+fUr54kd4/tF3JFAYLGyjbz769lt7O3V7ieJG/n7/wCCEfhDxv8AtLfET9sH/grb8ZtKubDxd+1h4/v/AIffBfTL8ySnwr8DvAGoQ2TafpU0y5l01tR0fw94MS5jKC6m+GVxqADjVHd/SzJwnPL8kw8YwWJnGrXp04qMKOV4GVOpWi4xtyU8RNUcDFWUXGtNJrkPjuBoYjC4TjLxSzatWr1MiwtfA5Ri8VUnVxGZcd8VU8ThMBVVao3PEYnKcJUzPiXEVXOVSnXwODlUv9Yjzf0ipu2ru+9tG7/exz3Pf3p1FFe6fkgUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUEA9QD9aKKAECqOgA+gA/lS0UUAFFFFABRRRQAUUUUAFFFBIHWgAor8qP2u/+CzX7Cn7HHiHU/AXjT4g6r8R/ilo0sltrPw0+DWkweNvEHh68j3K1j4p1aXUdI8HeF9RjlUxXOja14mtNetcb5dJCFGf89tD/AODn/wDZIvdZS0139n79o3QtFeUIdZt4vhlrVxFEWAM02kW/j22mIUHc0dvc3EpAIRXbAKutr/1ov1QH9MFFfIP7Jv7d/wCy1+214fvNc/Z4+KWleLb7R4ILjxN4Lv4Lvw78QPCcdwwjik8Q+DdahtNZtLKSc/Z4NZt4LvQbu4zDZarcyBlGb+3L+3T8Iv2APhX4d+Lvxl0Tx9r/AIb8T+PdN+HenWfw70fRta1lNc1TQvEXiC3nurbXPEPhu0j01bLw1fxyzx3s1wLmW1jS1kWR5InfS/TcD7Qor+d8f8HL37CP8Xw1/aiUdj/wgXw/59xn4qDI+mT7V6b8OP8Ag4j/AOCcvjvWLXSNd1r4w/ClLqRIhrXxF+GNw2gQM5AVr3UPAmr+OJLGAE/vLq8tYLWFcyTTRxqzLPNHv+Y7Ps/u/ruvvP3TorlvBPjfwd8SfCmg+O/h94o0Dxr4L8UafFqvhzxV4X1Wy1zQNb06fcI7zTNV06a4s7yAsrxs8Mz+XNHLBIEmikRdXXNc0Twxo2qeIvEmsaV4e8P6JYXWqa1ruuahaaTo2kaZZQvcXuo6pqd/Nb2Wn2FpAjz3V3dzw29vCjySyIilhW+wjUor8Hfjx/wcS/8ABP8A+EWuX/hrwNc/Ev8AaG1PTpWt7jVfhN4a02PwR9oiZkmitvGXjbXPCljrMcbLhNQ8N22u6VcAh7a/mjIY8Z8Jf+Dk39hXx3rNpo3xD8J/HD4Jx3dxHB/wknijwrovizwtZLI23z9SuPh94h8SeIbWBCVMk0fhi4iiQl5ZERS1TzR7r9Pv2HZ/18v80f0K0VxHw4+Jfw++MHgvQfiN8LPGnhr4g+BPE9mt/oHizwjrFlrmh6pbMSrNbX9hNNCZoJVe3u7V2S6srqOa0vIYLmGWJPnn9tn9tP4V/sG/BmD44/GDRvHOu+E7nxr4d8BxWHw90nR9Z1/+2fE0WpzafM1prmv+G7FdPjXSrkXU/wDaJmRnhWK2mLnbQj69oIB4IyPQ18ffsR/trfCz9vT4OXvxu+EGh+OvD/hSx8ca/wCAZrH4haXo2ka8dY8OWej3t9cJa6Fr/iSyOnyRa3arbSnURO8kdwsttCEQyfYBOASewJ/KgAAA4AAHoBilr8fdQ/4LU/sw6Z+2gv7DVz4C+OP/AAtR/jVpvwKTxHF4c8Fv4BPizVbuxs7bUDqbePU11dBWTUIGmuf+EcN8iB2TT5AoJ+8P2tv2pPh5+xl8BvGP7RHxU03xbq3gfwRceGrbVrDwPpmnav4lmk8VeJ9I8J6cbCw1bWNBsJUj1LWrSS7afVLbyrRJ5YxLIiQyAX/z/rufSVFfzvH/AIOYP2DV+98N/wBqJR6nwB4AHPpg/FQc+3Udx1x13hD/AIOQP+CdniTVLXTtbh+PngGC4kSN9Z8U/C61v9JswxAMt0PBHirxfqyxR53O0OkzFVBbaQKXMl1/y+/bqFn28vn2P3zory/4O/Gv4T/tA+A9I+J/wV8f+GfiV4C1zzF07xN4V1KLUbB7iDZ9qsLtV23WmarYtIiaho+qW9nqunyMsd7Z28jBT6hT32AKKKKACiiigAooooAbzxgcEA89BjoO/Oe/TAFOpvPGBwQDz0GOg78579MAU6l+P5aP56r8/wAAKKKKYBRRRQAUUUUAfnt/wVD/AGKdN/b2/Y3+J3wMSOyh8fxW8Pjr4N63elI4tC+K/hOO5u/DEk1y/FppviCObUPB2v3O1zD4e8SarKkbTRxFf8u/WtG1rw3rGseG/EelX+geJPDur6loHiHQdUge11TRNe0a/n0zWdG1K0lAltr/AEvUbW4sru3kAaKeF0bpk/7DJ/z/APr7fUc1/D5/wck/8E4Jvhp8RI/2+/hLoO34f/FDUdO0H9obTtMtv3HhT4nT+Vp/hv4kTQQqEttI+IcMUGg+IrsokUPja006+upp9Q8bOE/OePckeIoQzjDwvVwsPZYyMVrPDc16dbTd4eUpKbs37KpzSkoUbH9r/RC8UqeT5vivDTOsSqeA4hxDx3DdatO1PDZ8qcYYjL+aTtGObYelTeHi5KP17Cxo0oSr5hc/ljBPb+Wfbpg+v1596T6/5/Lv/XrQD+HHY9f/AK3+cUV+TN3btt+nb5fof6Nxje62tf8APt2+fbpofd3/AATr/at+GX7H/wC0DqPxC+NPwXtfj/8ACHxn8LvGXwo+Ifwxurfw9eprGheKrzw/qsdyuneKoLjw9qhs9T8N2Il0/UhbpNbTzyQ3ttcxRM3RfthT/wDBMv4iHUPiJ+xT/wANB/APxBK7Xmo/s+fGDwlZeK/AF280gMsPw5+JPh3xx4w8QeGHgUs0WieNINa0SdhssfEHhq2SGwP530V2xx9VYT6lOlhq1GM51KUqtFe3oTqKPM6WIpyp1opuCk6bnKjKWs6cj5ivwfganEi4qwuY55lmaTw+FwmOpZfmU4ZXmmHwcqjoQzHJ8XSxeW1qsIValKGNp4WjmNGlJLDYyhKMZqQZIycg9PQ5PYjv2JPXgY6V+tH/AATJ/wCCvPxr/wCCacvi3wz4b8C+FPi38HfiB4htPFfiz4feINT1Dwxrdn4kt9NtdEm17wd4xsLfVYNHvNQ0jT9NstVstZ8N6/YXyaVp7wR6bcxzXc/5Lp364+hP8vw9/wBadkDnkAeoPt/njj1FRgsdi8vxEMVg60qFeDfLOCT0lpKLjJShKMk2nGUZRfVNpW6+JuGMh4vyfGcP8S5XQzfJ8cqX1jB13WpqU6NSNWjUpV8PUpYjD1qVWMZ0q2HrUqsJL3ZpNp/oD/wUr/au/Z7/AG0/jzH+0D8E/wBnzxD+zz4o8ZaZNP8AGrR9Q8T6Fr+geNvHCTQi28b6Va6LpmnJp+u6hZedb+Lb94rZPE11Bp+tT6bba3Nreoav+dzokiskiq6MCGVhkEH/ADwetLNcW6yRxNNGJZXEcUW797K7EKqRRLl5HZiAqoGdm4UFjiu7134V/Fbwt4dsvF/in4U/FHwx4R1IbtO8V+Ivhz400TwxfrhWDWfiDUtDttJuUKsGDw3joVOQxANTiK1bG16+LqRi6lSXta8qVKFOHNKylUcKUY04c8vem1FKU5Sk7yk27yXK8s4UynKcgwNSpQwGCoxwWV0swzDEYzFOhTblSwtPFZhXrYvERw9NqjQhKpUdHDU6dKFqVKCjzuua5rnifVpNe8Ua1rPibXZ4ooZ9e8S6tqHiHWp4LeNIYIpdW1i5vNQeKCFEhgia4KRRIkcaKigDuvhD8EvjF+0H40tfh38DPhh44+LXje72snhzwJoF7rt5a27MFN9q09tH/Z+gaTEcm41jXLzT9LtVBkubuJAzDyyGeG4jWaGaOaJ1ISSJ0kjcZI4dCV4PHtjr1r9ff2Jf+C2H7Wv7Bvw7svhN8KPBv7PPiX4f2VzPeHTfF3wwfSvEWoXdxcTXMt5rXjL4fa54P1nxPqI+0NbQ6t4tHiHVYbKO3sEvRY2ltbx3gI4GtiV/aWKr0MO7ylVoUY4irJtx933qkOXmXMva8tZqVl7OV21ycU4ninL8kqy4LyTKM4zqm40sJl+bZnPJsvpU+WSVXnpYPEKuqM1TisE6mAjUpyk446hKEVU/W/8AYP8A+DYnxDqsujfEH/goB40Tw/patBex/s9fCfW47nWr1Vbf9h+IvxTsg1pp0TFFjvdF+HP2yeaCUta+PrKZWiH9dnwb+CXwk/Z6+H+ifCv4I/Dzwr8MPh74di8rSfC3hDSrfStNidlRZ7268pftGp6temNJdS1nU57zVtUuAbrUb26uXeVv42/Dn/B1/wDHSyVF8ZfsbfCjW3GBJL4Z+LPi/wALq5/i8uDVvB3iwIT0VWun292bv6la/wDB2i5jAvP2C7lpsYP2P9o208snpx9o+DyOMnJAIzg+oOf1PKc74Jymly4Ks6M5JRqV62Dxs8TU20nVWHlpdJunT5aalrGCbP8APzxJ8L/pVeI2OVfijJ45hg6NVzwWVZZxHwxhMiwLaspYXL553ScqihLl+t4z6zj5w92riZxSR/ZHRX8al7/wdmasUb+zv2BgsmDsbUP2kLby89MsLX4Ps+M9QOcdDxXivi3/AIOwP2jpxIPCP7JvwK8L7gwik8WfEnxv4u8vP3Wki0nSvBIkAONwWePOeCBmvUqcccNwV1jak32jg8Wn6XqUYL8T87w30VvHDETUZ8JYfCxbs6mI4j4bcVd2u1hs1xNS3pTb8j+5Wiv4ELP/AIL0f8Fpf2lbxtJ/Z6+GHht7q6Jjhi+An7MfjT4m3sG/hD9u8Sal8QtNQqDnzbqySNcbm74g+JnwN/4OCPjb8KPiD8av2rvjl8VfgB8DPBPhDxF458daj8Ufi9pvwd0iDw94f0u61W+t1+EvwTC+Ib3ULuKE6fpGjat4VsW1HVLqz00TpJcKRz/664avGUsuynN8coJylVjh40sNGMdXKddzn7OEVrKc4KMVq2le3sL6L2e5XXoU+NPEDw64RderSo08FiM7rY/O61WtOMKdHCZRTwuHljq9SUlGlQw2KqVas2oU4ybP2x/b1/ai+A/ij/grR+yd8JfjL8XfAfw5+Bf7B3hbxH+1Z8XNY8YeJdO0fSrz42+INPXw/wDBvwhBFc3Am1bxV4ahu7PxlY6Pptreao2naxqbpa/uHqt+0N/wcy/sleD9UPgb9lT4ZfFX9rf4j6hctpvh+Hw/ompeBfBuq6lL+7tYtPu9a0fUfiBrsjTFSltonw4ukukwsN8m8Ov5Kf8ABHf/AIIT/Db9uv4E6b+1x+1H4/8Aipp/hnxb428VWPg3wB4SutM0a88YaB4Wvk0S98U+I/G2q2eva0YdU8T2niHRTZ6JDpl2bfRPtcOvOt8gh/r/AP2Zf2DP2QP2O9OFj+zn8A/AHw4vXtxbXviqz0ttY8eatEUCyLrHj7xDNq3jHU4piC7213rctors3lW8a4UY5YuJ8yp18bRngcow+aVljViKkJY7HewnRo0sNGhRbp4aFOGGo07SrLmnUlOt7Ne0cV6/Hr8CeB8XlfC2Po8VeI2dcA5ZLhirlGEr0uE+E3m1HMMdmGeYnM8wprF53XxVfOcfi+anltR0aGGo4fLnjKn1SNeX8+lj8Fv+C6//AAVf2N+0P49tP+Cb37KmvA/b/h34HstS0X4qeKNAucLLp95ocert4/uTd22Yb2D4heL/AATorbzcjwDqER+xt+1/7DP/AASx/Y5/4J+aMi/BD4cQX/xDurL7H4h+NPjs2niX4p6+sqn7XENfeztbXw3pV0zMZtA8H6d4f0WfEcl5ZXd0rXT/AKLUV9FgskwmEqrFVZ1swzC1nj8fU9vXinbmjQi0qOFg2vgw9Ono+WTkkj8U4n8VOIuIMvnw/l1DK+DuEXPmXCnCOE/snK8Q46Qq5vWU6uZZ9ibKLlXzjG4te0XtKVKi3Y/HTw/4UPh//gvR8QPENpHst/H/APwS88K6jqjKMCfU/DX7Scvh+3lkI4aRNOS2hQnLCNAoOOn7F1+fPhvw7/bv/BUr4seOoI91v8O/2GPgt8O7q5Ayqap8Rvjj8Z/GMllu/wCesWm+BdLu5I87livbdyAsqE/Ov/BZP/gqZ4V/4Jw/AOW28L32j6z+078VdN1LTfg14Oumhu10GBVNrqnxW8V6eWJTwr4SaQnTra5VU8VeJktNCtw9lFr13papYnD5bg8yxuJmqeGhjsbWcrK7/fcjjFfanOtGUIRWsptLdmuLyPOOOuJeCeF8gws8fneL4W4WyynRi3ywtlscTCviKtmqOEwmWVaOIxNeS5MPhaU6ktIM/Mz/AILa/tJ+M/21/wBpP4Of8EY/2WNXe71rx1428Oal+054n0eT7ZY+HLGy8jxPZ+GtUa2bY+m/D7QLeb4peO7aWQodSsfBPh8FdSOpWB/py+CPwf8ABP7P3wg+GvwS+G+mJo/gX4WeDNA8EeGLAbTIml+H9OgsIri7lVU+06jfNE9/qd66+be6hc3N3MWlndj/AD9/8G9P/BPjxV8I/hz4p/b0/aNg1XVP2k/2rYLnWtDuvFoluPFPhz4V+ItQj8TPrWsy3g+0xeLfi7rLw+MdeaUC4h0ODwxZsYJn1O1H9KtYZFRr1/b51jYOni80VN0aMtXg8uppvC4ZX2nPmliKzSi5TqR54RnBpex4uZnk+Vyyjwu4UxUMZw7wE8TDMc1o2UOJuNMZyQ4hzyXLfnoUJUaeUZYpSqewweDnGlWq0asakyiiivoT8XCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK/Aj/gvp/wUC8W/sj/APwj8Hvg94guPDHxk/aLudfsP+Es0u5kttc8B/C7wzDYL4x17RbqF0m0zxFrt5rGkeGdB1RCJtPgutf1TTpLfVtJsrqD996/h4/4Oh7PWx+1z8BrqQT/2Pffsx6hZ6I+G8j+1rD4keKZtcjiOAhuEt9T8PvcBSXEUlqXwpTMyvbTe6/NafPYa79v81vbX7v8AI9B/4JFf8ENvAv7THwt8PftW/tgz+JLvwB47ludX+Ffwb0HWtQ8OS+LfDsd7LAvjv4j+JtPmg8TGy8TXMF3daFoWh6hpF1e6WbXxBqWtXNvqsOmp+/Ov/wDBFH/gl54g8Oy+G3/ZF8A6PC1s1vDrPhvVfGfh/wAVWrFNqXMXinS/E1vrst1EcOsl5fXSuyjz0lQsrfU/7DmqeGNa/Yw/ZO1LwY9q/he4/Zy+C66MLIobeK0t/h54etvswEeVWW0lhktbiP70dxDLHIBIrAfU1NJJdHe1/MLvufg5+xL/AMELPhj+xh+15rv7SWg/Gbx/4m8MeH7W5s/gt4ClnbRdS0W31/Sp9P8AEUPxS8S6PNZJ8RrO0W4eDw/pf9l6PpkwistU8S2ms6tp1lNF5Z/wc2tj9h/4PL/e/ap8Gk/8B+GXxa/kTn8qp/Bb/gtN8d/iZ/wU8l/YZ1f4OfCbTfh8vx8+MfwkXxpp+o+MD4yXSPhvb+Op9L1Vra5v5NFbU9Q/4RWyF/GLVLUC7ujbJGY4hUv/AAc4ts/Yj+DR7f8ADU3hHI/7pp8Vefwz+WaLWWn4b/0+/wCIt/6t/wAD5/ieXf8ABGD/AIJwfsQftI/sGeBfit8c/wBnTwN8SfiFq/jn4p6bqHinX5fEJ1C7sNC8b6rpOk20iWWt2losdjYWsNpCIraMmOJWkMkrPI30d+2r/wAEEv2I/G/wT8e61+zv8OV+APxk8KeFde8R+C9X8I+IfEtx4U13V9G0+fUrbw34y8KeINZ1fR5dF1trU6bNqmkQaTrekvdR6jDfXMNpLpl7+VH/AATH/wCC4H7Ov7DX7I3hD9nz4kfCn42eKfE/h/xX8QddvNb8FWXgWfw9NbeLPFeoa/YRWsmueNdE1Iz29repDerNp8KpcxuYXniZXHoH7aP/AAckaH8VPgr43+FX7Lvwd8deBvEvxB8P6p4T1L4n/FDU/DNpJ4P0LXbObTdZvPDHh3wxqfiH7f4jl0+5ng0nUtR1jTLXRLqRNS+x6lLbxw1DcXFX3t2s72W2mn5FJSuvJ9Xbs9nr26Fr/g2Q/aP8Xnx18b/2V9U1K7vfAWoeArX47+CdLuriWaDwr4isfEGi+FvG1tpUbMUtbXxTB4m8Pane20YEB1LRLi/RVutSvpLjyf8A4L+/t0/EX43/ALRw/YD+Ed7q0nw7+HmqeE9G8c+HvDs0wuvi98a/FCaVqOjeF9QSBkOo6H4PGsaFpmn6DJm1ufG1zql7qEdzLo+hyWP2r/wbjfsMfED4U6F8Rf2wPil4c1Pwg3xS8JaT8OPgx4f1u1nsNZvPh1b6nbeIfEPjq7066ijubHS/Fmrab4dtfCpnWK4v9L0O81mOI6TrGk3V3+OgksPDP/Bwhcv8S3ih02H/AIKN313cz6piO2jOt+PJ7vwBeTtPtRLRbrU/Cl1bO+Ikg8hwfLUGobcYRTW709Lr87tq76F2XM2lta/re+nnZffv1P37/Yq/4N6P2Uvhf8PdA1r9rTw6/wC0B8aNV020vfEulX3iHXdL+Fvgq/uIUmm8OeGNB8N6jo58Rrpbu1ld+IvFNzqo1eaFrzTtL0S1lWzHsP7Rv/BAH/gn58YfBuqWHwt+Hcv7OHxCW0nbw742+G+q69caVb6kIybRfEfgPXdZv/DevaOZgv263s4dD1qWAulj4g0+UiUft8OQM4zgZx0/DPOKWtklZaJr7/mZ8z7/AC6fdsfwS/8ABN39pP42f8Eof+Cg+q/sk/GzUZrX4WeK/inYfCT4v+F/tl1P4V0bxP4gmsbHwF8bfB/2tENpZ366p4d1DUL5ba3m13wDq5bVIJNR0fSHsv3b/wCDkxsf8E7NJAOC/wC0l8IFB6HItPGL8d84Q+nf6V/Pr/wX7v8AStW/4KjeNrTwcY5vENh4I+BGi6udPcNcSeOn0mO806ImLLf2lHoeo+E4FA/fKqW0RAKKo/fr/g43t9QP/BNnwsbwNJd2f7QfwWk1SQAsFn/sfxhazSMw4Aa+njUMeC7qBywqI6KS7X/X/L8R7tba2203tf8A4Jd/4Nsjn/gnr4gPr+0t8Vj+eh+Aq/oAf7jf7rfyNfz8/wDBtdNFJ/wT28SRoytJB+0v8UkmUHJRpPD3w+nQMOqlopUcA4yrA96/oHb7rfQ/yq47L0X5Ce7/AK/M/gU8ZKF/4OGrfjn/AIeK+BWHH9/VvCrH+f41/TD/AMF7hn/glp+0R7ar8Gj+Xxs+Hx/nX80fjMC5/wCDh22FufMz/wAFE/A33Tnm01Hwv9oHH/PJoJQ+fu7WDYwcf0wf8F613f8ABLP9o0/3NQ+Djn6D42/D0f1o3v6209F/n+BCvZei/wCCfjH/AMEDv2Ev2SP2tfgd8fPFf7RnwP8ACvxW1/wp8ZtP8NeHtU8QXXiGGfS9Fk8A+HNVl02BNI1nTLdrc6he3N3mWGWbzLhwZTGI0T9ffjd/wQM/4JyfFHwTq+heBfhFL8CfGU1nc/8ACO+P/hv4m8WG40bVTC4srjUfDGv6/q3hjxDpiXBjN/p15p0N1c2olgstV0u4kjvYf52v+CRn/BXT4I/8E5/hV8Wvh78Vfhp8V/GuofEP4n23jnTtS+H0Xg+fT7LT4fCOh+HWsr6PxJ4o8P3IvvtWlTXA+zRXED280IMySI6V+iPxw/4Oh/hb/wAILrVp+zn+zz8Rp/iLe2FxbaJrnxgv/COieD/Dl7NGyQ6xfaZ4U8QeKdV8SCwdhOuipc6BFesqxy6xaxlt03itHa600XXbS3V6W26LQ0XNfTy8u2mvqtD4S/4IS/GH4j/sx/8ABRzxB+yRrGtS3PhP4mav8T/hf438P289xPoMXxN+ENp4k1DSfGmlWsj7ILuRPCGueHJLxVE13pGs2q3nnf2bZGD+6ev4rP8Ag34/Yw+MfxQ/aduf29viromu2HgHwpbeO9U8IeLfEVlLYzfFn4s/EaLUdJ17XtCinSFtR0DRdM1vxPdajrttH/Zs2vahYWOnTXL2mpJZ/wBqdEE1HV31/Cy1Xq7/ADv0aCTTtbfr3+a6Pe/yCiiirJCiiigAooooAbzxgcEA89BjoO/Oe/TAFOpvPGBwQDz0GOg78579MAU6l+P5aP56r8/wAooopgFFFFABRRRQAVwHxU+F3gL42fDnxp8Jfih4a07xh8PviF4d1Pwr4u8NarG0llq2i6tbPbXUDmNkmt50DLPZX1rLBfadexW9/YXNte20E8ff0VMoxnGUJxjOEouMoySlGUZK0oyi7pxabTTTTTs9DWhXrYatRxOHq1KGIw9WnXoV6M5U61GtSmqlKrSqQcZ06lOcYzhODUoSipRaaTP8vX/gpz/wTu+IH/BOP9orUvhpq/8AaniD4QeL21HxD8BviXdxbo/Fvg6GdBPoGtXcMUdmnj/wQ1za6V4rso47f7ZHLpnia0tbfTNes44/zoBBA9/8/wBD+Vf6sH7cn7FHwe/b2+APib4EfGCweO2v8av4L8aabBA/if4b+OLGGZdE8ZeGZptoF3ZNNJbalp0ksdnr+iXWo6HqBFrfNJH/AJoP7ZH7HHxu/YV+OGv/AAL+OehfYtZ0/wA3UfCXi3T4bg+EPib4Pa4eDT/Gvgu+mUG6027K+TqOnSkap4c1ZLnRdYggvbYh/wAO4q4aqZLiZYjDxcssxE26Mld/VZyd/q1VttpJt+wm/jguRtzpycv9Xvo9eOGE8UckhkmdYmlQ48ybCxjjqEnCks/wVFRgs5wUFyxdW3LHNMLTX7iu/rFOnDC16cKPy6c4ODg4OCRkA9iRkZ57ZGfUda/q4/4J6f8ABC79hn/goH+yX8N/2iPDXx9/aN8IeKtUgvPC3xT8IaZrXwz1jT/B3xS8Lulj4p0i3TUfhsNQh029drPxP4fgvL68uT4X8QaJJPeTTSSSH+UYNnPTt3H4/r379q/bX/gh/wD8FLbf9gT9om88I/FLWJbT9mT4+XWj6N8SLqbzJbT4b+MbMtZeFPiusS7mi0u1juX8P+Pfs0fmSeGp7PW5Eu5fCVjZzcHDlXLKeZU6eb0KVbB4hOjKdW/Lh6knF0azlFxcYKS9nVbkoRhUdSd/Zq32vjVgOPMXwNjcd4c5xmOV8UZHUWaUcNl6pzqZ1gaMJRx2V/V6tKtCtiXRf1vAxjSlWqYrCwwdGzxk2fvTov8Awas/se20gbX/ANo79qDWogeYbG8+FOhhlz0aQfDbUZORwSpUjOQciv5oP+Cw3/BORP8AgnF+09YeAPCF/wCKfEPwP+JXhGz8Z/CHxP4uuLW/1xhp5g0jxz4U1zVNO0/SdNv9a8N6+bfUDJaaZZgeHfE/ht5oftDTO3+mxp+oWGrWFlqulXtpqWmalaW1/p2o2FzDeWN/Y3kKXFpe2V3bvJb3VpdW8kc9tcwSSQzwyJLE7Iysfyq/4LIf8E/4P+CgP7Hvibwf4ZsLaT45/C2S6+JfwJv5PKiluvFemWMsereBZbuXaItM+I2hi48OyCaaGytddPhzXL0tHoaKf0vPOEctq5XX/svA0aGMpJV6LpKTlW9mm5UG3JuSqU3JQjezqqm3pc/hXwm+klxxgOP8ofH3FOOzXhnHzllOaU8csNToZd9blCGHzVQoUKMaTwOKhRlip8rksvnjYRi5yjb8jP8Ag2I8X/syfEn4PePfhxqfwZ+Dln+1H8CfEkmuJ8RW8AeEh8S/F/ws8aXVxc6Brr+LZtLfxJeXPhbXhq/hHVJYdQEVnpaeDUuB5t/E0n9Z80MNxFJBPFHNDMjRywyoskUsbgh0kjcFXRgSGVgQQSCDX+Uf+xH+1l8Sv2Av2qPAP7QHhPT9SXVPAmsXvhz4lfD+8Eml3Hi3wLe3CaX8Qfh5rFrdopstVCWzT6X9ugJ0Txjo2j6hLDv05kP+pB8EPjR8Ov2ifhJ8P/jf8JvEFv4o+HfxL8NWHijwvrNvtVprG+QiS0vrcMz2Gr6VeR3Ok63pcxF1pWsWV9pt2qXNrKivgjNaWMy1YGShTxeASjOEUourh2+WlXsrc0oJKhVl70lKEJTadWKMvpW+H2ZcNccy4tpVMXjOHOL5yxWExFWrVxFPLc3UVUzHK1UnOpGjSrzcsywFOLp0nRr4jDYaDjl9Vr8d/wDgp7/wQy/Z/wD22/Dmo+Pvgto3hD9n/wDag020uJtJ8YaBokGi+BPiTKu6ZND+Lvh/QLRI717mTdDZ+P8ATLGTxfohlRrv/hJdItY/D7fwI/Hv9n/40fsvfFHxB8Gfj38P9c+G3xH8OOTeaFrUSPb6jp5kkhtPEPhjWLZpdK8U+FtUMTPpniLQ7u80662yQmWO7gubaL/XKr5D/bF/YY/Zq/bs+HEnw3/aJ+H9n4mt7VbmXwp4x0100f4h/D/U7lArav4H8XW8L6ho10WSB7ywkF5oGtpbw2viHRtXsU+ysuI+DcNmvNi8D7LB5gryl7vLh8U/+nygm6dV/wDP6EZc21WE/dlCfBX6TOeeH3sOHuLFjOJeD3JRot1VWzrIIt6yy6riJxWLwK3lleJrQjT+LBV8NapQxH+Zj+yT8SP2Zfh18Uraf9rj9niT9oX4L60tvp/iPTdC8aeMvA/xC8GoJiT4m8CX/hjxX4a0zWruBZCNR8LeKS1lrNrGkOn6v4b1BBqEn9rn7Mn/AASM/wCCEn7W3w10n4w/s+/DiP4l+CtVWNZjY/HT44JqfhzUjGJLjw74t8PT/EC11vwt4gswcXWi67a2l8qbLiJZrOa3uZf5wv8Agot/wQk/ao/YhfXPiF8PLXUv2kf2crNrm9bx54P0WV/H/gPSYw0u74o+AdO+1XUdnYwrJ9q8beEk1Pw0YYH1HXLXwcs8VgPyv/Zt/am+Pf7JfxDsvix+zf8AFPxD8NPFsYt47250S5hvPD/irToJhOmjeMvDN6l14d8YaG7gn7Brmn3iQNm4sZLO8VLmP4PAYuXD2Llgc/yPDYmjdt+2weGniYK6XtMNiJwccVS39x1J0+b+HWpe/GX9hcWZF/xGnh+nxV4PeLmfZFmKowpKGVcS55hchxc4xXLgs7ybDYmnichzGEbXxFHBU67p+/isBjnUpVqX+iv4d/4IZf8ABKLw08ctp+xt4C1OWPBD+KPEfxH8YK5GMebb+KPGmrWkvTkPbsGHDAivqvwD+wF+w58Lmhl+H37IP7NnhS6typg1DSvgv8Po9VjZPuuurSaBLqW8YB8w3RfIyWzX4TfsF/8ABzD8D/inBo3gD9t/w/b/ALP/AMQnFvZL8WPDcGp6z8EfEdyR5YutXgH9oeJ/hlcTybPNTVB4g8MW5aS4uPFenQBbeP8Aps8HeNPB/wAQ/DeleMfAPirw5428Ja7bJeaL4n8J61pviLw/q9o/3LnTdY0i5u9PvYG7S21xImcgkEED9Vympw9jqar5XRy66ScoUsNQo16N+lSkoRqU2npdrlk9YSkrN/56eI2C8Z+E8dLLfEHMuNFzznDD4rMc9zbMsqzCK1c8DmEsXXwWLjy2lKFOo61FNQr0qU1KC2rHT7DTLWGx02xtNPsrdBHb2llbQ2trAijCpDBAkcUSKAAFRFAAAAr+UT/g4Y/ab8afHj4l/AH/AII//s33zX/xJ+PHjfwJq/xoNhI8kWlaZqOqw3Xw38H64IC3l6ck1tP8XvGSXAQ6b4c8I+Fr9y9jq84H72/8FBv23fhz/wAE/wD9mPxx+0B49e31HUtPhGgfDTwQboW1/wDEX4mavBcDwv4SsSP3sVtLNBNqniHUY1f+xfC+ma1rBSU2SwTfz6f8G8f7KHxE+OfxX+NX/BXb9p8XOv8AxE+LHiLxfofwc1LVrZo0vrnV7x7L4nfEnQ7ebP2LRbdLaP4T+AYrUi207w7pXivTLZBYtp8h5M+rSx1bD8OYWbVXH2qZhOnvhcrpyj7e/SM8Sv3NNNOLUnGXKqkJP6Hwiymhwvled+NnENCnPLuEZPB8G4TFK8c/8QcXSayqMIS1rYXIrvNsZOLUoToUqlJ1HhcTCP8AUH+z38E/B37N3wO+FHwF+H9sbXwd8JPAfhrwHoIdUW4urXw9pdvYSapflAFk1TWbqKfVtVnxm51K9urhvmlavYqKK+nhCFOEKdOKhCnCMIRWijCEVGMUuijFJJdEj8GxOJxGMxOIxmLrTxGKxdeticTXqy5qlfEYipKrWrVJWXNOpUnKc5NXlKTb1YUjMFBZiFVQSSSAAB3JJAA9yQKWvwy/4LB/8Ffvgj+wt4B1n4PaHNbfFH9pTxtpH2SD4X6HrX2OHwf4b1NUW71r4ma5p7SX3hOy1nTJJ7bR9M0/y/GGrQ3Jv9G/sq3ji8QW3Njsdhsuw1XF4urClRpr4ptrmk78tOKSlKU5tWjGMZSerSaTPe4S4Sz7jfPsDw5w3l2IzLM8dUUY0sPBNUKEZRVfF4mpOVOjh8LhoS562IxFWjRgrKVWLlG+7+0b/wAFD/gn/wAE/fgl8Xf2tPiRJb+IPiZ+07451TWfgD8J7G5S28UfETwn4L0DSfh/8Lp18xZJ9H8BXPh/QLf4na/4luLc2mjW/wAQpLW3jvvEGo2OlXn88f8AwSy/Ys+NX/BZD9sbxR/wUI/bgN54o+CPhLxjFfy2mp201t4b+KPjXw9Mk3hr4ReDtLuWlitvhB8N0Nq3iW1gaa2v2S38N3M19qWs+KL+1+Uf2JP2O/2p/wDguZ+1rrPxb+OnifW7b4O+GdS02H4u/Euys10jw/4Y8N2W250P4D/A/RAr6PoNz/ZrraaXpGlwy6f4J0SaTxLrhvtYvbKDxB/oc/Cn4V/D74H/AA48GfCP4U+FtL8FfDv4f6DY+GvCXhjRoPIsNK0mwj2RRrktNc3VxIZLvUNQu5J77U9QuLrUb+4ub26nnk+Ky2hiOJ8RQxuLpulkWCqyqYTCzVnmOM5nKpi68U3GUPaupOUE5UYuTw0HUisTKf8AU3G+Z5L9H/Jc04S4axuHzPxc4pwFDB8UcRYSbqUuCuHvYUaeE4cyWvJRq08V9SpYeisTJUsbVhSp5riqeGqf2Th8L3sUUcEUcMMaRRRIscccahI40RQqIiKAqIqgKqqAFUAAAACpKKK/QD+NQooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAr8WP+C3P/BO3Xf26v2c9G8QfCnT4r/9oP4B3+seKvh3pTSwWjeOvDutWtpD45+HK3lw8MEGo65b6VpGreG5ruZLX/hIdBsdNmmsrTWL2+g/aeik1fQNj+E3/glv/wAFn/FX/BPvSL39lX9qP4fePPEvwf8ACWv6rb6NBY2H2H4u/AfVbzULi88QeEdT8HeJp9HfV/C/9rz3eox6NNe6Vrfh29vL4WA1awurTTbH95tf/wCDiP8A4JpaR4cbW9M8a/FbxTqfkeZH4S0T4OeMLbX3mK5Fq1x4lt/D/hiGUN8jSTeI47ZcFhOygFv0F/aV/wCCfn7HH7XkiXv7QPwE8E+OfEMMAtrbxrHBfeGfH1rbqmyK3i8ceE7zRPFL2luADBY3Oqz2ER5W15Ofg7Rf+Der/gmJpGrrqlz8LfiF4ggSUSLomu/Gb4jS6PgMCIXTTtc0zUJoeACk2oyFgMOWycylJO17rTt3/r0WzbQ/6/Lyt30/p/zY/wDBOXx0v7Qn/BcXwV8YfBHhrxDB4e8d/Hz48fGOTSZ7ZdS1Pwf4T8XeE/iTqtnJ4rn0g3mn6eLSfWbLS7q9+0tp39pXMFpDdySTwiT9xv8Ag50Kj9iL4NZP/N0vhLH/AIbP4q/p0z26Zr9zPgR+zJ+z5+zD4bk8Jfs//B/wF8JtDuTE2oQ+DtAs9OvtZlg3iG48Qa1sk1vxDdxB3Ed5rmo6hdKHYCbDHOF+07+yN+z1+2T4J0X4d/tH/D2D4j+EPD3ie28ZaLpU2v8Ainw4bDxJaaZqmjwanHfeEtc0HUJGTTdZ1O1NtPdS2brdGSS3eWKF46aurX/qyvv6ettLu1xL/K//AA36P0ufhP8A8ET/ANgb9jL4+f8ABPr4b/Er4z/s1/Cb4l+PNY8afFez1Hxb4t8LWuq65fWej/EDXNK0u2uL6Y+bJDp9haQ2drGTsighRUAO4t8Uf8Fzf+CWfhz9lyDwV+23+xr4Nt/hp4H8Kal4e0r4q+EfAdo1lp3w48RWep2x8BfF/wAOWC+dBpVhdasbPw/4sjjRLK21r/hGdX+yyHVNeuF/rV/Z8/Z3+D/7LPwv0f4M/Arwkvgf4b6Bfa3qWk+HV1nXteFpeeI9Wu9c1iUan4l1TWNXm+16nfXNzsnv5Y4fM8qBYoUSNfRfGngzwr8RfCPibwF450HTfFPg3xloWqeGfFHhzWLdbvS9c0HWrObT9U0y/t2wJba8s55YZACrgPujdJFV1Tjdeffz/ry/yKUmnrqu3+S2Vuh+bP8AwSW/4KHaJ/wUE/Zr0/xDrVzp9j8evhmNO8I/HPwvarHaga8baQaT470mxQ/uvDHj+0tLjVLFIlEGl6zb694cQuNFWef8Rf8Ag4R/4JqfEa4+Izft/fAPw3rPiLS7/RtGtf2gtF8JW11c+J/COteDrSCx8OfGHTbLTY31C40b+wLDTNJ8WXWnRtdeGrjw/pfiWZJrG+1i+0n+hT9mn/gmd+xf+x94+u/iZ+zl8Jr34a+MNS8P3fhXVL2w+I/xP1ix1bw9eXFrePpeq6H4j8Zaxomow297ZWt5YPd6fNPp11CJrKaB3kL/AHiQCCCAQQQQehB4IPsRSUbxSlZtbNa7bPXr31fe4r63Wm36P80fyofsG/8ABx58LJvhv4b8Cftv6b4s0fx74f02z0r/AIXb4H0CXxj4U8f21nCIIda8U6BoryeI/DfiqeKOJtZOkaVreh6petPqdtJoyXC6Vb+9/tNf8HIn7JHgPwXqsf7NOieMvjl8Srqzmi8Pya74X1n4e/DfR76SJ1h1DxPqXiaPSvFGoWtlKY530fw9oMk+qIj2n9s6N5gv4vvn48f8EcP+Cc/7Q+vaj4t8afs5eHvDvjDV5nudT8UfC3V/EXws1HUbuVi817qVl4I1TR9A1S+uJCZbi/1PRru8uJS0k88jMxPCfCf/AIIWf8EzPhNrFrr9t+z+PiFqtjcR3Vm/xb8ZeLviHpMMsTB0MnhXWtXbwjfKCB8mpaBeqcAkE80JTVldWWl99NPv+fnfoGlvP19Olvu19eiP5wv+CSf7EPxu/wCCh/7Ysf7cf7Qtlq9/8H/C/wATpvjF4o8da/YtYWXxo+Ldhqq6v4f8J+DrWWMQ3/hPw7rcFjea/Pp0cmg6To2iWXg2CZbm98my/q//AOCm37Kmpftm/sTfG34FeG1tf+E71TRtO8V/DVr2WO3t2+IXgPWLHxb4Y0+a7mZIbKDxBd6U3hm6vpmEVlZ61cXMh2RGvuXSdI0nQNL0/RNC0zT9F0XSbO30/StI0myttO0zTbC1jWG1stPsLOOG1s7S2hRIoLa3ijhhjVUjRVAA0Kaikmu+/wB1v+CJO1n21P4GP+CSn/BUif8A4Jj+Lvit8A/2j/h344/4Vf4l8Zf2h4q0fTdKEPxI+DHxU0ezh8O67Jf+ENXudMk1LTNWsNO0ux8QaYtzb6tp9xo1hqWkxalHc3NrcfvR8Yv+Djb9gvwd4F1LVvhK/wASfjL4+l0+ZvDvg238BeIPA+mNqrx/6KnijxP4ztNJtdI0tJCDfXGk2viDUFjVhaabdMQR+kX7T3/BOP8AYt/bEvV1v4/fAfwr4r8XR2qWcPj7SptW8G+P47aJVS3t5vGPg7UdD1zUrW0RQtnY6vd6hY2q7hDbJubPxr4M/wCDfz/gmN4Q1qLWbn4QeMPGoglE0OjeOPix4+1fQFZWDIk+l2es6XFqMCkANbao19byqCk8UqMyskpR0umuj6pfhf79u/Vt316/5Ja9Nz8Cf+CKv7Pfxa/ba/4KF6v+3J8SdKuJvA3w28f+Ofi/4v8AGTWc9poHib45eMF1NtB8G+F5JQy3beGbnxBN4nv47d5l0HTtD0Sw1CWC41nT0l/oZ/4L0jP/AASw/aT9rr4PH/zN3w7r9WPAvgLwR8MPCmi+BPhx4R8N+BPBfhy0Ww0Hwp4S0XT/AA/4f0ezVmfyNP0nS7e1srVGkd5ZPKhVpZpJJpS8sju3G/Hf4D/Cj9pj4WeJvgt8bfCcPjf4aeMP7JPiHw1NqetaMt+2h61p3iHSZF1Pw9qOk6xaSWWs6Vp97G9lqFuzvbiKUyQSSxPSVlZff1v39RH8qX/Bv1+xh+yt+0/8Bv2g/EP7QXwG+HHxb1rw18btP0HQNW8aaDFqmoaTpD/D7w3qM2lWdy7pJDYtfXk141up2G4nkdgSV2/0ReEv+CY//BPTwNqdtrPhn9jT9nix1OzlWe0vLn4ZeG9YktpkO5JoRrVnqCRyo2GSREDowBUggEenfsvfsdfs6/sZ+F/Evgz9nH4fD4e+HPF/iNfFniHTx4k8V+JjqGvJpVjoq3pu/Fuua7e2+3TdNs7cW9tcQ237rzPJ813dvpuklok0nb5/mNvtotPyW/z/AMyva2ttY21vZWVvBaWdpBFbWtrbRRwW1tbQRrFDBbwRKkUMMUaqkUUaqkaKFRQoAFiiiqEFFFFABRRRQAUUUUAN57DjA68Yx0GOec9T2A9adSemBxjvxjHQY7HPtS0vx/LR/PVfn+AFFFFMAooooAKKKKACiiigAr4p/bs/YL+Av/BQT4MXvwi+Nmiyx3VlJPqvw9+IuhJbQeOvhj4qeERpr3hXUp4pE8m6WOG21/QL5Z9E8S6dGtpqlq8sFjd2X2tRWNehRxVGph8RShWo1YuFSnUXNGcX0a7p2aas4ySlFppNejlObZnkOZYLOMmx2Jy3NMuxEMVgsdhKsqWIw9em/dnTnHo03CcJJwqU5Tp1IzpzlF/5an/BQD/gm/8AtF/8E6PiX/wiHxe0g6/8PvEF5cRfDH44eHbC6j8BfEK1jDTLYl5XuH8K+N7S2Rn1jwTrFwb+AxTXujXWv6F9n1q4+ByQRzyCCCpxgjgH19cEE8g/n/rq/GL4MfCv9oD4d+I/hN8Z/Afhz4j/AA78W2TWGveFfE9gl/p13HgtBcwnKXOnanYThLvStY0y4stW0i/ig1DTL60vbeGdP4hP+ClH/Bux8Zf2fp9d+LH7FcHiL48/BZDPqOofCmR/7T+N3w7tAzvJHosSeW3xZ8OWi/8AHv8A2XDH8QLSBoYbjRPE7Q32un8g4h4KxWAdTFZXGpi8D705UF7+Kwq3tZXliKUek4RdSMV+9hJJ1n/pR4L/AEpci4wp4Th/xAr4Ph3ipKnQoZtNxw2RZ9UVoxlOpK1LKcwq6KpRrSjgK9Rv6pVpTq0sBT8s/wCCUf8AwXc+JH7D+n6J8Bv2gNM174yfsvWk0Np4cn06eO6+J3wUsnlPmW/hNtRuIbbxd4FgDtIngfUr2yvdFUf8Urq8FnEvh26/ui/Z1/af+Af7WXw8sPil+zz8UPC/xP8ABt6IknvNAvf+JloV9IjO2jeKdAu0ttd8K67CFYzaN4g07TtRRV837OYXjkf/ACV5IpIJ7i1uYpre6s7ie0u7S5ieC6sru2cw3Npd20yrPbXdtKjQ3FtcJHNBKjxyIsilR678Dfj98a/2aPHll8TfgB8UfF/wn8c2XlxtrnhDVHs11O0jcS/2X4j0ieO40PxVosjqTNoviTTdU0uX7z2pcKy4ZBxpjMrjTwmMjLG4KCUYJySxOHgrLlozk+WpTivhpVX7q5YQrU4R5T1fGD6L3DHH+IxnEPDVelwpxVipSxGJkqcqmQ5ziZ2lKtjsNSTqYLFV5PnrZhgFJVJOpXxOAxeJqzrH9If/AAcZ/wDBL+6+GPjfUf2//gh4bdvht8Q9Ut4v2kNB0i1LReB/iLqU8Vlp3xVW1t0xB4b+IVxJb6b4wuSiRad47a01m5mnk8aXRsflD/ghn/wVuH7CvxDk+APx41u6P7J3xV8QLdrrd1JLcx/Aj4gao0du/jOGMeYyfD/xM628Pj+yt0/4lF1Fb+M7OMGHxFDq/wB4/sv/APByv4e8b+Eb34Kf8FJvgPYeMvB/ivRL3wh4r+J3wq0ODVdF8QaDq9lLpuqQ/ET4MatcMZLW+s55U1i68FaxexypJKNP8FQKUiX8Pv29P2PPgp8MNcvvjd+w/wDGXwl+0Z+xx4tvRdaVfeG9fTVviD8BL3VZz9n+H3xj8J332bxt4e05ZXNn4Q8X+KtA0tNXt1g0bWpIfE8SNrG2Y18PRzCHEnDOJg7ydXHYCUXCvQlK3tpVMK2qlTBVk39YlS56dCq3UhVhGVOVLzuCsnzrNOEK3gZ465Fi6SVGGB4T4spTWLyzM6GGV8to4TPKUK2HwfEeUqMP7MoY32GKzHARjhK2Bq1KeKo5h/p56bqWn6zp9jq2k31nqmlapZ22oabqWn3MF7YahYXsKXNne2N5bSS293aXdtJFcW11bySQXEEkc0MjxOrG9X+fT/wSQ/4LoeOP2HrTRv2f/wBom28QfFL9liOeO18M6np7PqfxD+BMFxKDJF4dt7iUP4t+HMbyNPJ4Le4h1Xw8DLN4QuHtx/wjN5/d18Efj18HP2kfh7o3xV+BXxH8K/FDwBrqA2HiTwlqcWoWqThEefTtStz5eoaLrNlvVNR0PWrPT9Z02Y+RqGn20wMY/Sskz/A53QjOhNU8TGCeIwc5L21J6KTitPa0btclaC5WpRU1TqN04/w54q+DfF3hRm1TDZxhKmMyOtXlDKOJcLRm8tzGk7ypwqyi6iwGYqCft8vxFT2kZQqTw08XhPZ4qr63gHt9ffP+f0Ffh/8At0f8EDf2Jf2yr/WPHnhrSLz9mj42as813efET4Q6fp0Hh7xHqcpDNfePPhfcC28KeI7iaQyTX2raMfCfizUp5TJfeJ7gAKP3Bor0cZgcHmFF0MbhqWJpN3UasU+WW3NTlpOnO2nPTlGS6M+H4Z4t4l4NzKGb8LZ3mGSZhFKMq+BrunGvTUlJUcVQlzYfGYdySlLDYqlWoSaTlTbSP85z9qH/AIN6/wDgoh+znJqOreCfBuhftQ+A7QyyQ+IPgrdsvjFLNWbym1T4V+IprPxKL1kUNJZeDrrxzHGTtF23ysfzq+D/AO0j+2Z+wd43vofhP8RfjP8As3+K7W9WXxD4E1Sz1jw/pOoXNu/I8WfC3xtpsvhvVpAwKNLrPhqabbnyZ0YjH+kB+3H/AMFKP2Uv+Cf/AIPl1345ePbaXxne2Et34P8Ag54TktNb+KvjaUArB/ZXhpbmE6ZpDzApceKvElxo3hizCSJJqrXYhtJ/4hvi78bv25/+Dg39rvwt8M/BHhSz8NeCfDt3c3nhPwLZNcT/AA7+A/ge9uIrTVfiR8VfGSWMV1ruvT28cMM960FrJrWoLD4a8CeHLWW6eGX8oz7JMqyrGUKeS47GxzapWjGjgMK/b1YSm1vXp1KVbDe7rFTlXrTbTUFT5qsP9F/BvxS4+8ReHsxxfinwhwvPw4wOBr18242zun/ZWAxVHDQvaOUYzDY7Ls9l7ZKNWpg6WWZfhUpKVWWNWHwWK+Q/2n/+ChPxv/b9+J/wa8Sfts+JtV8XfDn4Yvp2l3ngz4Q2GleCG/4R27v7Sfx3rHhvTdQurrQ7T4jeNLG0hsLrxLeg2NnFaadbWOn2Wn2Mdk39gP7On/Bwp/wSh0P4f+CfhtpkPxU/Zx8LeCPDWi+E/Dfg/wARfB/WtR0Tw5ouh6fBp+n6XYXvwyu/iHBJZ2dtbpElzcypc3AQ3FzmeSRj2XhL/g21/wCCammfDTwf4Q8ZeD/iJ4x8c6JoNpZeKPirafFHx34T1rxlrwUyalr03hzSNffwno0VxdPIun6TYaS0On6dHaWk9xqNzFPqF18xfHn/AIIIf8EYP2dvD8/jX45fH/4s/BDwyiSzRXPjH9oXwVo0d6I+XttFtfEnge91jXLz+GOx0lNR1CVsLHBI/Fexg8r4uyipiMcq+U16mJhSliq2PrVKlRKnFKMKleUaUoqF+VqFd0m1Fq6jE/NuKePvo2+JeGyPhL+zPEbLMDkFbHYbh3LOD8nweDwk54zEc9XE4LKKNfMaderi5R9rCeIy2njVGpOM6dKpUrRl+mll/wAFzP8AglJfW4uY/wBsbwPbJt3GPU/CvxP0m5XjJU2up+BrS43joVEZOQcZrxL4p/8ABxb/AMEvvh3ZTzeG/ih47+M2oxoxh0n4XfCvxi73MgUlETV/Hlj4F8OhHbCmX+2CqjLKHGAf5Pv2hfHf/BD74MSajoH7J/7Pnx8/bC8U27T29t8Qfjv8XPHPw1+DVvcKVWG/t9D8Hw+AfiJ40tVIYtYNpXgO3uAEaLXJYnZW/KhLfxV8bPiNYaD8PPhhp8vi7xffxaX4T+FfwU8F6nK1zcSMRb6X4e0C1m8QeKdZnQYEuoazquuas8atPqGpyBXlXjxnGub0LUYzyStiJSUL4CnjMRGEm4pJVKtSFCbk5e57CWJT2lys+k4X+ir4ZZqpZrjqHitlGT0qbxC/1txfCuRzr04rmk6uDwmDr5thaVOKlKtLMaOT1IwXPT9pG/L/AEVftnf8HMv7SPxi0vV/BH7KHgCz/Zp8LajDPZz/ABC1zUbTxp8ZZ7SVHiaXRTFbReDvAdxNE/NxBbeLdXsZQs2la5YXSJOPkL/gmR/wR5/aB/4KZeOm+NXxZ1Xxf4J/ZxvfEFzq/jj42eJZrzUPHfxh1U3jPrOmfDa5183V14h1O/ulmttc+I+rG90LRpvtK2za9rNs2kRfrN/wTJ/4NvXSXw98bf8Agohb28pja11fw9+y5o+px3doHBWe1l+NHibSp3t9QK4WSXwB4WvZdNbKQ+IvEOoRm/8ADw/sB0TRNF8NaPpfh3w5pGmaBoGh6fZ6TouiaNY2umaRpGl6fBHa2Gm6Zp1lFBZ2NhZW0UVvaWlrDFBbwRpFFGiIqjty3hzNM7r08x4pr1Z0oWlh8uk/ZuV7O9SlT5IYWm0o81KEY4io0vayp8lqnyXHPjb4feE+WY/gj6PuVZbh8xxK+r5xxrQjPGxg4JxccDmGNniMTneLhJzdHGV61XKsC5SeAp4l1ebD+Z/Ab4CfCX9mX4VeEvgr8EfBeleA/hz4LsBY6LoOlRt8zufMvdU1S9maS91jXNWuS99rGtalPc6lql9LLdXlxLK5I9goor9HhCFOEadOEYU4RUIQhFRhCEUlGMYxSjGMUklFJJJJJWP4fxOJxONxOIxmMxFbF4vFVqmIxWKxNWdfEYnEVpupWr161SUqlWtVnKU6lSpKU5yblJttsKKKKowCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooATnjA4x34xxwMc856nHT1paTk447Z5/QY55z1OPzpaX4/lo/nqvz/ACiiimAUUUUAFFFFABRRRQAUUUUAFIVDDBAIPX9eh6g+h7dqWigD8nv29P+CNX7Gn7ew1HxT4v8J3Hws+N1xA4tvjj8Ko7DQ/F17crGy248caXJbSeHfiLZo3kxt/wk9hPrkFnELPRvEOjKxkH8eX7Y3/BAf8Ab3/ZXn1TXPBXhBP2pfhXaNPNB4x+Cun3d140srCNnaOTxP8AB+4nuvF1tdCGMy3DeDJfHemwopea/tgfLH+jdRXzOb8JZRm8p1p0nhcXNuUsVheWnKpJ296tTcZUqzbS5pygqrSsqqufuvhz9IfxG8OadHL8LmFPPuH6XLGOQ5+qmLw+HpLTky7FxqQx2XKMb+zo0K7wUZvnng6j3/x6bq3utPv7vStStLrTNW02d7XUdJ1K0udO1XTbqNiklrqGm3scF9Y3MbhlkguoIpUYFXRWFRxokMzXESiK4eGS2eeLMUr28wCzQPJGVd4ZlAWWJmMcigB1YAY/1av2jf2Fv2Q/2trN7b9of9n34bfEu8MIt4PE2qaFHp3jjT4lQoiaV4+0GTSfGmlJGCCsen67bR/KAUIGK/Cr44/8Gtn7LHiyW71D4A/Hb4wfBO7mMskOheKbfRvjD4OtmYlo7e1i1J/CvjSKFeE8y98bapKFGSXPFfA43gHN8PJvBVcPj6ad4rm+rVtHdN06rdFW7rEN3T0V7H9h8J/TF8Os2hTo8TZdnXCOKkkqs/ZPPspjdK7jisDTp5i1zK/K8oSSaTqSabP4bMD0HvjAr234C/tJ/H79lzxc3jv9nf4veOfhD4mn8ldRuvB+sPa6Zr8Nu4eG18U+GruO88M+K7ONhlLXxHo+pwR8mNEY7h+7HxQ/4NgP26vCbXFx8Mvin+z18XLCMubeC61fxf8ADXxFcIv3d2nar4e8RaBDI4/hbxWY1P3pQvzV8OeMP+CG3/BVPwXJKt1+yZrfiSGLdi78DfEX4S+KoZlXo0MFp43h1Ihv4VewRzggoDxXgTyPiDBTjU/s3MKVWnJSjVw1KrUcGrWlGrhfaKL84VE9T9lwvi14O8VYOtgnxxwXmOBxkPZ4jLs8x2BwcMVTlyt06+XZ4sLKrBtRcqdTDyTaV07JH2J8OP8Ag5w/4KD+D9Jj0zxt4P8A2dfi5cQoEHiDXvB3ijwhrtw4GPNvV8E+L9N8OSOSNzrZeHNOjJJCJGK8e+Pf/Bw//wAFJvjVpt5oXh3xt8P/ANn/AEa+he3uP+FJ+DXtPErwvwRF4z8c6r401rS5wOEvvDv9g38R+aG4jbBr4tv/APgln/wUk09zFcfsM/tKO472HgCfVYwf+u2l3V5CRzwwkKnqM4qfS/8AglH/AMFL9alWKx/Ya/aJidzhW1fwjaeH4Rk4+efX9W0yGMZOdzyAYyc45rqlmXFtSl7CVXO5K1rKjio1GtFaVSNNVpXV07zd763ufL0eC/o34PGf2tRwHhVTrKftVOrmmR1cFCSakpU8DiMdUy2lyvWCpYaChZOFrK3xk3iVfG3xAXxb8ZvEfxA8Xf8ACQa5FqHxB8VrqyeJ/iZrlq8oe/uLbW/Gl9PDe67NGDFaXmvXV1aWjus0trdRQ/Y5v6CPgn/wXo+GP7FHwjt/g3+wh+wB4Q+HWlgxXmveNvjB8V77xp4v8e69FB5DeJ/Hz+EfCHhe91/WJQX2xnxVb6ZpcEh07w/p+j6VHBYxfI3gv/ggd/wVa8ZvDu/ZpsvBdrKUBvvH3xd+FWjxwhurTWOkeLPEGsfKOWSLTJZRziMng/ffwm/4NYv2r/EMlpcfGb9on4HfDCwl2tc2ngXSPGXxV16BSRviK6ra/DXRlmAyA8WpXkIbJ+dcZ1yvA8V4epOpluW4mhWrXjLE18JRp1VGVuZU6+PpxdKMmm5ulODnpzuSiuXn4+4z+j1nWDwmB434z4fzbKsucKlHIsp4izPGZc61FJUamLynhHEzhjqmHglDCwx1HE08MuZYenSdSo5/DPxt/wCC/P8AwU7+NkV7p1r8adE+CuhXxYNpXwM8E6V4UvIomyuy38Y+IJPFvji0dQQPtGneJLCXIDqUbgflglv8Zf2lviSkEMPxX/aH+MXiOchI0/4TH4ufEbWJ5H55Y69rkke45LsVt4RyzRxrlf7nfgN/wbI/sHfDeay1P4x+JvjB+0Zq1syPcaf4j8SQ/D7wJdSKM5Xw38PYtK8QeTuGTbah421OFh8kiyqTn9zvgn+zf8Av2bvDSeEPgL8Hvh38JPDwSJJ7HwJ4V0jw++otD/q7jWb6xtY9Q1y9HJe/1i7vr2UkmW4ckk/QUuDc+zOpGrnmaOMU1JU5VqmNqx7qEHKOHo32Tpzkk7vkfX8bxv0nvB7gHDVsH4UeH1OviZQdP67Ry3BcLZfWWijUxGIjQr53mFrJyp4vC4ec0kvrEJPmj/D7+xj/AMG1n7Wfxym0rxX+1HrVj+yx8N7jyLqXw2v9m+MvjdrFm4Ehgj0SzuZvCvghpkHltc+ItV1LWdNmOLnwfIUK1/YN+xj/AME4v2Rf2C/DjaR+z38LdO0rxJfWaWnib4peJXXxN8VfF4Uq0n9u+M76EXkVlLIizHw/oUWi+GIJlEtpolu5LH7nor7bKuG8pye08Nh+fEJWeLxDVXEbJPkk0oUU1o1RhTutJuR/K/iN46+Ivib7TDZ7m/1LJJSvDh3JozwGUWTvBYmCqVMVmLi0pReZYrFqnNOVCNG9gAAGAAB6DgUUUV7x+PBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAnPGBxjvxjjgY55z1OOnrS0npgcY78Yx0GOxz7UtL8fy0fz1X5/gBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkKq33lB7cgHj05paKAGCNB0RB9FA/kKDFGesaH6op/mKfRQAgVV4VQo9AAP5UtFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAnPYcY78Y9BjnnPXtilpOTjjtnn9BjnnPU4/Olpb/j6aP56rp+nQCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADeew4wOvGMdBjnnPU9gPWnU3rjA4wDz046YHr6n2p1L/g/g/nqum3ougFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAG89hxgdeMY6DHPOep7AetOpoycYHBGfYY6fj6noO2adS7fP8Hu97NdFp6LoBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBozxxxgew9uPXODnt0HTJdTBk446gHqcewA9c4PsPfkvpf8AB/B/OzXRaei6L+vPpp1+f9NFFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADQDxx2HU+nTj1zg5xx0+rvw/z/kn9aYM8cDGB9Pbj1zznHHQdOX4HpS/4P4P52a6LT0XRf157ry2fX+rFFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADBnjp0A5PcdseuRknHHTty704/lx35/H6800ZOOmMDvxntgdAcjnjj+bsY7fj/j35/HnrS/4P/pXXezXRXXohdvzXy9dH1/ppaKKKYwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGDJxwOg78cdvrnGT26e5cBjHH4+nfk5z1+tNXPHcYHfjj29c4ye3TryXYx2/H/Hvz+PPWl/wfwfz1XTb0XRdvz+710fXX/MWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx0IwO/HHt65xk9un1dgDt689/XrnPWmjPHHUDv3HbHrxkkdMHGTyXYx0Hrzn8eT15Ppml/XluvXVdO/wCSWtn6a9dbdNd+uunfstFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEYzxx1A4J9MdBnqD1OOO3qX49B2Pfn15Oc9fTNMGePcDgnuMdB6jqSM46Dkcvx6Dse/Pryc56+maX9fj89V077+iWy9Fr16eu/XX/gLRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGCeOOw6n09OcZB6+nb1L8e3OD36d8Z69fTNMXPHHGB1PGfbnGRjJ9Mcepfj25we/TvjPXr6Zpf8AB/B/PVdNvRdEtk/TXr03069fT7looopjCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjBPHHYdT6enuD1Pbt7vx7c4Pfp3xnr19M0xe3HUDqfTsO2QeSRnHIHPV+PbnB79O+M9evpml2/rr13s10WnoJbJ+mvXpvp16+n3LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGCeOOw6n09OcZB6+nb1L8e3OD36d8Z69fTNMGeOOoHU+nQDtkdTjOO3PV+PbnB79O+M9evpml/X4/PXttfsuiWyfpr16b6devp9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqTxx2HU+g7dsjuR07c9X49ucHv074z16+maYpPHHYdTxwO3bIPUjpgjryX49ucHv074z16+maX9fitevqv6sl0+WvXpvp16+n3LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGM8cDoOp9MdOeoIyeO3HIyXjoMDqPX1569evcZ9aYD0+g6njPoO2c4JIzjoOer8e3OD36d8Z69fTNL/g/nu97NdNVfsiVsn6a9dbb6ff5L7looooX9f1ZFBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAIx246gdT+QHPUHr6dAPV+Pbt1z684z1696YD047DqfyA7ZB64zjoOer8e3OD36d8Z69fTNL5f8HXrva3RXXotyV0fe2u76b6dba/f6LRRRTKCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjXPH0HBP8hnsevHGCB05cPYdR1z689evXuM00E8fQdT37Adsg9cZx0HPV+PbnB79O+M9evpml/wAH8+u+q6LT0XRLZP0169N9OvX0+5aKKKFt/X+S/L/IYUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNc8ehA4J78cDnqD19Og9349u3ryM8kE9evcZpg7HjkDqe46Dr1B646dBz1fj25we/TvjPXr6Zpfd/wAM+u9mumqv2RK6fLXdvbfTrs/T7looooX9fd10X9fcUFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjUnjp0HBP9M9QepxxjA6cvx7duuefXBPXr6Z5pg7cdQO/p2+oPJx07c8l+PQdj359eTnPX0zS/4P59d9V0WnoukrZP0166230+/yX3LRRRQtv6/yX5f5FBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGL29wOpOOOwHrnBOOnTHcux6Dse/Pryc56+maaueO4wO5xx0H1yBk9vryXY9B2Pfn15Oc9fTNHb+uu73s+y0/US2Xotd309d+uvnfstFFFJf13frotRhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGAnjoeB3449vUHknsOOvV2PQdj359eTnPX0zTRnjoQQO/p6D1HUnHHbnq7Ht26559cE9evpnml93X8H13s101V+yF2/wCHfT1366vvfstFFFC/r7uui/r7hhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAIwenToOp/LA9cjnjjsM9X49u3XPPrgnr19M80wdunIHU9cdMe4PXjjsM9X49u3XPPrgnr19M80vu/wCGfXezXTVX7IX9X3fT136u/S9+y0UUULb+u3ovy/yGFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjBOR06DqePQYGeuRzxx256vx7duuefXBPXr6Z5pinkdPujqfyA56gjnjjt6l+Pbt1zyM8nJzn8ieaX/B/CXXfVdFp6LovNff16eXXr6fctFFFC2/r/JfkhhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1JyOB90dT6dAPcEcnHHb1LwPb/Hnk/5zTAc44xlRwWzjGeO/QjqM49Ac1JS7fP893vZrotPRdF8rfn0339Hr0XyKKKKYwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKD0P9en40AMXsf9kZGenH0wfTIwOtPpoK9iOnqM8ev0BB/HtS5HqPz9en50ALRSZHqPz/P8qWgAooyPX/I60UAFFJkeo/OjI9R+dAC0UmQehB/H06/lRkeo/OgBaKTI9R+dGR6j86AFopMj1H50tABRRkev+R1oyPWgAooyPUc9PejI9evSgAopMj1H50uR69elABRRkeo56e9GR6jnp70AFFGR6/5HWigAooyPUUUAFFGR6/5HWigAooyPX/I60UAFFJkeo/OlyPX/AD1/lzQAUUmR6j86WgAooyPX/I60UAFFGR6ijI9evSgAopMj1H50uR69elABRSZHqPzpcj1HPT3oAKKTI9R+dLkev+ev8uaACikyPUfnS5Hr16UAFFGR6jnp70mR6j86AFooyPX/ACOtFABRSZHqPzpaACikyPUfnS0AFFGR6jnp70UAFFGR6/5HWigAooyPUc9PeigAopMj1H50tABRRkeooyPXr096ACikyPUfnS0AFFGR6iigAooyPUUUAFFGR6/5HWigAooyPUUUAFFGR6jnp70ZHqKACikyPUfnS5Hr16UAFFGR6/5HWigAooyPUc9PejI9evSgAooyPUc9PekyPUfnQAtFJkeo/OlyPXr096ACikyPUfnS5Hr16UAFFGR6/wCR1ooAKKMj1/yOtGR69elABRSZHqPzoyPUfnQAtFJkeo/OloAKKMj1HPT3oyPX/PX+XNABRSZHqPzpcj1FABRSZHqPzpcj1oAKKMj1/wAjrRQAUUZHqKKACijI9f8AI60ZHrQAUUmR6j86XI9RQAUUmR6j86Mj1H50ALRSZHqPzpcj1FABRSZHqPzpcj1HPT3oAKKTI9R+dLQAUUmR6j86Mj1H50ALRSZHqPzoyPUfnQAtFJkeo79x26/l3oyPUfnQAtFJkeo79x26/l3oyPUfnQAtITgH1wTjOOn+evajI9R37jt1/LvTSwwwBU8dNw5yMYx79Pfj8AD/2Q==' : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAABcCAYAAABgK+tjAAAQAElEQVR4AexcCXwV1dU/s8+8eXvy8rIQtqAsiiigbAHDlhD2xcQFQXGjWrVV+33VajUtbb9WW1qLn9a6UHFBiYCENSRAFJAdFEVFlkBClpfk5e3zZp/vjv3Fj6rkBUggqPf37pt5995z7rn3P+fMuefOPBx+TJfsDFxS4L14zz3UJTvTHSB4pwfPAMDWFTzg2Tb3v0enRrnpf5/3gAd+TF/NQKcGb0tOEblh1l39u9mtiyhMn2noys4HFi9q+kryH7+gU4Jnmsc1c+68ksyofz6FZpYElFj5Yd336PS3n6/GAIwfcfv3DHQ68FZOv93ZJyjP8ajEO3aK1xRKn3uIFV+b+/rrsX+L3Pr3soICwgS/9Vbfj9pOA15RURG+dfKtA3oY5NJk3PaYpBrPNMfi/zV0yQsH5//zn0qi6S79xS/4lXN/ch1lcedAPJ6G2iMlRd/f40+nAG9J7hx+3LbPbnBI2hodjGBdJJY3svil10YXPx9NNPfL7rvPWnHHw6PpgP5mkjt5MobzX9ZlZZ1CdN9783rRwVs+c2ZaVz28gFPkl1SOfOeEXf7ZuLWvHkdq0+rkm+axZNZtV/QW6OfcNPXnEKm8ciQsPzN98cJqpMU6Au97/+lA8BLP3VtTbk52+qW/M3HpIbDzTx0VxAUzX3+9IRElAgdPBfuEHiRTLgoxvi7kmz39xUWr73z16Ugi2u9T/UUD762pN3vTReUFm07dENHwR46x8qLC8uJQosldVnCne8KB6idcEXWNEBVWHiOi9+Yt/dcXiei+j/UXBbxXJhT09jRFXmZi0g0iTi4IZvIvFBYXa4kmeFnBPY4eCjxOx6VfC6D9ptGhP37L0qU/2HXfBQevNHdOjz5B4X/xxubJOkEsqqewvxQWF8cTAbd10i2urIbQH3BJmR9i4aGTNukPk996K5CI7vtcf0HBWzI8N4Wpq11oiclj7d6MLTVALWiLqVyXP9vONYm/I2PifTFMefETxf8SAlz+PgPTlrFdMPDKRkzuOkiiFjoUY7rIcUdPusj7CrcWNyYS0gQuuUl4hFTV+wIcvHeEjP3lwfXrpUR0P4T6CwLei+PGOZIV/ddCbf1snONAtFkeu2H10jY5GckBeaYtrj1p2CzHRI/tvjtLSmp/CMC0ZYwdDp7p1l8dZW+WAs13RWiAMM++1Choa9siXMX1M4a5YvKfNRTOPKrGfj5hxRt1baH7obTpcPAmbfh0lNsv/U6XDLBmZnzRyJJ/LdyR2EEpGzejb4akveCvrk6ik9xvG2lsxQ8FlLaOs0PB2zRmcgbjCy4UmiJJLG0zmlXsgZnl73yeSLgXp0yxsJHw/Q21pwYkdU2LNOnKX5GD8v+hskQMfiD1HQbelpwckvdF7iTjwjUkQwPhdr9bx4a2tWVeu4dj11sF5XYcMAhyVPGpVOWjttD90NrgHTXgqCBf66LJeyVZACLJLp2ijVfnVVSIiforHTUtMy1M/kn3RS0kZ4sHkiyLkNbJieg6Wz0KzGIdLVOHgFdUVIR3Y+2zfccrUxXQIUQbq0+QkFDrzGCzI67cF6tu6k+SDEg08WqQVz7p6EnoCP5vzp6dsfj229mO4N3Cs0PAG1G2bbhR3Xy7nbAA506CIIkt+WlFccJ7Fl8T68/L2J2shQPcyQu607YEaV3CsFnLYDrTkZYNbzpJmvuKHSYW3t6cl+ZM6O6IE3+DiMwrsgFxC707pIsfJOrnxUH3UB6DujFwqsYTjUZA4rndTTR2LBFdZ613WjiWEbWcjpSvXcEzzWVX3TrLqG0eJEYkALsV/DT2auG+8oS7BS7iRBdLVJ3CGxhYHXZoprD1Mzet9Hfk4DuSN4URfjtBuTvy3teu4PX4YG8aG4jdyEg62Hgb4A6bv4bWt7dlktI523RcEK5QBQFoqwUkO/tpW+g6axtNVmVDloiOlK9dwXPKeH8rTgzU4xIoigYKw6wOG46Epm9Jbi5PhsU7I4EgUBwLOsec9GPy4Y4ceEfz1hTF4G28vSP7aVfweEWb0lxdQzAUDRanE4FHb324DdGU5GbiajYm9QZVBcAxCKvKNikzpaojB34m3u1Vjra7jHAowv6mqAhrL57f5IN/s+Bcf795zZhuySo204ITIMgSEA5rNIJpCbXHXMw7o9p0iAkkReBgGAZoQGxoyxNj5yrrhaDDSJUkWY7pyL7aBbwiKMJ7MrZ7NZ8/VRFEYJ02CBH64Zpo7GhC4WOW5GSKzI2H/u3TUHYegCf3J6Tr5A04nLGROG17qqjI6ChR2wW864bs6uOMyXON5ghgqgJhRYRmHt9w96ebfIkE52iiOyZIfS00C5KuAm63nkDAJ3wIKRHfi12PxfUsOa52GHDm+M4bvKKiItyLUYVyY3MabWjgcrkAOBoadXGF2UFr2YyoEHF1crPPR2myAjpBApZs27ovZ1Bza3SdvW5LThHpwPnRJE0nfITxfMZy3uANWr2PtStGPxBiQJM4+PwNYHE5QiqLJ9SeSK1k4UnmSjvHg4acFcZmhWpd/BhdEJf0c5dhexXH6MYIRZRrzgecRLTnDR7DYk5KVq8EZPJEZDKdKcmgUliVAkzCcJiNUnlJlrJisgjJyclgHkXAzKedE8ndqettktxTj0peFYfj3xQUXZj4snkP9Fv40EPcN+vO9vd5g4fp4NVUuSfG0oBZaPCFQ2CQxCGAoJhImKgqWXAH65UoDOqbGsHlTAIKoxLSJeJ7MevNW4FVI6YQOEaLmvKtC7FfQ4OlB8fnZUmQcb5ynjd4pA69xYj4lUsck0SwuWwg40blvDZs/7C8hQtFojYdA2A5C8iyDAaBX9LgWRvpNErSbo8p0s6gon3rmdJ00YpZBIWj4gJ9UcEzADA3xY3SJRXdszCgCQYwQweVMCqhDUmWVSenAUuJKiD8gEHRFVlDNrQNtJ21iUUT8kMhX1YDqb05471/BU+T8+tTDnQnQbG2rwvO8QQ/R7qvyMzoAaXpWbquA64bQBgAJIIBB6JN3qIbJ/sYcRkopHqGqoEOyF1lyEtu4/WryUBfb+fOuNKu6r9M8XhOCEl4OSr61keJRA2SxCiCwC+u5g3at49VdbmLbigIPA2QCQXSoADTKflbUn9HgQtj0qRgBHAcBwzDwMAwxQBa/Y6mnb5occ7tbJcIPp+V9KyIGC2a2coLM5KmkJSCJuo8R4W3hd4AwBYWFLjhG6lZIDkV5BQdUxB4KhA6AIZ0D0gS2pKwoNDFzVtB1zREQoKGGXRQDDFtoe1sbTIJaaRNh/sFEvuI7el490zyUTYRU1XFRWBw3uPEz9TJ6eWvz5lj6c/bp68umPsfHhJOYrQCGqMYGgJNBxxpj47A0yCxRTAAMIts2KRwFBiSAh2ZTUPHcJ5C+0FwaaUNebf2sobEZ2OqDI1u6ukBrbyCTUo8pqiqRce0Ns19azPRJgaZ1dWSTTHs6TQ32lyntDBUMYHBdJ0iDASZDoAjRHScAJU0z1panfnosHA4jYBTJBk0RQECXQIkg7dNbc/M9oLWrBtzY1ZSs/iXoK+xr2JlV8dT+I2tCRAVTlEUTSYp2gUCb3RFhSpr2hGeYqYP+OiEvUU4XsEsrKYznALAasRXk6/jAFJLgwTHgBBBsGtofWcHwsBARFpIqZcOeKum3mHzhmM/J4LBqayTjwYI448zlyzxtzZsDMOssUCgC5pPrbV2balDU92WZgAyRu0VYpLVg5N5SMEwk4rVdYzScYxAsBlIawzAQUOrdiBUszphxhy8KiEfMxgMAof2AO0UC4YiJ7a5CTl3fINVU29Kd9XWPa3VNNxPEpiMp7jmTd/87oeJeiYkvKsal1yGpomJ2iaqxxM1aKkfu/Tlhoiiv2o1iBf2T7ptoFnuICmZoBhDoSgII9AEXAdNl0BDZtCsby0j9I1mxvDpHAUkSaKrA5lNVQVG0lJao+sMdSvGzeibUtnwV2dj5CcOhgPcwf9u1Ka3z+iknC4zK6vX0RgJKHx23u9dtBk8c7J9FFaKYdRBC04t+nBMQQYugBSLRONx5C1SDjtoJI70TwMHheGnC3ym8yYtXo3if0DSFFpeGBD0NUGGw9nrTO07Q3lJzoxsb33kDS4QL4yFgqAk86tPctRLbZWN1SCbBKxW06hvhc7ayqOl3f9PcktJK8fC4n+G6tT4XWiH+HK0Y/5kptWZbOVshumkREVkAHUd5HAYGEVOaoXN11W43XaY4DiICQLgFAlWBKLSGBi4Lj+f+bpRJzlZNqKg66ZBU37hOd64nmsMD8RUHZx9szbUdnM+MqmiuL4tYm4bMdWWTPDDMEnbd2Bg11hbaFprg7dW+V11E0peOVoVCd5LkPQ8OaK8rYRjvJVkAFc0sFIMWDEKGBmuXVZQQHwX/ellqqL5aJrRMJIAGe1IKJIEKRzfC9etaDv99JYX79z8j5iV/XPzeyvYm56Q/IwREa2UzQZSmvu1T1RlXu7yt460VTpDiE4ONQe8BMd/gLx2va10Z2p31uCZjA5hzpIQQfzK39R8mdwYBmgKgxtw0JtDyOvEgJTka6AREm95KGpMU7Qww3BAcTSKsAAE6urTsLjoMPu5mBlNLl42YubQy33Bxd1kbE3T4S+z6/0+EJOtWrXH+tSJFOvDhXvWtUnjzHFsyZnuZEjmQWtK8im/Im81y843nxN4D65fJB2qp57F05OfIG0WsCFF0Q0VaJoERVKB0Km+gMcTAmAFa8xusfvRohXCkgAETYAWi+MWgr5oTguyGPS7oyZflrd279OOmqZSqq6+QKyvwy12Fqg0d6PU3VMwcceq3xaWFrcpfmsCZABgmqJMa25qHOqLh96oc+vHoB1Sm8AzO39j9uyv13dmv/P3/VPZC+qzetfkVc2UAgK6S4k0BlFdh1A45qCB7Wa2azULQkSJxU4aOAYYQ32leVLYvGdi2a3StXOlqWXrRhZ4tg6bOPnyqvjLlzWLZXxt4yPgb7RjchwICw6G174xnGa9Mb+seOXZdr941LQuVh2/z+l0Qr0hrShsw9+WtKUPvC2NFuXn01mG/bp13wDwpxXF0Tot9ndragrIhgEmCDTPIu2LAR+IDUrEe+r2kqhGU18aBAYKWq7rmA40TiLTq+X+Pf8BdDlAhybTMXove9qQsRv3/La7JKxwN0ZXS19WzjFqG7qp4QgAuqggxRUTu3j+dMpK3jZtU8mWcxEoBbBcNSJep9H00jo7hTaqz4XLt2naBF7zkCGKJjd7PYzlOlMLT2cjKuwXOGE/jCsk0AYJOiYBoUQhVRYe33f1+J9uGTq9u/ls5uk0LecYgNFEiJ9hLA0kSQJogHhgQIhq/xSloSe0czLl2JJzc/KunFmD9w6fvMDTIO/sHgxtpatqHo8ercwWGn3AUQTENQmt3WxAX5a16ZjHnn/9nrJHCyvafn87XewtObP6dAlpC3iMU2Ikt3D+6tXC6fXnc94m8JBZ0SmWikEoXlBRcB//Hx1akiMi93TvlQAAEABJREFUTR6nOB7ipsuvasAhFMSaWq81FH3OXdOwOi3m+Ev5kOm3vjFqYv83huTbT6e3suxWhqECZtlXuxJoX5CMCt4eBplllp1PLoIifEXujJS1o6cN2ZVTcKdXcjzt9TWtTK4NfEAdrXmCqKy/WjleQ7FRBVRBRlcOAyKyHHz/3h+He6Q+fNBN3lKwfe05OxcvjhyUxgdCz+jBSJpEky99OL5/uz6P2ibwzAkMRtR9Htx6uT0anHa69tWLpBjl6E+D6F7HW52m1gCnEsDgNAQbA6BF41dGj9c+mFQben1AE1HaL0Yt2zN46ovbrpu4cOvAsRNS4jprY/kGFa0TKVP70I4eFojhmRFljKkp0Eoy5UAOBrF30D1UaW4uXz5kqnfLtQVXbx0048GDg6f8Y8bAvf/q26ys6+6PbyaOVL2snKh9SG/wZweq6zhd0IDRGLCRDjBUBjJ69Imwmb1e9LmSbt1rwaaM2rrqr3M3rkz4BNyZxFudMyW5n+R+SmyKTNbsliot1fVCUVGRfqb251LeZvByV719qi4Se40W4eU9ubcOa+nMdFyalOgmq9cDkXgcbBYrGKIKiqgBz9vAarGCnWJBbwqCeqI+jaxuzIPPT91jP970kNcvrRdqG7YHG329GYYBSZYBx3HQRQnEmvq5WVLK/NLsaVPWT5szsSTnxsmlY2+ZvW7krHt3jSz4r6MDpj9RfUX+wms+Cy2xSkc2Zp5SD3ibI196ff4DSTWNz+pHTs43jp2YEztSOUioqrFowSBgooKsgwS80w2qBa1kkMxqRvqXWJ/LH/+So4b037/iJ1P2r3/zjo2rqlvGdy7HZTkFVltD9DGuSZ5P8jxEeXZB2bWZn50Lr9Zo8NYqT6/DAIzPbeRawuH81EHTz5ROuymzpV7BscOs3VavURTEkQYSaGJImgFPincXaeHmqxT+16Su6TvcGSkRAB0sKJIiIxMrhaIAEZEgFR0EUQQd3W8UVK8aOkiSkBQ4eeK5pNrmEsv+I2vdR2tX2z+reiPjaMPz3GcnnpaOHV8QO3ny51L1yVvitTU5kaa6y+LhRrscbQJDCAGDggYUkoVFsoiGBqzbBbrVAs5uGQE92b1W7pb+p5puSYW7usDoAXvf/sP4/Ss/bxnP+RyXj8xL61rXuCA9gj9MSThoLtvfGzHizfbWOlNG3Pxqa76jeHEjCo/Nb4qGsxhRvd/01kxahaWaorqyUyEA4rICQkwEHAVfQ0KcMyh6Q9/q9x+psqqzDrLRvHCG9SdSqr1CS3MZutMKCtqTEAQRON4CiqYCySDHBTcQmBGINTYA3RCE5LAMjrgCVCgCNAKciohgAkMgD5dEABGqCqomg6RJIOsSxNE9V3PbwM9Q0EDhwPftVducbHslkJY046THlnPUjt08Ys/KR3PL3iq+s6yk3f5R6aUhY72ZUfW3bCj681AIBSxSPZtjTvo3hW14U8qcx7PNZwWeyXzsmsX7xSTbIguQPyNCxgyzrBAtGWIg/CMpzYu8RhocVgcosgyiKl/lw8RsDMAYta+0bson7+/I/mzTix97lfyTmcmjTjnYh209u7+X3q1nHc9ZwW61gajIEFdEwJEWutxOYDEMmeA4RFQBFCsJiouDIK1DmNQhjoDBWQvQVhfw7mSweb3gyOwS4Xr12FaX5vqnPuSaJyOXZeV+wlNXjT5Qdtfo3avfG7d1+cFp20uQBTAlb7+8cnh+Vt+4uhAPNt8V1KJAXNGt8iir/XLCWSzmz1aaswbP7OAoHn0dANtFxuWX1k6cOgFQwrnIhwZufKFhGESEODAkBZFAAJAlvWv1oCkW1OTrz7yKCrGwYuW2SR+X/7XKFSqosZNjZBd/G2bjj5u7DBzy+BSkhQIyrSwKXKf17N5sv7xrg5qZdEru4j5E9+7xMX15t/10r54b8R6Zz8oZqU/6U5x317j56ZUOcuQhuyV//J7183PW/mvBtE1Ly27rwNejlw0r4N67JveGHmH1DcYfuUWIxcDSNf1UJWv8fNL25Xu/HnQHnJwTePOLi6uihvqwA6e1lIC45MOBI/Oyt2+PIAdzi4BpQNh4kKU4JKGYJdEQGc1gyhlfrDd36QfvW/1Fv4Prl8STrX9jnDZQFAUIZE4BeZ90srsm5uJm+Gzk8EoeRn1pxcces3Djj+Js7idWdtYbewY/3H/P2t+N3V768qStpasmbCv9uBBZgg6Yq2+xXHptbmaaEF7gbY6+rPsCQ3VZB2ta16ONNnbGrC0rSr5F0M4F5wSeKcOYjcX74jR9txaMeRyS/o+awbnjlXDkE/MtoRi6+kgSBykSAU42wKXhc5fk5vImXWu5HlfXgY05jiHgDNUAHWVRUR1RRcHGbn7v2NwPNlbesqnEV7i1uHHm7pV+E6QiKNIxAKM1vu1dZ65V116ZPfmymLiUqql/hIoJDlFDF1xa6qFAkv3OSRXrOlTjWsZzzuCZDEbuKCm2e70PMUB3i/lDy7q7UuebYJlLAwzDwAxWU8ipwPzhSdYIO9KkaS3nf7j+uE5yL1ssVuBpC1hJDqL+oFWOSHdsQe53a7QXos40/1uuyRvX1e9/PjMmvU40NYzAlDjoLAFk97QNTWmOuWM3r0j4tyXtJet5gWcK4YPmf8QY+g8S4M5jlZUDGut9oMalr15PJpDZEyMx4BXMmhrHJhfl5JAmzZkyhjQoiMNSsNn8MUkGEa0bCQwHQlSmy2Gh95noLkR5Sb/RV/SIa7+2+wLveuLabM3f7NQkBfiUJEN08M/57NScCaXvtGsEJdG4zhs8dM8ST3DMn6SUpJcwmw0olgEera0MpHEcYwEMHfVwFDxR5cYx8aR+iQQa/dGGE9W49kcq2QGm86LqKqiCYE+VsTuRbUT4/geHDv1hmvoN2TMGbO034dFeMbwU8zU9iq4oR1MwiNakLNDJqeE6DP9VPIN9dErF6qYOFeY7mOPfUXbWRabr3eB2/CKUxD9ryUiBqCIAhhEQjQoAOAmKKoMUDCSzUeGxV0ZMtSXqIGbnl4OVO8BYGAjHwkCgtSMdk+a8P2TqGR2fRDzPpn5xzsTUlYNyp6dWiv+bWRfeYK9p+B/D78+Ih4MgazrwaRmAdelSVmu1Tt/+5fin8zZujJ0N//Zq2y7gmcJMXP9m+KSd/J2QxCzSOAowIIBF9yxg0TlPQ1QTQI4Fb8qQ1RsgQZq6e3VljISlFFqwJ7kcICIAtXjUSonSY8+NHZuUgPycqhfn5LBrBudeuXNQ3s/6VIWXd/NH30mNCbeJ1VWpHCgApI68aAvYXMkNAsM/dYiE2yZ8XLrFdJjOqcN2IMLbgcfXLG5BpuNTp/aY1ivzESrd6xcoAIkEFDJTwEDmjxAkyFSIx8sGjMv+mugMJyFcLZas7EcxRQK7lQcBAcjKyvgucWbqGUjOqvjv+fnM8uETu60ZmDey4qrcxwaE2PL0pvh29kTT32xNkeFYQzMNIQGcvA1kHAfNZQ2qXTz/qElirs8+tP63c1DQ4aw67IDG7QqeKd9cZEIG7yxZWOWxTCd7ejdrSHsoIFEEnwA6KoN+ypfVI06+vrdf7oPbRswavOSq3BT4jpT/UcUJn8vyK9rtjImyBBTapY/V+yAjpj2wekxBxneQtFq0rF8BXX7t2J6brh0zfOeQvHnZ9crz/QSjvEtA2GRrCP1Br/KP0JvjdiWmgYGxQFI2kHQSqCRvTEvxLq932m/YT/V4MG/fxi9a7egCVrY7eC2yj9++ctthizoPMr3vSCiMZaCr12ou2pGHJtbWd3cEYs+mNYc29wFtXcWw/N8uGzzmuqUjxqejbSDW3OYx+YQyHRsVVf+L25kEhgzAqgD2mH4NVecvMOvPlJEpwxEP+q1BOcn/unbEFaUj8m/soda+0ieClV4W0cqsJxteJSrr7oh8frQXGYxSDNrL42QNKHMv0spBxFAgjMw93afn5s8pecbhNMftuQc2bDJ3UM7U58Uo7zDwzMEUbi+vqnaQD7JZPZZjdiv4hQgIKHBskACSEIbG4ydshq95EF7p+3X3oLqzbxA/ZKshd2V9FF5xcMDkBX0+i93ooVxZ0SDSPIUBm2EFqc4P3RT81xuuGj13zYi8kaXDJ44qGzo5p3zYxAmbBk0q2DIw//HRA/e8lHokWtFL4z+9JsgfyDwuvO1s1G8NVTb08h1rsBAqBaRGI5/IDlExDjKmoUC6jlYoqNyKh5kM55pwD9e07bxyQ97nm8oKKxL/VyhchNSh4JnjmYk2NI+yyqNainML53EDRpEocoICz2jbx86yoIejYEcbsGxDFMOr/U6spvkqzNc8Nfp55RN4nf/NUH3DbF1WgSZJYAgcCLT+U+t9brTmeq17Y3RTlj+yuVcwsslb2bg+rSG8jD5S/zv+VOgOONE4TDlS54WTfoqPqSCj+xeOkcCxPIRiMYggDzigy6B6XSCnuxW9a8onIa/jf5q89rxaC39j/s61JfdtWxuATpw6HDxz7IUVJUdraP0x3O2o0pHbT2kAqhwHQFe8hSbBDKNhqgoKmlQbZ/kKpBSnA1QhhjREBqeNhbgWgeZoA1goA3hNBbGqGihfM6VV+gj5hA+3qBhE6xrAYeDAREXwAg0s2kayWljwi2FQnRSEKRXiuAqWZBfYsrqI5GWZnzV4+We+SKbyD6XSk68+WPZ49q71O6fsa7/nTKADE96BvP+D9fSd63Y1urgbknt1r8KRxpEIpLgkAk2QwKF9N6vVAk60LJA1EeKqCAG0oYpzOIhaHAKhJqBZCix2C6iEAYquAIPTQCoYOBkeMNmAaCgMHNqBoNHFoKMbZFyMAOe2QICSQExCGp7pAbpf9ybi8u4VjR7bQ4dY7OqP0olrZ+4q/+/bt5ZtKixfU4WhCA98nTr/CX4hRRz3/oo9x0ntfsOT5AsZABpFA44TQADSGjEKNq/7eUe6+4/W9KSNlh4ptarLApTLBlZkblUw0L0JAwEBL6Klg0yzIOIk1CFtBQQ8abeBYaFBszJAeB3A9/JUKV25LaE07qVYr+QHa21U/kk3c/0Onpoydv/6vxXu3XC4PZ/kupDz2NIX3nJyoY5bpw5fW+e1/dTo0SUUR9oXFhXAEAisCUpcIGhc+5tG6LOCtDQq6OayA6mOWwOZKY8Fu6c9Kfbu9SQ6PtGcnvJi3OuS/BQAgXbMg5IAtmSHwLisD4g8MVmyM8OO42rOCU6Z5u+dev/4resXTdpWsmH6+uLPzGdNL9RYO7qfCw5eUVGRPmbre8ur3JbxWpp3r8LzYBA0mM+zxPxN80VZ/KPE4Ekj9n14bMzeLduzP9r05nV71vxx1IHSBUN3rFhw/d61vx/9SdlPjiVxN8W7eurDhAI4hyHzKnAyLrE4RVUMOli+M+/gB5XT0B5jYXGx3NGTeLH4X3DwWgZ606YVexpSHPPUrmklkoOHr8weqgyHorejeNjSzaPzZi3Ly3Ojou/83LJj/XtVHPZTMtVzxBqJpckAAAVQSURBVOAYOHnqFIqmEn8QCfWZ9SMnXIXWecR3En6PCi8aeOYc3rTxnU+Peej5Pjf/SNTJ+wQcB03RAGsShjmPBF/tWa2/sOv6W0eihTtptv9mvntn+Yogb58JDvfCy/tcJYd8YYpujN/bxW+8e3mlfu8H+QWeb9J8n35fVPDMiZy3rrg+f9+6hUKmd6KY7i6TURRGjQNwMd1O1gYLiWM1JUTM9aul0+Zlmu2/mfM+XPnpfv6yRz9TxKmay/2JhrxXPSxcplTVLnLUSRtLRk6Z9vJ3/IfMN/mc7W9Ts9Et4KLO30Xt/PQJG7X5nf1HPOw9cmrqU+6uvWo0ikFrQRmMSMBp8/l+0/vEqWW7R06/feXQCd1PpzPPzbBV/qHy0pM9XLOErin3xe1MeUqqR1Eb/Vd3j8N7fWukVauuy/vJ+gk3X7Vs2Lf/DMjkkSgbANi6/AeYtWNu6bZ14t2Tk/Xkn3U/WJ0wwA4dmDoNeOYY51VsOFHbi/39YUbPFTM9T+FdkgLA06DHY0BW1w5ljp1YfLkMy3cMzb9xXf5/vnJm0s8uW35k1NblL2BptpsacDkXt7PPWg1cJWqbsq11zS/0UeDjAQys3ZE97ZcrcycNenHcOIepPSYwZjZ5tGTzt5nN+hUzZiS9P2XuhGQ18K9eNschF8v8w2K1RDFDabc3flr6PZtjpwLPFLywuFibeGDVZ4P2rVxQk8QPFzy2XxgO28eshQdOxyFy6tRAOhh8O83XtPNgTuGCsoH5Q1ddMzW9NHcOv3fQILR4ABiyaaX/2o82VFz9+ciHVSfR2+J0zEjxeH4jh6Ib8Gi8jy0mPZUew9Zfp1j3T127u+LTAfnFe68Y+9K2/qOf23Zt3m92DJ/8531DpyzePXTKmkl7Du/rhjmqXTS1inJzParI2IPHiGDOhpP7Xr1tZev/uWKO5ztzOxV2OvBaxoWhaMeUHau/uP7jTX9p9ronNngc0+Le5FeoVG+NjlEQ8Pn6Bg4ffaKrBu/3MfT1XZujzxtE+v3lY6eNWzUu/5rysTMurxi2o2edL6owBLmNpYyFkqTfgtYUgynNyHPI+v18TConfYGR4GuaxQajd3K+0E/Z6qYnjRP1jygR4TaSYcajjYZASNWKqrR49qGwkDtu+ZLF04rfOFpUUaG2yHqxjp0WvNMnJHd7SW32gbKSnSTz4BGnfbyPt02zZfRcZPN462NRmW6sqb8qVFc7V2poWmgPxssyRWqfR1B2Z9L23V6O2c5Q1BZDIdfyFuJNnMSet1gsTzko5z24jOcqKgaCjkEQbQvhFhtwzqQGNiPztfpk2y2HHNzwgy4oHFPy+tNT3ntr963r3wybFxV0knRJgNcyV/NRwPimD1Z+Pnnv2pLBu1f87CiDXVPvtuRoPdKewLqmbeXSvU0GRcqCEMea46LjWKPP1aDImV8GG6+slmLZ9bKSXyWJuTWyOrYyEhjbzJBdjW7pPi2r61o5K/OBOqcl+wseu3qP7rl7xvvvLZ1b8vre+UuXXvAHi1rGm+h4SYF3+mBMDSjcs65+4p7V71+/e/XvtwOVd4CVB1fyRHaTxzW+1uOYFLosfeaJZMusQM+UG5rSXDdUueiZgUz3lFoXm1+Tas/7wkUOP2DDhm1kmqaP3Vvy3MSP1m+fta+0zvReT++rs55fsuB9c0If3lEcv2vzupM3bVq9Z3rpsvLZZcvXFa56e+Xc8pUrbly3fPmN5cuX37x51cqZG99dM3NT8YaCsnc2zt24fNfdG4srO8P965vjacvv7w14bRns963Nj+Bdwoj+CN6P4F3CM3AJi/5/AAAA//+uJ+hmAAAABklEQVQDAJZAMak3hEQoAAAAAElFTkSuQmCC') + '" style="max-height:65px; max-width:100%; object-fit:contain; display:block; margin:0 auto 3px auto;" />\r\n              <div style="font-size:8.5px;color:#444;text-align:center;line-height:1.4;font-weight:bold;">' + (doc.type === 'PD' ? 'PT. BARA INDAH SINERGI' : 'PT. BHUMI KARYA UTAMA') + '</div>
              <div style="font-size:9px; color:#000; margin-top:4px; line-height:1.3; font-family:Arial, sans-serif;">
                Jl. Pluit Permai No. 12B  RT 01 RW 07 Pluit, Kec. Penjaringan - Jakarta Utara 14450
              </div>
              <div style="font-size:9px; color:#000; margin-top:2px; line-height:1.3; font-family:Arial, sans-serif;">
                Tlp : 021-26063593 / Fax : 021-26063591
              </div>
            </td>
            <td style="width:35%; text-align:center; border:1.5px solid #111; padding:6px; vertical-align:middle;">
              <div style="font-size:14px; font-weight:bold; color:#000; line-height:1.2; font-family:Arial, sans-serif;">PR</div>
              <div style="font-size:14px; font-weight:bold; color:#000; margin-top:4px; line-height:1.2; font-family:Arial, sans-serif;">PURCHASE REQUEST</div>
            </td>
          </tr>
        </table>
        
        <!-- Info Metadata Table -->
        <table style="width:100%; border-collapse:collapse; border:1px solid #111; margin-bottom:12px;">
          <tr>
            <td style="width:35%; border:1px solid #111; padding:0; vertical-align:top;">
              <table style="width:100%; border-collapse:collapse;">
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:75px; border-right:1px solid #ddd; padding:4px 6px; border-bottom:1px solid #111;">PR No.</td><td style="border-bottom:1px solid #111; padding:4px; font-weight:bold;">${doc.docNumber}</td></tr>
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:75px; border-right:1px solid #ddd; padding:4px 6px; border-bottom:1px solid #111;">PR Date</td><td style="border-bottom:1px solid #111; padding:4px;">${formatDate(doc.date)}</td></tr>
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:75px; border-right:1px solid #ddd; padding:4px 6px;">Department</td><td style="padding:4px;">${doc.dept}</td></tr>
              </table>
            </td>
            <td style="width:18%; text-align:center; border:1px solid #111; padding:0; vertical-align:top;">
              <div style="background:#f5f5f5; border-bottom:1px solid #111; padding:4px; font-weight:bold;">Priority</div>
              <div style="padding:12px 4px; font-size:11px; font-weight:bold; color:#c8102e;">${doc.priority || 'P2'}</div>
            </td>
            <td style="width:22%; border:1px solid #111; padding:0; vertical-align:top;">
              <div style="background:#f5f5f5; border-bottom:1px solid #111; padding:4px; font-weight:bold; text-align:center;">Inventory Type</div>
              <div style="padding:8px 10px; line-height:1.5;">
                <div><span style="display:inline-block; width:10px; height:10px; border:1px solid #111; margin-right:4px; text-align:center; line-height:9px; font-size:8px; font-weight:bold;">${isStock}</span> STOCK</div>
                <div style="margin-top:3px;"><span style="display:inline-block; width:10px; height:10px; border:1px solid #111; margin-right:4px; text-align:center; line-height:9px; font-size:8px; font-weight:bold;">${isNonStock}</span> NON STOCK</div>
              </div>
            </td>
            <td style="width:25%; text-align:center; border:1px solid #111; padding:0; vertical-align:top;">
              <div style="background:#f5f5f5; border-bottom:1px solid #111; padding:4px; font-weight:bold;">Purchase Category</div>
              <div style="padding:12px 4px; font-weight:bold;">${doc.purchaseCategory || 'Office Equipment'}</div>
            </td>
          </tr>
        </table>
        
        <!-- Items Table -->
        <table style="width:100%; border-collapse:collapse; border:1px solid #111; margin-bottom:12px; font-size:9px;">
          <thead>
            <tr>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">No.</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">COA</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">Part Number</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">Description</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">Cost Element</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">Quantity</th>
              <th style="background:#f5f5f5; color:#111; padding:5px; font-weight:bold; text-align:center; border:1px solid #111; text-transform:uppercase;">UoM</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRowsHTML}
          </tbody>
        </table>
        
        <!-- User For Box -->
        <div style="border:1px solid #111; padding:8px; margin-bottom:12px; background-color:#FFFF00;">
          <strong>User For:</strong><br>
          <div style="margin-top:4px; color:#333;">${doc.userFor || '-'}</div>
        </div>

        
        <div style="font-size:7.5px; color:#666; margin-bottom:12px; font-style:italic;">* Untuk menghindari kesalahan, harap menggunakan bahasa umum yang mudah dimengerti dan menyertakan spesifikasi yang lengkap disertai gambar atau contoh barang</div>
        
        <!-- Signatures Grid -->
        <table style="width:100%; border-collapse:collapse; text-align:center; font-size:9px; margin-top:15px;">
          <thead>
            <tr style="background:#f5f5f5; font-weight:bold;">
              <th style="width:25%; border:1px solid #111; padding:4px;">DIBUAT OLEH</th>
              <th style="width:25%; border:1px solid #111; padding:4px;">DIVERIFIKASI OLEH</th>
              <th style="width:25%; border:1px solid #111; padding:4px;">DIVERIFIKASI OLEH</th>
              <th style="width:25%; border:1px solid #111; padding:4px;">DISETUJUI OLEH</th>
            </tr>
            <tr style="background:#f9f9f9; font-size:8px;">
              <th style="border:1px solid #111; padding:4px;">USER</th>
              <th style="border:1px solid #111; padding:4px;">SUPERVISOR</th>
              <th style="border:1px solid #111; padding:4px;">FINANCE</th>
              <th style="border:1px solid #111; padding:4px;">PROJECT MANAGER</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="height:52px; vertical-align:middle; border:1px solid #111; padding:4px;">${sigUser.content}</td>
              <td style="height:52px; vertical-align:middle; border:1px solid #111; padding:4px;">${sigHead.content}</td>
              <td style="height:52px; vertical-align:middle; border:1px solid #111; padding:4px;">${sigFin.content}</td>
              <td style="height:52px; vertical-align:middle; border:1px solid #111; padding:4px;">${sigPm.content}</td>
            </tr>
            <tr style="font-weight:bold; font-size:8.5px;">
              <td style="border:1px solid #111; padding:4px;">${sigUser.name}</td>
              <td style="border:1px solid #111; padding:4px;">${sigHead.name}</td>
              <td style="border:1px solid #111; padding:4px;">${sigFin.name}</td>
              <td style="border:1px solid #111; padding:4px;">${sigPm.name}</td>
            </tr>
            <tr>
              <td style="border:1px solid #111; padding:4px;"><span class="status-pill ${sigUser.statusClass}">${sigUser.statusText}</span></td>
              <td style="border:1px solid #111; padding:4px;"><span class="status-pill ${sigHead.statusClass}">${sigHead.statusText}</span></td>
              <td style="border:1px solid #111; padding:4px;"><span class="status-pill ${sigFin.statusClass}">${sigFin.statusText}</span></td>
              <td style="border:1px solid #111; padding:4px;"><span class="status-pill ${sigPm.statusClass}">${sigPm.statusText}</span></td>
            </tr>
            <tr style="font-size:7.5px; color:#555;">
              <td style="border:1px solid #111; padding:4px;">${sigUser.date || '-'}</td>
              <td style="border:1px solid #111; padding:4px;">${sigHead.date || '-'}</td>
              <td style="border:1px solid #111; padding:4px;">${sigFin.date || '-'}</td>
              <td style="border:1px solid #111; padding:4px;">${sigPm.date || '-'}</td>
            </tr>
          </tbody>
        </table>
        
        ${doc.attachment ? `
          <div class="page-break-preview" style="border:1px solid #111; padding:8px; margin-top:20px;">
            <div style="font-weight:bold; font-size:10px; border-bottom:1px solid #111; padding-bottom:3px; margin-bottom:5px; text-transform:uppercase;">Lampiran / Attachments:</div>
            ${doc.attachment.indexOf('data:application/pdf') === 0 || doc.attachment.toLowerCase().indexOf('.pdf') !== -1 || (doc.attachmentName && doc.attachmentName.toLowerCase().indexOf('.pdf') !== -1) ? 
              (doc.attachment.indexOf('data:application/pdf') === 0 ? 
                `<div class="pdf-rendering-container" data-pdf="${doc.attachment}" style="text-align:center; padding:10px;">Mengurai halaman PDF...</div>` :
                `<div style="padding:10px;"><a href="${doc.attachment}" target="_blank" style="color:#1565c0; text-decoration:underline; font-weight:bold;"><i class="fas fa-external-link-alt"></i> Buka Lampiran PDF (${doc.attachmentName || 'File'})</a></div>`
              ) :
              (doc.attachment.indexOf('data:image') === 0 || doc.attachment.match(/\.(jpeg|jpg|gif|png|webp|svg)/i) || (doc.attachmentName && doc.attachmentName.match(/\.(jpeg|jpg|gif|png|webp|svg)/i)) ? 
                `<div style="text-align:center; padding:10px;"><img src="${doc.attachment}" style="width:100%; max-width:100%; height:auto; object-fit:contain;" /></div>` : 
                `<div style="padding:10px;"><a href="${doc.attachment}" target="_blank" download="${doc.attachmentName || 'lampiran'}" style="color:#1565c0; text-decoration:underline; font-weight:bold;">Unduh Lampiran (${doc.attachmentName || 'File'})</a></div>`
              )
            }
          </div>
        ` : ''}
      </div>
    `;
  } else {
    // ==========================================
    // PERMOHONAN DANA (PD) PDF TEMPLATE
    // ==========================================
    let itemsRowsHTML = '';
    doc.items.forEach(function(item, idx) {
      itemsRowsHTML += '<tr>' +
        '<td style="border:1px solid #111; padding:4px; text-align:center;">' + (idx + 1) + '</td>' +
        '<td style="border:1px solid #111; padding:4px; text-align:center; font-weight:bold;">' + (item.PC || item.COA || item.coa || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:4px; text-align:center;">' + (item.DR || item.CostElement || item.costElement || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:4px;">' + (item.desc || item.Description || '-') + '</td>' +
        '<td style="border:1px solid #111; padding:4px; text-align:center;">' + (item.qty || item.Quantity || 1) + '</td>' +
        '<td style="border:1px solid #111; padding:4px; text-align:right;">' + formatCurrency(item.price || item.Price || 0).substring(3) + '</td>' +
        '<td style="border:1px solid #111; padding:4px; text-align:right; font-weight:bold;">' + formatCurrency(item.amount || item.Total || 0).substring(3) + '</td>' +
        '<td style="border:1px solid #111; padding:4px;">' + (item.info || doc.userFor || '-') + '</td>' +
        '</tr>';
    });
    
    // Simulate budget check for specific department
    const deptBudget = DB.budgets.find(b => b.Dept === doc.dept);
    const brPC = deptBudget ? (deptBudget.Project || 'BHL.22.105.001') : 'BHL.22.105.001';
    const brDR = deptBudget ? (deptBudget.Dept || 'TOB3,CE0831,LM001,LA01') : 'TOB3,CE0831,LM001,LA01';
    const annualLimit = deptBudget ? (parseFloat(deptBudget.Annual) || 10000000) : 10000000;
    const actualSpent = deptBudget ? (parseFloat(deptBudget.Actual) || 1650000) : 1650000;
    const budgetAvail = annualLimit - actualSpent;
    const budgetVariant = budgetAvail - doc.nominal;
    const brVariantColor = budgetVariant >= 0 ? '#2e7d32' : '#c62828';
    
    const sigPrepared = getSigBoxData(sigs.user, 'user');
    const sigVerified = getSigBoxData(sigs.deptHeadPm, 'headDept');
    const sigApprovedPm = getSigBoxData(sigs.projectManager, 'projectManager');
    const sigCheckedFin = getSigBoxData(sigs.financeSite, 'finance');
    const sigCheckedCc = getSigBoxData(sigs.costControl, 'costControl');
    
    if (sigPrepared.name === '-') sigPrepared.name = doc.requester || (session ? session.name : 'Mona Asrani');
    if (sigVerified.name === '-') sigVerified.name = getSignerName('Head Department', doc.dept || 'HRGA', 'Rosalia Natalia');
    if (sigApprovedPm.name === '-') sigApprovedPm.name = getSignerName('Project Manager', 'Operation', 'Yohanes Sam');
    if (sigCheckedFin.name === '-') sigCheckedFin.name = getSignerName('Finance', 'Finance', 'Putri Amalia/Fakihun');
    if (sigCheckedCc.name === '-') sigCheckedCc.name = getSignerName('Cost Control', 'Finance', 'Janrizal/Dwi Wibowo');
    
    const sigCheckedAcc = getSigBoxData(sigs.accountingHO || {}, 'accountingHO');
    if (sigCheckedAcc.name === '-') sigCheckedAcc.name = getSignerName('Accounting HO', 'Finance', 'Arista/Sinta Agnes');

    
    const sigDisbPm = getSigBoxData(sigs.gmDept || {}, 'gmDept');
    if (sigDisbPm.name === '-') sigDisbPm.name = getSignerName('GM/CFO', 'Management', 'Sjamsi Josal');
    
    const sigDisbCfo = getSigBoxData(sigs.gmCfo, 'gmCfo');
    if (sigDisbCfo.name === '-') sigDisbCfo.name = getSignerName('COO', 'Management', 'Fransiscus Vici S.');
    
    return `
      <style>
        @media print {
          @page { size: A4 landscape; margin: 0; }
          body { margin: 0; padding: 8mm; }
        }
        .page-break-preview {
          page-break-before: always;
        }
        @media screen {
          .page-break-preview {
            border-top: 2px dashed #cbd5e1;
            margin-top: 30px !important;
            padding-top: 15px !important;
            position: relative;
            page-break-before: auto;
          }
          .page-break-preview::before {
            content: "HALAMAN BARU / NEW PAGE (LAMPIRAN)";
            position: absolute;
            top: -10px;
            left: 20px;
            background: #fff;
            padding: 0 8px;
            font-size: 8px;
            color: #64748b;
            font-weight: bold;
            letter-spacing: 0.5px;
          }
        }
      </style>
      <div style="font-family:Arial,sans-serif; background:#fff; color:#111; padding:10px; font-size:9px; border:1.5px solid #111; box-sizing:border-box; max-width:1080px; margin:0 auto;">
        <!-- Header -->
        <table style="width:100%; border-collapse:collapse; border:1.5px solid #111; margin-bottom:8px;">
          <tr>
                                    <td style="width:25%; text-align:center; border:1px solid #111; padding:0; vertical-align:middle;">
              <div style="padding:5px 5px 3px 5px; display:flex; justify-content:center; align-items:center; box-sizing:border-box; width:100%;">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVwAAADPCAYAAAC5k2l1AAAQAElEQVR4AexdB5xVxfWeuf317UsRBbG3qNhQUBTpXcVeY42JJmqMXTHGFPOPKSb2kthlpbPAUgTFrtjR2ADpy9bX3+3/71zYdXdZ2MVQdvG+35t37505c+bMd2a+OXfu27cC818+Aj4CPgI+AjsFAZ9wdwrMfiM+Aj4CPgKM+YTrjwIfAR8BH4HWENgBeT7h7gBQfZU+Aj4CPgKtIeATbmuo+Hk+Aj4CPgI7AAGfcHcAqL5KHwEfgZ2NQOdozyfczuEn30ofAR+B3QABn3B3Ayf6XfAR8BHoHAj4hNs5/ORb6SOwOyHwo+2LT7g/Wtf7HfcR8BHY2Qj4hLuzEffb8xHwEfjRIuAT7o/W9X7HfQTah4Avtf0Q8Al3+2Hpa/IR8BHwEdgqAj7hbhUev9BH4MeHwCNXXCH/+Hq9c3rsE+7OwdlvxUdg5yDwA1txGeOzxl9T/PqFvzm5Syow9h+XXFPM/Nd2R8An3O0Oqa/QR6BzIbBwwARpzumXHbpXNPyAytlprmO+fc1TD1R3rl50Dmt9wu0cfvKt9BHY7gjQ1sHMCy49ROq+/sFSTXu6zkzP/8JZd/PYFx9cxRlzt3uDvkL/5xn9MeAjsOsQ2HUtTxl7cd4B9cYFxZb0UlQN2YZoX7hUy/3nwmeeSbfHqonjx4tE2O2R9WW+R8CPcL/Hwj/zEdjtEZgwYYKweOT5P+nFpReKpMgtuuX8uTaZvfG4px/65MpHHzXbAqDi178OTbnwqmPkYMEAls12hTyCYXz673Yh4BNuu2DyhXwEOj8CTw++IHTq65+fEdOdmY7D69fF00P6lz32n5PLHky11buJV18dXvTT609W6p3nCguKRnIh9NW63r1Xo56/9QAQ2vv2Cbe9SPlyP3YEOnX/J512WteeTuKegGk8ZgXEl1ZEc788tfzJZQhPt0qYtHUw/fSLDt4/o/yzQJH/Ly6aT3ydMP489qn7VyFadjo1KLvAeJ9wdwHofpM+AjsTgedHnVOUV6P/Q87q17Fo6K5vMrl7TnvmmQ1t2QBCFbqw6NC9JW2+kUuH1sUrzxv7yAMzLn3yvmRbdf3y1hHwCbd1XPxcH4HdAoHnR59TukfOeijiyGckbeGGbzXjgTPnl8Xb6tzE8ZcWDP1w1e35SWtmOpWe8jVP/WzIC//+b1v1/PKtI+AT7tbx8Us7KQK+2Yw9MXT8/sW1qcfldO6MnCDdU98j9NCZZWV2W9hMHH9FrJfJblOy+h0ZZt9dFXNuO/eFF/zv5bYFXDvKfcJtB0i+iI9AZ0OgYvAFvQ6oz/xLqKwZ6YjiA+tl/pczy8qybfVj8Yhz83tvSP5e1M0r4xq77ruI/vuRzz9f11Y9v7x9CPiE2z6cfCkfgU6DwNPHDy4JrFt7fzBtDIx17b5wDZPvac82wqxh50UD1cbvpHTm6hQ3H/nUrHkMJG10mo53AkN9wu0ETtrtTfQ7uN0QmHfCyD376PL9EdMdmwsGvlkRk64+c3FZVVsNENkWVWdukCzj6niATf1aSv/l2tmz9bbq+eXbhoBPuNuGly/tI9BhEXjk1FNjJbZzR2bt+vOEQIDlwsFbzpjxQrsedBXVGadFsvadPBr8NlMcufrS6dPXdtiOdmLDfMLtxM7zTfcRaECAvsJ1eEo7J1tTe1lSYSwR0h6rytjlDeVbOy46aVzf/LT5fzZz2Vdm+ldDJz+7bmvyftkPR8An3B+O3Y+0pt/tjojAiDmfnVhQq//O0V0W6dH9v1Wa9Ncz32r7Idm8U8cd2F13H6pZtbJQKSx40e2qLeqI/dtdbPIJd3fxpN+PHy0CC04Z2V2tqr8/U5UsDCgRt8bi15w2/6Uv2gLkkVGjgloy8YsNa1f+pHDPbslqx/wrHpK1+We+ben1y7eMgE+4W8bGL/ER6PAILBwwQApVJi+V0pkjJFVhQkHBy+u0+OvtMbxnIn1SOGteLDDO6gNS2eou5kftqefL/HAEhB9e1a/ZCRDwTdzNEUhljKPzVelnupFhUmFUX624T16yaFGurW5XnDimR9eE9CdnfSooBSLZusLgA4hujbbqdbRyl2G1YJ3n5RNu5/GVb6mPQDMEJkyYIPTSoudVfru8i8kcllDcGSsk1mZ0Sz9IE8uaV6dXVR8qSSrTFfHJ+pD5aTPlneTiufPO6/7UxRdrncRc/wfIO4ujfDt9BFoicMK814+3V9VeHBWDLFBQyGol/vTPF5WlWsq1vA6tSR8aMvmlWjDAhPxwxsmLPI3ots0/+W2ppyNcK4Zb2k2S6Hd5O4I5bdrgR7htQrTzBPyWfATai8ALA4b2jGXFv7GkETINl+VCyrtxJ/daW/Uf6XOFXOzKZ9WtWlOcSiWZHtberVb4t23V66jlecGApubsAR3VvpZ2+YTbEhH/2keggyNAWwl7OuHT3bW1fXJJnbFomFXL/Mkzl8xv81fA8sUVe4TS1qiQy1k4FmW1Ip992oIpNR28y1s0T+ZiTVSUCzrLXq5PuFt0pV/gI9AxEej12vtdtbr0WarusEgowoRYpGaN4rzRHmu7BSJjeTpzsJXJMCUcZHpU+6w99TqqjG1YhmvoYke1r6VdPuG2RKS9176cj8AuQiDPEA6NiNKRTlZnpmkzU1VnJNxYm9sCTw8eHJITuUuTdfVMDmjMDajf1XDjy13Uje3SrG2abigSim4XZTtBiU+4OwFkvwkfge2JQMS0R9WsXC2qssKCeXkgXGXx9e34q7KiWvFwNaPvzyyLMYGzuGW+rvcoWck68csRRTcRT2p3T5jAO0M3hM5gpG+jj4CPwEYEnjvilL0KbH5aUBBZxtCZGIukktxuM0qlP5AoSNljWSojyaLAXNdlNhPntOc/9W5suWN+csmSJC2gdkzrNrfqR0K4m3fcz/ER6GwITGAThL3VyM/s9TVdzEyOaXkRFhftL9ek0t+02Zd0sKhIVgZn4xufq8nREGMh6YM263VwgYCgRiRJidw1YYLbwU31zPMJ14PB//AR6PgIHHPsOwfkZY0L3dok45bJEmaO1YaEOZd/tqCyLesDitjTzWYPDCoa0x2LHrStiItOm/9Isi29u7qcZ53eRtrqFGRLWPmESyj4yUeggyMwYcIEoZTLZxqVtV0V12b5+fmMBRRW5eQmt2U6/WWZmLVG1q6vlG3DZI4oMV4YXbxkQJ/atup25PKFAyZIMSF0sqQobf67947Sj45IuB0FG98OH4EOg0CfGUu0qOkexDJppkgCq6zZwIIFsbilCW1Gqcm1ejAiqYdEAyFm44GZGgmzVU7mY5C402E6+AMMSURXBjSHnWDmjDU/oPouqeIT7i6B3W/UR2DbEFA1nicb9iEM2wE5bCfklRQxW+IrTaa2+ae8EdkK5Qy9d9rIsaKiIkbHHOOrt82Cjicd0Y297XSu1BLYspbWYTERJl5yzUH3X3ddoGXZrrz2CXdXou+37SPQTgS4w0pty9ibawrjQYVVJuLMkeSljNXn2lKRsvQgjwVKdZmz9dVVLD+vkMlcbrNeW3p3ZTltk4RtcZTIuZKzzc0Wj4M2bAj2CoSG9NZZ911pZ8u2/2fCbanQv/YR8BHY/ghIDts/l8x6X39K6zkWyY8wQ7CXX9KOn2LUQsFAPJWMOJwxLRBkhmEwVxQ6NeGGq5Susm5fnDb1t+tNu7ol4t1yYR7MmAE5m1Falu3Ka59wdyX6fts+Au1AwGWMF8iBEx3dwh4sZ4qoMu46zBLd5awdL8Ow8gIW0+ScxcC5TA1ozLCxv9COuh1VJGhnhsXjlb03SPZz46b+u741OwPMyRNlLdJa2a7KE3ZVw367PgI+Au1DgP6KSrad3o7jMMFxmegyJoE6BSa261sGBYJ0gJs1mIwQ17VshoPNVKnT/dh4A1ovDh53SNR2byotLV6RKRTmN+Q3PZrJlCtJXBZFYRdGuE0t2ngubDz4nz4CPgIdFYE+S5ZotmPs4bgmCNdm2F5gkisz7shGe2zO52pXvT7JBEFgnHPmMma6TLHaU7ejyTw14GJtj6RwpZazeycyqQmnPfPMFr+lodumJJsAqgN1QuhAtvim+Aj8qBEAEfL7x48vaAlCbUYKmMwscbgJwrWY6DDGEeMySWLteYn1mT0KQmHm2DaqSBThKvW5uNqeuh1Npoeo94847Bc5iX+k7R17eUv2yZEctywzX+SsQ/VT2JLBfr6PgI/AzkXgmQsuCB4aio6dMf7CZk/WBYkrJrdV07VBtA4TEKU6IFybtX237DLGNcON6IkUdhFk5tCWgsOEkBwOsk72mjPk/H3C8dzf05bBKgvk+37yzDPpLXVB0kPctKygw+32ctyWVG3X/A5lzHbtma/MR6CTIdBj1So9YrrRbkrgZPoeaYP5Fs+o3LFlEQ/KaDtBcBlzBJFZEp01SG35GAsGBEWSmakbzDZNJoK2JVVoX3i8ZbU7tWTWKWf1LqzN/aW+supAO6zNyJaE5m7NgFRmtSwrUqFp+4S7NZz8Mh+BHy0CJy9aZBm2/XVEVsf+5KMV0QYgQiYPBixHxb4C02zRI0xHYExvEGjjWJdJug6zWX5elIkuZzlEu7LVeQh32uifRkoT6V+J9fWjtbxQqkZ0/3ja00/XbK3bnPNwuq5uD+Bpb01uZ5fBbTu7Sb89HwEfgS0hYHD5/VRaDxcL0hAEspzkNMfhkiNwEVTrIjp1mcBs7jAmWlTcZuKxkKUzh9XX17OArLCorDHXNNrej2hT844XmDb67G75a9fdZ6/Z8AtZEgyhJP+Ssa+8/GZbLYu6sKeV0/Nd2861Jbszy4Wd2Zjflo+Aj8DWERj4wuMbkqbzZMSVHvpgxEVHknRMkg1JVl1TllkCRJsREK86OrOxRUDlW0ucMbdWdSudgMwkCbsIBrYU6PcUdLtka/U6QtnkU8cdWPJd9V/zqpJXxdQA49Hg705c8OIWH5Q1tVkzrGNUjj3rlL6uaf6uPvcJd1d7wG/fR6AJAkSQlTKvYFz6JCjID7x5yvjuQobpqVQmm7VtJseizJYExLk2i8lcaFJ1i6fVdnaVBUlJkRl3XFZfWc26xwr22WKFDlAwfcC4fqWVyWcDNekz0/F6ZhZFZnwXkB9rr2lBm/WTmbDWtuXN/uy3vTp2hBzcsCPU+jp9BHwEfigCZ5Y9Gl9nZS+TtMB+YUG+s0c4ryishVx6UJbK6Yz+AMJIJJhqGoXtaUOIRr4UAwGWzmSYIEssDOI1q2qOnDVsmNqe+v+zzDYomHjC+D0X9Bn16+Jl1bMDGxJHcstheQf2nrN2r+gNIxaVrW+PqtdPGB0pEEN93Zy55MMj90y3p87OkhF2VkN+Oz4CPgLtR2Do9Ce+WZms/xmX5EuMpPmimUiHwpLKBNNmYVllYdwuqwY7mn7EpS2tlmlXKqpmc0lkhmUyU9dZSTCyj+CEQ23V3VnlTw++IDTl0MHD9jf5c8Vx489uMhuWIxGmdy34z6eWecngSc9/3V5b3ExqSIZ6xAAAEABJREFUZLy2rlQMhF6bMGECNrvbW3PHy/mEu+Mx9lvwEfhBCCzledPjonBrTXXtvkZVgrHqBCtgAnNq4wz0ySTdOoJVsUCbyk0rbZtWQlUDTA4ozOWM1a9d15Vnc7E26+5gARCiMO+E047br7L+qZ6GMLP6y6/6ra+pZLmiiL2qOHzXipLw9We+N6tdkS2ZunDA2DxVVq+NlBStrjGNxZTXkZJPuB3JG74tPgJNELh29gP60vXy34VuRbdLkSCLICB1XIspioQo1WKSKx7IhGybpBlm4XQ0EK0x8bAsoWeYqIjMSmeEoKi08uCsiQE78BSRufLyiSP3HVL+/n2xtdUV8rr147Pr1wrBqMaU7kVVes+i8cPfmvbbMyvK2vV7EWSqyxi3TXNMbVXVceuz8WfXFTjfsg728gm3gznEN+fHiwARxrPnndf4/VtC4solj5rvM+vvzl5F02plk2Ww65pTOEs5DquPp2MK0/Yiua2mTCZppjPfuQJnXJW9CFdP0B4w77fVetu5kKLZWf3HFy/uO3zkfiuzj+9bm5sXWlt1A6uuinIjy8SgwNzS6Nx4afCsYfPKpmxr80+dOGaPsCNcnZeXx9a7+uQzy8o61HdwqT8CffjJR8BHYNcj8MCwYUpvN3rMrBak+/NFZal1Vvof4S4lzHBdRsSphDREuWkWqkv3acvy0W9MT9ma9JUrcma6DnO4wxRBYprjDv7HsGtA4WyHvujh3NR+Y44dOPe93/bUs5MLqlIz9K+WX+Cu3bCXlUgyRgtBaUE6t0fxn1aHpYvGLJi+8IcYVML4YCuZO8ZWlBfWReWlP0THjq7jE+6ORtjX7yPQTgRqjz3WtI3a0mI1eAxFu02r5Uztv6IU/VIwJaa4EkhTZ6KZYl3M7G1LDh/084XHje25cMAAqWmdhnPOmFvNc59zTWGSJDFmM+jgTMoZh5aYG/ZukNteR7Jj4YBzit4ZcPpR7x8/8p7iDebbPePxxcrKNbelvlnWL1NVyQKyyLK2zoRYhKn79V7wTVFk2Envzbv5zEXt369tau/CAacfsEfCvickBM20FLj/yhkzMk3LO8q5T7gdxRO+HT96BHDL7cianGbJ7PhF468ONQMkWJTMytIyORBiWfp6l2WzAJgzt3pNaTie+mfBmg0zuqZjf5l/7Njznz1x+KHPHjss2rR+WNMWq6pcR3ner405LpOS2dJertSb8v6XNIFNECYPHldSfvKYY98ZMP7SUj12X9cN1VOK19a9Jn+z5nZx+brDzW/XyFrKZFbGYExRWQ4RevjQ/T9O9Opy/cf50rnj3yj/wQ+4Hunfp2uoLv5npy7Z1ZTFx94cdOgH/0t/dmRdn3B3JLq+bh+BbUSgPmktKWbh/aKp+jFNo9z1OSmXCimf1TsOC4XzmJizWMASmSoorL6qjtmp7CGpZWuvLVwbf+bwaqnioLQ8cclRYx95/Zjh9y8+cuDQkqyjRYOhDVZOZzJFuSa016WEHknzFIpI2VZekOQTx48X3+9zhVwxeHBo/rGjSxcePf7wxX3GXfvJUWMePv3I9/99YK05q2dt7hXx65WPmyvWXmdV1vSrXbUu4GRsptoqi0gx5loq697rwKTWY59HKvMLz38vyEeduHjaXy+cO2WLv2m7FbO8ohkDRhUdpBfclatOjnSioZVml/yHJkzoWF8F8wzd9OET7iYg/IOPwI5GoD36B097cfW6ZPo/ao4//t7g8/s21KGHZ9V6akG4tBgBcJZFgmHmgnTNnM1CoQgL4zoqa8yprmfminVdpVVVQ5wvVl4RXVZ9XWmNPju7tuqNusrK/VVVZbphMEEQmAPy1ddUXthbL7myot+YUbPHXDB8+oCzRlYMPPe8Wf1P/9k7/cff+M1Pxt6+6uBh9x/xefzpsP713B6rrQ+71Ka+Kq2s+bBwTdXfna+XX2l/u+KC9NfL+2S+Wx206+sZz5mIwnUWyitgVjDAGGy2unf7ih+w321fBaRjD/1g8lWjPpj93E/nTlvV0L8fcpw4YHw4siFzS6DauFIKhVgypN4z7+gen/8QXTurjrCzGvLb8RHwEWgbAc6Y+0VEKhdjsc/yFeXPFWPO7tFQyxT4l1osst6WZZZFpCuCzCRFZcUlXd+RgoErLVn4a+Fe3d8q2qM0yZjDgorMDGw/6PEUc5NZUTIdlsnlmCOLzES5hQdoOT1dWPfdin8Wrq2dHvzg6/KCb9bOiH6+8tnu32x4MPD5ivv0b5fdk/7uu1/pq747N7t2zYBk9bp9M4kNUSNVzdxMnKmmzWTYosGWnGszrSCfOeEgy++5R51TVFBu7NXtT2v2KjzznT3YyT95/8XfD/pgyhcN/flfjpP6D+m657qqe7ol2fWyLjA7P/KPKi4+15GjW+qvQB9+8hHwEeg4CPy07KmqtVb2yqp0oreas35BT/nJOlOTq1O2+bYpMpY1TJZJ55jAJZbMpAOurMw5cNWrN6wMmad/pCaHJLqHr9K75C1yuua7Tl6YmVxkmUyOBUJBZtoWk1Q8PBNcEHCSpas2MGVDPStKGCyWNZkcTzIFJC0ncx6Ziq7LJJCqaFnMsg2m2zozHJ1lsYdsF0RYjSqzDbLAQgftu7a2KPJEXdfCcSuKwgO+ifJzTnhvys2D5z1fdum86WupD9sjPXbswNK9UtZvtXjqV/F4nGldil9J5yl3n/lWWXZ76N+ROnzC3ZHo+ro7LwK72PKBM5/6IFsQeSDEpV+KcXccmXPmorJUmmUeLuxayiRJYbFwjJmGwTKWcVglz/XjjLknLqlYN+rTV9/q9/mCRz4u1Yet6FF04uqYdn1k755Tu/fce10oEGbRcITlTINlzRwTEO3mF+QxjXNm5rIsaWWYGZaYmR9g9YrDEpLDsiBTQQsyJZzPQgVFLFJaymI99kgG9u31+rqu+Y86xx5xZ3Lf3oM/DUqHnfzhvMtOfnfG1FMXT/pkzBvTEWmT5dsvTTl+WO8Ds9b9rL72sno7xaSDey7/RrNvGroNfyCx/azZdk0+4W47Zn4NH4GdgsA3QuoZ1+XvyFnjsfLho4dSo0Ig+aYruP+1OUdkm2WqJLNkXR1TZOGyGX1GBUmmIV2yaFHuzEVTXh/x8fy/rsyPj18dkU4x8kMXCdHwMvr1sEBI86LdDLYdtECAde/dsza6354brB5Fq409Cpeq+/f6WNmv1wfKPnvPFXr1+LvRvcudNSV5l68pCI1dHpP6L40Ehw16b/aVA8r/fc+YBS/Mu2jBlJqGtrf3cWLf8YGpRww+o1fSelatSZ6bSadZcM9uq5dpzq9GvDHp/e3d3o7S5xPujkLW1+sj8D8icGVZ2cqUa10fFRS7tF5/+s0j+w/p98YbSUFhCzPcZmIkxAw9ywrVABM2xE9WuTlgS03Sf5M4asmM/x70yeynM4Whv6l5EWaaJhOx1cAkiaklhWuSeYFxlRHp+OUh98SvwnzgN8HAoG8EZfCnYe30Z9876vpD3yv/3cA3Kh4fsbhi2tDXKz4+ExH3ltrbnvkvHD24R9dM4p4udanHnfV1xzmGw8Jd9/ymKqKNO33h5Onbs60drcsn3B2NsK9/JyCw+zZxytyyJVlFudyqSxXn6ezhNUcNHmQmkp/m5+ezNKI8SRKYnkyygOGyQlu48OnBg0NtobFesGbxiLqMg2xdy2UOEvaEYynT5ANfmfrtha/NXX7ugumVZy4uqzrt3Sk1RKwT2ASHM+a2pXt7ltN3icsP6Tdy33TuBXnN+hukVCaWs7FIdOuytK4weumIRbM6TWTbgItPuA1I+EcfgQ6KQP+3ppdFS0uvU5m0V6YmPrFnYZcriWDpa2Ccc0Y/aCO74MKa5IhwUuvfVjeGvTl7mS0FHg8GwyykBFlYCrBUdX3YSOo/XThgfLit+ju6nLZGFh4x5NQ9a+oe7JHWnxGrN5zAzSxzNJFJPbvOqe4Su3DgK5Nf29F27Aj9PuHuCFR9nT4C2xmBSlb7cEpVfo/HXHnffrv8J1XrK5mV1ZkLohWxJZBLYk/TZOFuWT5ywhb+xLfBJI5ItV5gL7BopCatGyyXzWJrQWCibo01Epn9G+R2xXH6QScf3Ctr3xGtrHu5OGueZ9fU5tk6OlZS6OZioX9WRuULhla81GH/kqwtzHzCbQshv3x7I+Dr+wEIYA82tyKg/kkvKXyMRyJM1lQWCgY8wg2oQcZBvE4ixQrT1lmnZAsPaquJkz+as2IVt/8oF8UYPUCzHItZ6XS0i8UvRawMTm5Lw/Yrp22QOf3G/WTxQUNv3jctVPDK6puxCsSq6+uZI2tMKe6SWMuFW7PdtZtHLZpRvf1a3vmahJ3fpN+ij4CPwA9BgL5mtaEg9ut4Yejvwe4lLGVmGOciS6UyjAkSMy2D6XW1RVoqc8sTJ4yOtNVGOhqaxMKBD9WgyhLpBBMNkykp/YJXjx29xYdvbenclvKnBgzvMqXP4LFdluf+1WNdYk50zYY/ODU13bOJembYDgt17c54jz3mrQ2Fx77x1aD7hsydm94W/R1R1ifcjugV3yYfgS0gMHz2c4nvotLvMoXqA3ZAZpyJTMMeLNNwHlJYys4wI11/dnfDOoO18Rr97ozlaYm9IKsSK8yPsRxI186kwnJOv+WfAwcWtlH9BxU/NWCANvOowYe83WfILw9YlZjUszb1Upd05qLcqpVdAsxkTHKYSD+2XlCyIaOG7loqsouGflyxkB7a/aAGO1gloYPZ45vTwRDwzel4CJyL2+rP8uxb7H163CB3L63JyIzpEmNZx2QutgbEjM56WOJt835yar+2rI8LVpke1j5KmzqLhkMsA9LVDHPQHll1dFt121P+j2HD1EnHD99r5pFD+i86bPAtP4kH5neryb6hraj+W6QqeTyrrFVYPMPyQhFmCAKz8yP11h7FD68pkE/qt3T2by9YUrGuPe10FhmfcDuLp3w7fQSaIHAhbq+Penv6/SuLgmOlvbu8YiNKlZnEVFtkSspgzqrK3r1y0jPvHzT42tdPOP2opw8bXMJaeQ37aNGKyvzgrUphfjpn6ExWOEuvr2Td0/Y1M04Z372VKlvNmnjQeGX+0QP3XnD0Kce/feyQS/qttx88KOvO36M+syCyIf57Z2X1CU5NNmqmbeZyjUlyhOmOxJSi0rRdUjppfV7kjA/kXtcOWTL3v1ttqJMW+oTbSR3nm+0jQAgMemPK618GzUtYj9KXdFlgLqLEsBpgIp7s59as7xmrS/+9a23ylYOYO2tR32G/nXjUKce8cMKgbgtxa08/uUg64j1ic03T/ktBXiFzDcY0i7Fo2jlCXlcznsq3lHCbL0CH8nyfAUX/PvqEgytOGHZWL2vtEwekeMV+KXde+LsNT4rL1/w0+fk3+0h1KVnNGCxg2Eym3/INB1jSNVkCWyHKgXu/8rlkjPuya+ziwR/OWUC/jLalNjt7vk+4nd2DTe33z3+UCJz5xvyVq2LStVrvXs2Rmy4AABAASURBVJN4NMxqMkmWcXTmSozpmQSrWrYsYldW9xGWV97Rq956+8C4sDS6Vnqn9yeJyZ/8ZOQ9B3yePqtYzu+dqkeEa6os4oaZvq6G7WWJd8w57OQLZ54wpH/F8cNPnHfcyAHz+w4fuqDPiPELjxx228lHvvdYt28yi/axw58dEQ992GNZ5sW8Kuf8+LIN+6z/Zn1QtGQm2QoLB6Islcsyg9tM4A6LRGQmR4SE2iNvZqJX/pg3guYZQ75YMO/MRWUptpu/fMLdzR3sd+/HgcBpc6ds+EYzb7ZL8xYGigsYlyXmWDkmuA6LahpzEikWNV2mbkhxYWVNHltdexhfVzs69cXy24V1Nc/F1284zzEspkgSU0UBEbLBrHXrC3pl7f/0rE4t2Kcm9cq+9ckFpcurZnfdkJiofL3+d6HV8Z86yyv7ml+vLWUrauRQ2mIG9mMFLrGAFmLxdJolLYPVOdBVms/M7gWms1fJp/HS2B+qSqJD1mqhs4a9XT796tfL69iP5OUT7o/E0X43d38Ezlw0/Zs1snOLWBBb6Rgmk23GLCPLGCLLoCIx+hNgblnMBBFGAkGPWEvyYszKpBGJGiwvorGsnWS1qQ0sKLssZFsst3IVk9fXytby9aK+olIIWpyl1m1gMVdgairHSpnCtKzJwkGN1eQSzMqTWUK2WFawWLAon0V775GT9u3x+YbS0J+/KJSHLS1VRh7+ybzb+r0z++1RSzrm/x1jO/Al7EDdvuqtIuAX+ghsfwTGvj3rnQ35gTOK9um1UkBkK4FYs3qOKaLEAqrMwuEgy8uPMcPOsSwi4LpMnAkBgeXsLKuLVzNFk1kwGmSW6DLTMZkqKEwyOctTQ4wbLkvFEywQCDAFBO5gwzebS7JAQZDVyTrLFSKS7lHMlIN6VosH9FxUVRy57jONH/5RN/Ho096Z/5uLF89bcOb8mSs5Yy77kb6EH2m//W77COy2CJz66uT3lknWL9ziwso4qM2WFSYIIhMZotNcikVKCx6MdSv4Y7R74dxQr9K1Vn6QyfkRFsZWhAUuNDhnGZB1LhxihqKxnCCxdYiKGchaikaYG1SYHVaZWBpj4X1KVpp7BhbGuwYeS+9TdO3aiDzsuwL1pLcC8qiBH8z+25nvz/myo/4H3V0xAIRd0ajfpo+Aj8CORWDx6OPL15VGfs723iOeRZSbyJmMgzg1ItJsRlQE+2+m4Jxep+ROrC8I9KvrEju/rkfJLfU9u96Z23+fO3G8vb5bySPZ0gK9RmZMLIiwej3DosV5GTU/fE0uJI7Uo2rfbwVzwIqAOaZm/y6/GLR49gMjXp8+Z+zsss9//iN4APZDPOgTbvtQ86V8BDoVAhMmTHBOWTx10nf5wUFOty7vm6EQc0WF0f83S9dUX5kzjD/qqlB4wpI3vz3l/YVv9PtowXPHvDfzjyd+WHHPcW9Nvuek98vvPenTeVd9W6idre9ZvD4hmkwIcJaz0gFD0DVBlhf1+WT+20M+eW35mDfeSJ5ZVmZ0KoB2kbE+4e4i4P1mfQR2BgJnL5j8XmVx9BJrz67T9ViIeVsCaDgRT1zMctkXXjl5yOkThwwpQFar73Pfmj11RYD/XOpa8rUbUNmK1au5yMXf50Trz7P7Dz1s4vjxYqsV/cxWEfAJt1VY/Ewfgd0HgbPnvvTZt8XKlZUFoRtSeeHKjCAw27QZr071zfum/sm9VzkPvXPS+f0XbuFnHS9/e/7k+mDkNBYruH+/A35ixNcnZKUq+7MeNe7L+y13fvbasPHFuw9aO7YnuyXh7ljIfO0+Ap0PgUtmla0ftmTW/ZkeJcNz3YrmGWqAWVnGAiknKq2tP1Natma6mM6/9YUxl/RorXdD3pzy2QehfW/+3MyOtgsLP7VFidmJzL7myrUPxNYZc6f3HzXm8fHjtxgpt6azPXkUQWN7ZLfhqd2mI+1xni/jI/BjR+DEV1764Oti5QqjS5e7Cnrus8aWVWYZBnMSdXmRysq791+xeuK7/cdePOW4oT1Zixf9ye2wpfMrvtsr7/TMniVX46HZ/JKuJaZVVX14zyybeuBac9q0Y4ZcNXvoOYdN7PvDyNdljM8ado1afsq5ey0efvnIIqfolz0/WdXmj/CwTvLyCbeTOMo300dgeyFwyaI5K9buo937pewMzvUovkvco7COhRTmZNNMWrX2OPXbFU/tb7JJbx037KxZw86Ltmz3vHmTvj5x8aSH3K6RszdwfbAU1f4eZoIlrtnQL7yu9qEDTPbxT1RW/la/MTdNGTyizyOnnhqjKJXIlFJTfXRNiconjxtX+OqoC4cWWXX/3icSW5ofUB8OhoMp7ppLm9bpzOe7nnA7M3q+7T4CnRSBM8vK7OEfTvu8z5Ip96wuDB2fKY78muVFPtaCIRZwBJZYtfpIpb7+xa6V1W9/MuDMe+YdOey4aUeM7lYx+ILQ+336yNTtYxdMqTn6ozmLDvui//VWTNw/mBcbV1JcfLeRSM0RU7kDIhnjru4ZPvsYO/LB2PJ3F312xLCy9w8e+Njrh578z9ePHnL3W8eP/L8lx4166v3jRs0c8d5XS/YSYqvyVWWaXBjstVJKX/utUD9gzndLnrxoytM11N7ukHzC3R286PfBR+AHIsAZc0e9NeO/J3284C81JQXDNxTHxmRLi55QupaucbjM6iorD6z78pvb97T5qwe47uyetakHXbHbL+YPHHPqtFOHHTF/4Lj9FvV9a+91lSlTFaXXNdm9X88557o56yjZcoZEdecXoWRuvlBZ15+tqz5dq09dGqiM/1xbVX2nu2L9DWYyc5GgaoMsl9XFTXvCSivTb2k8PfjUSU8/Nabs2W8mLFpk/cCudchqPuF2SLf4RvkI7HwEBr8xfW2/D+dNf1tSr/0qFh1UGYqMifTY+4FIcZf16ZSuVK1Zd1jdurUX6huq74/WZ+ftmZOXFGfsd/dUYu92CWhvqLK80LWk8lBQfk6QxAdDwfBdeXLeFYIpDTYtzjIOZ/UZgwnBCAvkFW7Quvf4z/qiyLlLY9rxn8TcM0+Z/sx9o6Y+/+75s59L0ELAdsPXNhLuboiA3yUfAR+BZghcuWRG5uzXpnwx8v3y6Ue9PfmX36jsiPUFwQF2r6638z27Lg50L61msmykM1lem83Evqlan19p6j2+qq86ZFUu3W+9oQ9bqWcGrzaMgcuSdQPrFHFPd69ulXbvPcuN3j2uWZcX7PffED/8Paf48nGvTn3hwunPvH/lCy906n8O2QzArVz4hLsVcPwiH4EfOwIUaZ753qz1w9+b8epJ78649w0mD/lQNY5aFhL6VRfnD1pbHBsR37fbaSuKgqfX7V1yRnXX/DNW5iun1fUoGLU2Xxu2pkt0yBf54vEfRnjfuWr12IHvT//n8I9mv3H6kop19K2HHxu+PuH+2Dzu99dH4H9A4Pq3yrKXvTLru7MXzHhvbMXE+efNmzTrzGkvTrlw/pTJZ82aNOms+ZMmnfPKtCmnzX155mkLyuaMn/fS3AvnTnrn8rlly3e3/diWMLbn2ifc9qDky/gI+Aj4CGwHBHzC3Q4g+ip8BHwEfATag4BPuO1ByZfxEfAR2L0Q2EW98Ql3FwHvN+sj4CPw40PAJ9wfn8/9HvsI+AjsIgR8wt1FwPvN+gj4CLQXgd1HbrsT7vjx48UBAwZIDQnXCqUrrrhCpoRzccKECQIlwMiRftCb9DS00adPHxnXXjt0vkl3W3o51Sf5hrrDhg1TkafRsSFtKhchQz+0/IPthV6JdFCi86apLUO3VE793GSfQkfCl/S2kOfUJiUqo0SydGwht9klyaCeQkfSjXPCoFGO8pHnldM56W1ITfGjMshR3R+Kn+cr0tOQoM/zN103GrSVE8h7Pmx63Iq4V0T4kv4WddrVB6qLeoRN3ogRI/L79euXD11hJMlTvvWPzdogfe2s26pm2EL4NysjfX36XCHT8YpNx4Zz8jfleYnmLuYY5bXQ0zi2rqBySlf08fSRHNmMBjfrC/La/SY9o0aNCp577rn5hOOpp54aozHWHgWb2m+P6E6T2a6EO3jw4ENymdzN0XD0toK8vNsL8wsnOJbzO9dx/7hm1ar7Nqzf8IdsOjvhg/c/uPPdt9+9AQBeOHTo0H6jR48uJUe3t9djBwzIM3XzhqAW/H1+LHb3XnvueY9lGPeirXv33GPP2z9+//3joWuLjqaBg3bHdikpuau0uPRuI2fcnapP/F4SpD+WFJXcJ3LxL4os/4W57M977bnXPXU1NXfA7hsHDxz809EjRpw8fPjwLjQQ0EZ73nzMmDHHhwKhO9LJ9B3cdu/IC4fvLMoruCscDN6lKdo10BVrj6KmMhiERe+8886l3bt3vyMej9+x77773rZy5crbIpHIiIYBCX+EhgwZcg7q3QaZW/Ly8m4Lo+1u3bpNKCws/DUw74KyVt9DBg48ORaJ3OraLuwM37Z+7fpbHdMchToeYUBvgaZpV2ez2TvQ5q3Qexvp7dq16x9w/D9FUe5H+kvPnj1/H41G73Jd9zcDBw68EER8AnR0ae9kgKx0xrgzRgC/O2HPHSUFRbdHAoG7RZf/Vk+nf5cfy//1sP7DtvoD2CNHjtwzXhe/EWPmLkWS7sxlMncm6hN3jRs17hR0vtVxctro00589+23b1Vl9c5UInUn6t+OereNGDHiyC3VQT6DveGTTjqp/wcffHB1Lpe7uaCg4Bbk35qXl3dLLBa7RVXV30DH+Rjz+yB/s7aRHxk2ZNgFGGOHotx7E1YfffTRZXnR6J/h9y3a7Am38kG6ZEG+AnWDDcXjx44/HLbd27VH1Z9jBUX3x3sn/1YSK3pgj2jxv5zemQczqzc8ZPZMPJztUfUwy+UezuzT68FETfU/BUs/G+NVuXjAAO2cUaPOlhKp2+RE6tf6nnveUl1ceGf1+tI782OhO7LZ5G8+/nDJ9WecMeaGUcMGX3P6qOHnjBtx6oGouxnxN9jU9Dhu4LjCYQMHj7UyxnXMYrfVVdXdbGSNm0Ja4ObuRSU3jxk6/Mqxw4cfTnO5ab2Gc/S5y4cffng5jns15HWE43Yl3ICqHhYKBX/LmDtB1427TNO4zXHsG1PJ5HWuy34lCPwGXN/uus5diiLfF1C1pzB5ypllvxALxy5uOiC2Bo6uKEe6toXJI95oGOattmXfhOOvLcukdGcym7sKEzuyJR2rVq0KuI4zNpPJ3h4IaLc4jn2zrCo3cM5+FY/XXyPL0s9TydTPVUW5BrbfFIvl3RUMBv4QDAUek1V1hiSKT9XX15+GNtQttdGQjwkYckz7MlWW7kS6K5lM3MW5cIeu524XRel26P1jMpk8rkG+vUfHcYoDgcAvBMbvUCT59mQ8cVc+7ARBjiwsLFRIT6GqBhRRvkjP5u4G1veYujGBu+wOx7JBpM4fNFkbQ3KtpUAocoqiqBNyueyt8NsEYDshqxtnK4ri9TkcDpeEg+GboO9213a+DQBkAAAQAElEQVTuRsLiat8K3TfYpnWtZZhXI/08nUz9Gtck83vY92RQC84ozCt45sP33z+fFoTW2m6aVxAMdmeucztz7DvQxp1GLneXLMq3gvxusm3nRoylO7R87fAJbILQtF7Tc27b3fLz824i2erqmjuB/52KIt9hOdZA+NDDqqk8kYIgOCcQZqGAdkdQU+9E/QmSJN+NSX90a3WoPk1u4HIfyPV60zR1+Gg+SPcJWZYfxsL0MM6fVxTlE/jtEJQ9BHIdQvWaJtQrCQS1S/Oj+Sc05C9ZskQTGD8X4/VXiiw/Pm7cuIMbytpzjAQjR+X0zOWhUChvkzy3XOsInF8dDgd72Q565RrptJtLmyEhWc+MpFMQTGRVIW6ocqI2k6jLZHNxVdUSihIwUI/pkUjYcJzzw0VFA0xZ/DZpmp+HCvI/UdTQx5xJn6qS9pWsKsudnL1Ck1RdsIWjosH8B/Xa+l9tiSRJL+aLNHLQ0IFpJ/m0pioDDFv/zhGcyUxij0YCkUc1Kfh4UAstkkU5LxCI/KtyXeX1wHGzuS6KYiH0XS4IQi8cO8xb2J6WoJOiYRiCrutMkiSGQcZSqRSLRCIMZQyDiQEAZlkWs22byng6naHf2zxZUeW/O5ZzUR/clmzNJpqkgWBwOAZxMJ1OM9d1PX24ZnTNOWeFBQWn4rrnlvSEzTAPBIIq55xs8Gwh2zKZDEM9z1aQFkNfGKI4T29lZSVDv3g6lQ4ZujG0IC//35g4F2DyeQS0xbbC4a6iLA0kLAgTknMch3HOGciDbFeAx2k00KisvQm2kJ0y2ayqqodtVVUVkzEjY7EYJz31lsVBABImuleOdqiO1y/qWyAUuBbt7kGyLRNsVNEGpzo49/wZCoYie2iY+xBGfdG2rQCVkQ+Q5fWJ/Ez9bEiBQICRfVigGBYWIZvN5McT8VOZID6CqPU3wI/8T9VbSxyTeh/Hsfdv8Ava9fwF25gkiEzkPGjZ1pFrr1grtqaA8ixG3ZYU8jHnnLKYNw5tKwI7N6t38MEHu7Zty9Q3HL1xvH79eq/dWF5M8xS0+ACOXTD+bkV2GO3cNHv27MfKy8vfnDVr1ldTp079dsGCBcsqKiqWzpgxY+by5cvv4JxXoO0JuPs5FnUa38gPWqaVVx+vjzVkYgwKoiCoIHKLuayra7uXtTc4IR2wRzFMUxExN+maEueuwBw3k44nnp45dfpNU8om/aZ8+sxfv/TCS79+eeLE659/9vnrX3z++etfemnidS+/PPXXk1H2n+efv/GZl14qw8uwNI0rwZBSl0p9WTZz5suTkZ55/qWyF8vKXp48bdrLk6ZOnTRx4qRJlF82Y8ajKde+NZFOP60GghdXrlp1I/y+2bwBhlJeIDJS0ZQ7C/Jis9yMNKF8zpwy4LgEeH47uXzyspemvvTti9NeXvxy+bT7LMO4IxgMDAWOl7IWL/gOUHIVY9O7I2tRvMsuhe3ZcobWyFzOxCruTWoAwTDhPtb13EOCKD4si9IT4IOpyF9m27YDRLzm6ZhNp4MBVbm1a1HXxlspr7DFB3QXuo47jIgmGAwyAOtNdCIV6CUCI3Ipra+tPbxF1cbLlJzCaOMuCIDRxMOAZNDLMKB1DOyphqE/lEgm/iUrysMg14mIDFbl5+d7xAEHescNGzYE0Yc7cU23mI26Nzux7Z+gz8VkJ9lIfdWxILm245E5yeOW+wT0pTudtzfBXhs6DepzvK6OhQIBFtQ05pqmDR2UWBgniXjcVmWZaYrCOBYnRIaMnC4JAjNzuQPDgTB2aAZsNigVRULXXJf0Ez6EN6Jd1vQXRhzHdh0LHGDbnm7SD93zRc7+iPQXSeAPM5c9ifxFAU2Lkw22abKCvDxqW0P9G6H7p4goFZi62Rv5ciAQInwjiNJZJpX2ZIA7U8SNJjtYvAwj17/q26qtETctzDb5Gp1iG/uSwyIiutXV1a6ntJUPyDrkK2DNouEwUyTJrq7e4GIR26wOxvnwoqKiMOz5DZFsK+oasxCxmhgHz8Cela7l3DIe+5INhVicACETAwG12UKAsWrjTm6RIIi3KarcHwtPM6JuqN/a0XZMFg6GWdwwGuymoy1yLmiCQMTHW6vXVl7OclzD5aSrLVEGwtRXVlY+m3Hde11VuUhUlFGo1KzdgCjuFw6qv5CYO2l9Xc0jUxdNrYfMlt5u2Ywpr+QM/R5BEMaec845zf4rBHynYd5inZYJzy3p2On529UYURQ9ErExASkBCHSIz83kcrcYpnFTIpO6oTZef7kgiRdAdg5kTCCCLaKcFz3geg/T0YdiorU6AaGMKYJwKAb13hiwHrkSIVAUBn0eEWICUyTFunXpNmJrenK67sIhjGxUESHSJIT+Woezv5m2fTMXhFvJZlGRrkonExem05l5aMeBI72IF+TMHMvugfrDB2A/C3U3e1M0LkrSqdlsFlyjePYi+qwsKSn5En1lOoiXEvTsB71HQ0GzAYjrrb5N3fCITgGZAhMPR0EUmk0ARAtQ7XqYwFZaAL3FhdpFARckfjLqF7RsyLQs3IkTpzuNGGmqajfICYLgciZQ6OiVkz+QTIe50yVN+20Kt/4m9m1zpn6dnk5d5LrOVfDRciRWW1vr2YDVMoA9+OvXrVt3IGvlBZ+EDEM/BuQCAgp4dVAfQa9TT34nX9MiFo3GDreCVpdWVHhZ4XCYZzJpF3oY1SN/w35mW469xx6tBvgos1yqjD7RgZG/0J4QDAa9fC9z0wdFa9B7MkjxDZDt+k3ZWz1Mnz69Ej54Hnck/bOadlCDsOu6HLoEHDeuKCiAHM/LLxCARZ2WjD+Cfrwd1oJnYnwHUNyOt8A4Z1yxFb5JmNuu6+imyeBnYVPeNh3ozhVzl9OrvRVpoUmnE1NdUfoMg2YY5kewoS76ogSCwfNcgSdMXX9xUTt/Bxf+fwM6vsDdxSXQIeLce8Pnajwel4FdY55XsIs/fhDYW7LZwX2KaYAEOGeyKNLtHkUy8fnz5yewwiVxjAPI6mnTpr2lm8YNgWBgOQBpvI0nJ2Ij/2jcGrdKuHQbldPNQYgYNQx+DCJObTiI7j4KBYMbcIvBwGxeMgx9CJyxN2vlJSdkl15EUgLKXSwQ4SB8b9su6qRhK9nrJdzO1M2ZP/9VRRLuQ5t1aIsFiKBTKYqayIajsGVCwSQ0NX9jYpeInA8CsRB50WR3YONbuWzmAZBcnKJcRZJA3JYsuu4ATNzN9qKaa/z+CrZzkA+Z72ViEjKQATONjURBmSl8gJQ9gsDkwBVj6APM2bilQaQTkNUTMbN/4hU2+VAlBTEw4yITGXcwT0G1RtZ01YTq6cMtDOhWcGEHIzLCBGYOYzBJtMrKynJz585Ng1SShOXM+fNX4tbwJRt7sbKixl3OMd8EqDCwraL3iIRCJ/fZfCuJYxB01xT1COa4nt3wmRPSAh+VFBb+iTGWEGCJJIjQkevqGvapyGv1bVkWolOR0ZhEtE14M1WWcTRsjDmY3Wo18q9LGBG2HOPZdl34W3RbSnPO82EbPQSraVm2tWvY9T6w+9o27KIGOYTUMNHh8JP3XxUa8x0MTtc1V2Fg247zbybwg3CHMqChfKtHYORwgbEm9Ow43OUi8tAv1N2sT8jb6huEBnws+F7fprqY/zk9nX41HNAOVBSF9lm9dnRdPxg2npvM6DOlWKzdOGJ86fDP6wieRpEOTxk+gC3UKxJOKeHQMd5AfPsaAvQdDD44A2dQLSuSM2HCBI7TjRk4wdtFpPe147hfgpQcXMNxthd9JRLJAtyetWoX9BZFwuGjsJp50Q7VQ17SdZ3rbcuchoFvOY7DKGEgx7jl9ieZlikhJ1xZkrz9SchhEnEv2sS5WxhtHANNq7kIqz5XVKUaTvXkBdCRiwkIQoigXbGp8KZzzix2gGXZ3UgOMlRPwPUntmUtsG1nnYjBbpsWEzEZMPwPlWy71cY36WvlwF0LZCJJUmN0zwTG2eqNorQKcIb5Czs35jDWYAvZj/6ynJ4rUrXAIETpzQZmOpMSyL6Get6Rc89X3vmmD/iPUd9IFpOQ19XWchQ19TUuvbdbVVPzhsvcJfCvd1tPNmCyMFQ4ac+8vJZbAi4wOQ796076SQPaMNGDF01TX4R+pKg+JVmUBC2oHj+qTx+smiTZPJnYxnBA2qSnIeFhHo03CzZvZuvSpUu5gkUVbTRTtPHaYcuWLWtWB4u0Cjs0x3FaGwfNdDS9AFmsyWZyfw4qwf825mMhCASCAtiima6NPtbE4uJiAX34r+O4iy3HvR0PjIjoG6tv6QQ83cxmyFnYfXJt1wX8uNrGNxYqBjtohW2pt01NAhZLjPsQMPOWAHqIhrF4EhO4KCriW1iw7TaVNBHAnPysrq4uCX0Hg2ugnhE/0PgVo9God91EfJee7ghjGh1AA9QBkgChMa+htxi0Asopn9OkA1geUUqS+BUmASZWg+T3R03S9lZk6UCSxURkdMTAew/hz9cYPe+Korfv6FVwQLySLJ4EIsnzMlp8GJbhkRRs2KTHYRqi3NpkLdnUQprR4LIkUUYzpkfOoigyskHXDR3O3oyIcHuj5czccNhBE5HqIwmm41jvC5r2tePaC2kS0aAFRExS5APVYHQvxli7JgDa93yHByqePWSL67oMCwnLFeU8HRThctz6Uz61Q4nOUZdRxEvn1DaEx2BgljDmtY1LBl8gABJF75y18nIcico836GPng0Y+BxRdqv4kYoizmst2/qKzql98h+lcCh8OO7Viym/IU1gEwQm8NGGYWiUR7aKklhrms6b2KJZjVV9LfWD2qYHcuh/n8hee7W6rYA2XCwMLrUJcmRUbyPp50zcTW3mO2ovHk9y1KHTpsl1He7svffevGkm9NNeYwp3Z42RatPyrZy7ffv1nTJp5qSvG2RocSAbbTBhQx4dU8mkywTOQHQcdw6pVDz1ckBTi9Dv8VS+9WQzjDW3qQz6ZtE1bKe+UKLLdifMUQbs6c5tm+uiTRUN6a7rGjiyVatWCdB3MPryNVIV5W1Lgr7/Qtc58O/bEyZM8PyJcU38wrHNsy2qdrisN2l3RCsAgKIpF7c/raovicX2ZC7bHwOMJqm39wuwLdtyF+Mpsd5KJZ7Tc8ckU6koHM0QITPUhdOtBbXZ7HrDcD8TBE4c4xEo1ccgOx6OJBKjy8YEcuHQQYPFm3xwDgNRMLBpo8xmJzkWsiwzCH00eNGuw3Abw0BRn2PyZliLF0i4Z14sNqghm8iOc5YEHmuwgjvMdRZi4mOb0/VswHlxMhk/BgNmmwYw9jk98qR2MOCYbnjziC69xPGiEzpgYNIp2V+HCKqKrikfmfuYmdzpOLpI9OYSF7wFhfxIGZRc9JqOG5OBrjNU5177pAuYMjypaNCxUazJ5xowSTaT8YiSfEdFpB93LJGcrtM+cmPfPxr2Ti9BEI8gnWgELTuMuXyFy60qK5GIc+6+LwgCGeCNBduye8dTqf5YYJtF7PFXTwAAEABJREFU6tQGxgERldcf+Mo7Am80bXNEjJvZi/FHBO3ALjRKGrae+vXrh7ss923IDxk+fHirpL8lDfB3szbIhy3HIW3jSLLs6HrOKi0tJYzcvOK8zyH3OORHjxs3brMtoabtYZFigiByLFSN2bDVxRggLDhsIJ2NZe05sSyLbp2gV2iPeKMMRbNo9xD4fxWChTgVYE5hr97ojb6s03U9S3nbknCnoFdUVLyLebW8oR70c0EQOPy9zX1r0LEjjtuG1g+wQFUDYey9BrA/qSLqU7BRXjJmxJjjXUmaADz2p8lEqxAdg4Hg7IyeWYAB0GwQUrOoqwkiOwJASnAYq6mpoduGtOMKn2BfyLYFew3j7DvSg5nENqXusiDQtxU2Ax0PgGiweQMGOr1zagdOp0OzhLYVQRUOl2WlBAOCURsML/BHdSaVwXbl3M0IN6SFDoDDe0DMe2+0x/kCu8feDT+I90uXudWiKHp7mZgATFWVE9955x3Zq9DGh2CaHlEQ6TeQEtmmyt/zDW0pbEHNq5yzx1GWocUGtgmCKJw/etCgbshr9c05IHS5E1fiXrskhBNv0cLk8xZMwi6VSCCbSjdPeGhi5efn1wuC4OHOOSfyJ8KWg+gI/I5GGCPSFEV5EPSWcO5lef50HOtLJy3Xqt26ZWyXv+1wloWMF10TBtg1OBNqIi1bdg2Dk23wFyO80V+qg8kYPC4Zj198yimnXDB00NDzx44adcEpJ51ywXtvv31BIKgdDjuFBl1Uh5LDneYrGgRgt8M5fwbEEQaev8UYP6SVPWlItv2msRgKh7HFZm7sOKpUsSr6ahp9O8JcsWIFchgDuRh1icRDIK3v8HDobMyxVrdTSBh9dgkn1mQTV5YFiXNGe8WM7IccR2r3G+1yehHu7a4EQQQiBwOj/sC2AncXCWTRA91iYEsL7nfHH3/8NhMu6WiZQLQubNviWGwpv7OuGwfU9mgQDqAOejpxTio5ej0GD4R+LzLhr45hPh5QtcmYt1MURT2fBpeiKBRdmpgML2PNvP2VV15ZSxVbpkxdXU/Ltk+Goz1ypAkE0qyUufMFycaSyWrHcj6EI4Gzw/BBRKbYrns4CLMZiRFZuw7jDZEPHnqRCpr4KrPt7sMHDO8ysN/AvYcMGXLw0KFDj66qrLwkEAxMSKdTIeoXJRrEwYD27yiPLkZl6jcOG99oTzEt8xgsJHTrtDGTMQdtTsmJoreq44FQJaKyz8kGEqD+IMruZ+dyh9B1exNFLVSXsKR+GJbdOHEo3MdA9mzDkREmpNcyLT2XtSY5jrua8qkucD06Y1l9YbtAMggPPFKk88bkogeNF4yhIZfapj6QHYZhwJdboXnGWE1NHT4ZLZYsnU6Tj7DQqEI6kxG9Anx0C4Uiju0Mhl0KYY0sIkrdtpwP5GI5A7LBhpH9lesyj7zhC4+QsWAfzS2+2Rfdwcq0X0vtEHExspd0uq57ajAYehRbAf/RAurTIOynCwrznw6Gwo+nkqnTUN5oE8l7yWGud2zxgdv8T4HBr0C6edD/cHFx8U2Ido8dN24cbdW0kN7ypSzLsDHHFcXbSWkUDAVDjLYViEgaMhFopIDhYyUlJaegTfr6XENRs6OIXph4VhCLKZwKQLBcUQIK/C9gARRwTYnKKJFImwntkowXJdNJOxI/55xzDoPcXbB1keM4E2E/LV4YakIe51xGWgZbHMj8z2/btgW0gels/8+6tqcCYXsqI12cC8Ctid84Oyybzf1SlsSfYQJdgD2oEyzLKgExMko41zlnD4ImrsOg/QQ6NhvQIAHRlZTTRUEsJUdDjzd5dN14J2kY66hO2Vtv5TBJyzH50rj23tDNHMs+CROh2f5gYWEhtY21wPFuR0H23uSvr6+nB0j/kMLi9HBeaGpIC85XZeWNvLz8h3O57GGcb+wXBv1ynN69bsOG305t5buCiDSLuMD7Y2BhqDMiC4a+xgWBLcLtjwHj3IRtx23mfAQ8LJR5ZIjtgZgWCp2+LdER2vAWINKB+kyV5Ub8wiwMInIY5xxHxNNgKM45s13b1h19Jed8Muo7GJxUzkOB4Ehglkf2Oa7tuG7zByoufQ8BhfT2OsEYR189AoMeWrDo1r2xfbb5y41GovXwkUv1QE6NEhKxwsYrXplIdJUCyuENrcMO0k3rx1KQrQkxF0y9krnOOipDPzz8uMDzNU0h4uGQaXwHJInVx+MeyRNOJE+FVBfjSUCEyDE5OV3jnCIuCcTHYaeHHck2JM6459OG6yZHF+P3Qyzm5yLvr8DjYIyTh6HzkZEjR96Mh1snIwrthRRE+Rbfqqri5sWAT7/fG0JQ4mayaZcLog3MmuGLdpYkEokPYeuNmCex1hRbeLpm2xaI/PvgkXZlGOMq+jvyk08+uQ13VrfAtltGjBhx69ixY28///zz78DxDth9x7nnnns7Fo47UX4x2ggwvHAnsWlLz1EhE2lI9FsHkC1EKkFeKeS7gGgPxvk4YHE9xugHsPmWqVMbv2NLY0FAHsM83G7sSPrg092fcBlrmCbMG6y2bVN04YAkXc45nTMAT7d0nsMwwBAF8gESF28cMXjw8XQ7yVq8MCgKRUkcCx2MgEQ0RhPMxcj7GKK0SuKAhi39dQy8VTSpcPTakRVlX5DIviTQNMG5nOQoKiN7KDrEwCbC2AtlR0uydGg8Ee+CujIiVdagD3KpVDLxdzT6yBtvvJFsqrPhHI7eGw+vDiB7KY/aEUTxW1sQvqPrTclCu/SA0KB20Q6jJIrS4K6xWMkmmTYPhC/ZRona4SIHLBurpViKMPBw35jDPJ8wB2zqOLbI5P9wzr2HWISDJMujM4kEfR+Y4W7BJp0ML8jgE2/3e92SK3HkeCRG/aT6dA1/evl03lqyLG+Pzgahef6nvoN86ZbfW/yx2EhaIHR0LpvrRr52yctQhPO1XHDX4NTrX8px4q7rvEE2or63AGezWSln6H2xfdVsW4EYOhgIuCj3JiDhRPXgJ89+uiYdLtpCO94Yoz4Rtmiv+Ztv/ZsIFLXNmjVrEvT8DDrPhJ6nMF5l6DoN7dwDZXcj8r0YxHQo7Wfiutk7XZ+mvw4E6YIhN5XgeQXuxrCQumwzQiLiCgQCj6A/e6G9yy6++OLmoTF0CILo9dO2N0a4DC/UQRuGDdto3Mnwm4bxF0V+AWwtqK6uzoNvouhHCIFIUBTFiCAIQcwNz784YldQojuck3F+J/x5J8bJ3ajzJ5DxQ7h+CsdngekLwOB56BkD+14MBoP/wKL5PfPDFuSRb1zY4OByszdIWwRhDzr77LOvOuOMM64+/fTTfwZCvwr5V+B4OfIuw+LwszFjxoyC78EnjG36rrc3VjZTuAszvEG+PduHs7xOwjmMBjSc8BmY7S+CwP8sCeI/RFF4KRyOvA3nJkRRZIgwqPmfCJxdq6ja0wElcCJlNE0yY/tg++AAyoM+GiA0KXIu419ggDcOQrWgoNq27I+hG007jGzAeVgWxRFUtyFhAHAMLM8+yiOdsNsjI9ikK6qCwDOVxjZCyrGd7CY93qAF+Ycj0dgEwXbuGTFw4Gbf88UgEAUmHAMF+RhkjW2IXPgaxE1Ps6lJ2qd0FFn+Em2nYSz1x2sfhfu7gcBmepHf7K2oERCW4UVhZDsG9sb+GmYznyKf3p5uQdhY5ICGYZurxbSvTcuaBAEL14RrAXwwGA1xrAZYU5hXjzW8BG+uNVxBi+udk/2km46OTfTmZbf64QqCBrmNhkAiZxgMm/Ic20W4YqxHJELbNqfAbyrsYpZjM9iLttiXJud0N+PJ4WEXdgqcCujSMVGBhen1PxQKHo28zRYs+NzDGP5l0O31C+eV6PciQRAWaKo2H72ZB58swBh6VRSl5Q19ogah0/M/DOFLly6lrK0mIsKZM2d+XV5ePh3k9QfUvw3t3onjxyCjMzD+Hlm9evUvQCTNFgdRE7GvahGZNY5r7HUy2CYoqtwqIU2aNOlDLCZPQ+dldXV1mz1Ay2YzgF2Aiu95LpPJEllmsVBOQoT8W9g0IZvN3l5QUHBL165dbwKJ3nTQQQfdNHny5FuwgNx2yCGH3HTEEUc8PGPGjMbnFbZtc/Tnv+Fw+AWcl0HHFIznl1D3EeTfD8zvRf7voffPwLIeeZcBtHMxRwpwbHyDiF34gvzSOC4aC78/UaCL7oxpv7cI7dA3Qoqhk3zdPRQK/Rxk/0tskXh3EOgHffUQfSbovleyq8+21sFttg2g0oxsMSjcaZKq3DJ91qybJs2Y9ktF087LVK4bHs2L/RQr22oCmiYWnELk1FsNqE/htqZxH5MiXlFRBoOYg9CP8Y4bW+zgAegNIne+Q7kIByqIjOT8ZcuETDb9OeRMJNLnRTQgzbGIKpp9W8ECMUAHOdl74IOBR7dccUESb7QdZ5AoSwP1jDHU4e7F4VB4IgLCJAaQF0mBOPNAVJcpgdCfsM/bbPBg8JaIonAxnC9ggnkkgHawPWq8DZJwYauAJGLScpvzNaLAv9V1nVH7mDA0SMJ6Nnsi+rVZpNLUIUk9yTDIGicllRGOtA9A51tLAugGtnFEGo4sia8jgqrDJPFsAMBjRg8dup8oinjeKOCSxuwmba7DN53hsJFYMfA9GfS3gdCaVIBY8zeXBKkQdjZis6k+ONX1+mKKYgEW6D6b8j28BUEARDn6iyL9ij595PEHHYQtcCZqAWUFJnkN2Q4Zzw5D13vrmQw9KP2+ZW/paD7xYANzXOc/dfH6UZjIY7JGbiz23ce5Ah8Hn58mScJ/gIEN/UCLeymbzWI8Mb7XXnvx75W3fYagwMJWUgLkuwzpWYyHM2Hvn0H2F2TSmccQuXVr0AK7OBcYE0UuNeTRUZYlN53OOMtafAeYyiihD0+h7jLoPqMhyqN8SvANRZA4DSAx+laCi7GjQ9Z7k30YCzYdH330UZMSnW/aTyV/unROiRQ0JNKLNleAlD/AAvPuyy+/vBj9W4jjgk1p0ZQpU+Yh71kQ9nXo8wOw82zg+KemCw3I0UYeLQpedNqgv+FItmG7phzH306cOPFutHcP0u9wfe+0adPu5Zz/AVH4m9CvYY5yqocBQwtkCy6ikl2b4NrtbkCzTsKjOoBpzMO5Xf7663WHHnrolFQq/RBASsMJ3mSlIybMnkbOGN5gVTQaLRS4cCgGJ4cub1LRbRAcXeow4efRYPAuW9dv71pYfOeqwsK7wuEo/XCNRASGOozqKKra09Ktxr+1xorMTcNiRHAkAwL1zvHwIYHJ+zYmx9tY1d+Zt3DeGxUVFWWJdPJaPEh5BjaZKMdkEPFwKIjIyzlRFdXGxQHlTHCFwzF4DsFk9drGYCBSlwVJOi6TSP26vrr6Jm7bN+np7G8kzi9hXOgSCAQ8nQ02y5LSB3nNIh/S3TSFJMnJZjIeHsCisch1cF/ceMUYZ99vA7BNL2I3SZJcusya5id1tXVvEqbIIz/sLUnKLzRF2QN99WRIzktNtn/2liEAABAASURBVBTomtqFDMPkpf03j7Advnl7JEsJC41gGDmFJgO1Rb6B/xmOlus4tEfLXEk91BXYXpxzquJtPWFxUCVNGSY47N7l0by73f0OmJCuT9yTM8xfQ6gQYwREaHtRLq6DWECG9O3bl9iFlCBtZFzOcQoBsttLjkP7/fRXcZm5c+d6CRM7BX3xbEbPwTZOtuLoET+NT0luxoPQtu3vGYgSES1OQ79uLSosPHbdmnXnQYtnHPJcVVEwZhzvGvkM9nAjZ3BREN29927+HWAqpwRSq0NQ8g/4sS+I8BjKa0i27XjjG91t1Il2wE1mw7ZRY35DnbaOaIt8g6nXvr80I7IG+b6KuXYvsB+I9ht/SyGTydRHIhEzlUrti0DjhwAsYk7TnZO3aMN2TuMSbTTyDvI6xFvY0VYQibTWBjlAVdS3RFE0VVWlSedNGpINhgKHDTv22Cid66nUXlogcATA82RoosJBdK65jn2547i3Y0DdEYlFb8eAvC2TSZ8EsEVEzx4JwLlESpJpmccOHjw4RDpx28UkWXQh5xEd5dHESiSTtMo2JxlsSi9YsKAyXhevCAZDBuxlGBierZIoFelm9gj0xcPRGyyuMxCDnmM0M865lzABZEM3zpIk8V48gLs3Hk/cq2nq7y3TuhVyPREV02rs6SS8wpEwPfhp/Y/8yVhKhJnLGm3d1E8qaUxSVnIdd+OY45wzkqFCDlJEf6nAPeGEE9arqjwD7Xp3BTSRQMg/E0ThdBANpzqUqB64m3tHfGyMb5mLvtKdgWc/5Jlru40yEGv2RnSmBoPhUpJDvz1s6BxElkG4VY+oCpsW7mj0yvuqA7Ury7JHFno2N9h1nRui0cgtiUT8llAw+BtZlC6G3SomMaNxgX55tohcGIB6dMvp4UN06+LF8CIZHDwskCXgroN8R3JNE4mQP7xbXbqgMYdJTXmcrpumQYMGdcMdVJemeW2dY8w4WNQr6urrp5aUFA8ZP3K89xVC0RHxvMOicUh2NaqRVYVpAa3xurUTjM03ges7juPcggiyMWqmcQ6Mm1XBfHLgOwcYeOOgWWE7L4ClA9wJt3bWYCwvL+9N+GwlAorjMR+923+M/2ooqAmFQj1Q7vke1+1+Yz7K8A9tNXD0y/NPMBh00GdA4WyTfe1u9AcKCj+wXqvV0LvNOieJIjm0dXnueL8sRpMcpMQwSWhAM8u0VScvz1vpZDV4AAZMdxAEwypIT5C9yU0kjXyPMOlIJIoB4E1ODAIGp3pycKxHvNgDHhBRFG8Qoh1XgF0kB5sZBp4XsWKiC3D6Zn0g49WgWqvrOYMIApOUbv1JrxDUtL2XVlR4t0JRRNKiJPbLphE4YdtDEgSWQhRq4RxJ0E1TNG2bSYhg6hMJWjQYJojXPgY+ohrLwwAR8l64bhalkA1Nk57QUc9rtmk2EYn7fUaSgf4cwqUhD3qJ6JyGa5r4XFFmA/9PdWxtABsqEmEX/fAHnW8tccgxwoTqkiAmvUjH1lKPHj0UxllXqkP+I/zJNsu2lsKuKtjQFfYeh3OvOh1zuVzjOdWjPMix+kSc2a7jtU26qH3yNfkym8v1DgcCfScw1ur4pjY9pfjAIuDi0OyNuzBnUyRLD/M8v1AbaJ83E8QFonYR7d6DyX0zFtxtJQtXkZQPULdbyk55Y1PTRG6YBrqJOB/66V1TUwPYGKc+0vWWEqLzZDwepwdUPaHgTNjjzSGaN5kM7d9qjVUNI2ti3m3aamjM3qYT4EHYNY6ldlbOYoxVo+1iHBWqgwUzjb59ibGzXyaTiVDeNia4Ry1C3UZbcO7CzzbGCvmM0jaq3DHirQ7I/7EpckKjCi5ItGfUaoctw9oDq5OCAetFJlQJKxPL6bkUHGDQvqzL7KOwaimUjzyPROEYItQ0yDEHUA2sigaiDwt6bAwCikJzRKQo84iR5BE19kxmDO/BG7VjGnQXu9E/NKkpybLE4Sgq3jyZ3u0X1DoMKzLD5jwjwshmsoWpvDyZKui2vb+qKPvBLo84KQ+2ka06iCAD+zJQkEW9HOqbgVDIwkjJYlCgi5ZHHrCfUX1MwhMaJgzpaZks0RKweYBdiebQcgSyDbIZUcS8gxQyOP9eznW5I8tyo5+OPPLI9ZZjPwa7LIh6vkD73m00XTck3gp/QY+3SNIROLuGnm3Uy1q8zExmD6wIhwpYiEh/A9a2ZS0GDrSl0AdVesFoHDa+cTvNcrlsFv7NAkudc054eedoU4fN2BUxPWHyIelFfe64fPTSAQOCWFBQxdvmcEkIZXRgyIQp/HtQvNzvP9KpNNYhxSM59AuyrleHc05/gOB+L8no1roAPtsHfvQitqZlbZ3DXhs6OTDx5mINFmJsoblo07um+oWFhSyIbSddz9Hd1RZtJlmMzU9AYE9C7xmYM952l20bHNssqLdx8SI5VQ1ZaIPaoUuU0WHbEtrAvnJ62ypBGj5zYBv9brA3b0aNGmUDg0+grxsw7AqfNfYd4m2+Ua8UAdY+NFYahKHPRb4XoDXkdYTjNnWsnQY3cx46TYTbbICSnoEDBxZikp0FgIM6IiuQkRfxYfObRcPRz3F7me7atWsJ58II6CDS8spRhwb4a4IonI/I6HxspF6czWUv4i6/yNDNixGZXGzbzn2QS4LcPBID+EQiEVmVj20gMfASsvHpuogUNS9SxgAUMInJvM0SYg4bE4EmhkcwRBY0wQMBLSIkk96Du1AwfDQIM0L5GACevTjqgsDvNSzzpy5nlyB6v9gyjQvTqeQFmVz2Ath6oWlaL0GfG8CkCofDrLa2lsjuRJB0780M2ZQhOzJw3hgFoSOMklckcAv1POL0rlv54K7bjHAxwB3bdWei718RZqjv4UZ+oeqkmxL6gTYphzFvpmC7hfLRZ2+BwUR3BEG2N0ps+tx0oMUT0f0otOHtbxNGIFDGOEsh+n8LdRWRi6OhL8Dwcjl8g4Qm1nMm3gDSPReR30WJZOIi+PtC7Gle5FjOhY5jXRKNRBdiAjOMJYbIybtbwZbNUXFF8bZlZFhLvmObXi58vul0i4dgKEh3Hxzk4C2shAXqwSLHraqq2rhSozaiYRt4fY4VsxTtt/o9WIht8c0FfpBlmQkQbi0JARNvrggCE+m6IVVX17gB7fsItSG/5XHJkiUmxvGTjuOsgU1elItrN5NJYeH6XjqbTbqw10W7jX35vrR9Z/Alx0LTPuEmUvARtk1Mupv0cmn8YfzTN5fomwynLF261IvMvcI2PugOA33tC7E86KC56dXlnLvomws8UdRx3sL2NGXTCGmclKRblKTC04YN6479mh7Y59oLq9kBwwYPOwOD5yXbtkaBkDyyw+BgAIhh8sTrEnX011sMEfAIANeL9MC5jVEG9rPKps6YMXXGrFmTps6a8cL08vIXy6ZNfn5q+fRnkf9CUBafcJn7DelDfXKCR36mZRwDUgtCl4tJDo5xvbZpMpEs2cBMam3zpImiwUFmJAMdjPRCD8jfFBVVFUCS+XjOcqxt2xIXRY+AGGYNF4Rl0by8/8yePfslPMmdOKti1sTyOXPKZuIaDzpenDZ75stYHCbhSa1JWGA7wdONyUDbCsMwGFv3kcoYNuBgBm80FheMO8ybsA2ZLa835VsgPGfTuXc49thj12LiLyDiQpmHGWzwypp8bHIxY5bJqR2H8CA59Ju2cwRJFqK0mCKVDhkypOum/c1Du5Z0vTIay/tNfX29ZzC14/WVCbNDudw7ILaugsAHUlsgNjp4OJim9WlQDL88Y/bsqdNmznxp3iuvlM2eO/dl4PYSfD9RCYdfzmTSM1ABJthkg7cFACx6ikzsg8nLucJdLnjNQuz7tyAw+/ur78+AOZclgTWMCeojSNW7RuTcDDeqhX4sAKkVwwCa+JTVrjRs2LDenLPR6PtbqLASiWwnXPHQx6BLLyFqBXHEsNVgbt4JT6L5Bx701mJMPQu/nAScj8/ljDxBELEQhUi3JxwIRNBGDmuv2y6dXqUmH+gr1aPfZ2jU2aR4i6dYrIikqa67SYcni/FPP0DzkiiKQ3DX6+1newVtfAD7Lojej2aO8yLmowMsBarCQbjQ5WIhp8sOkzzjtpc1qqSim66Aznsq0WHcCmnn52zn6Vg4/KLMhYkS45PyYpFn9Ux2IBoXMYoZJdrXzBmG7rr2X7Dn9AkIOoh915GYfJyU0aDHSoZ9O7cSo/I15Hn5OG72rkqlNjiu+18wqjdpqS7ZEtAC9G2HHqqqWpwzA85hIF5GbWd1nQky4ja8N1NIGbKcwcFwUZESbEVwzaiuwqJRioK6Iyo6lMiWiwJLptNMkEQmiMJSTJgU6m7pzU3TWc5FsYZ0khARejKeYLIkn7x48eJ8ymuZFOwD26bFBEHw+ojBBtgdZtqmCFlKZJPLBEYrvVeGfMpjtmPZdN40gWQcRxDKLdddL0gSI0wMy0Jll5mOCWaymSO6rHRTJVu0HS5x+i4n3GEx2q82dZ0rknRpLBh8KqCqz8J/L0UCoZeCijZNloQHUJ6HGe7J0uISjUQ+4A7/w5GDBqXhi0M4513gb68/dKQ+ibL00er61alNzW52OPjgg3FbLH0F/+aQvDshwgR7S6osCyexurqwiIED3Q61STpJCbZQgJ1k4am/Q9ctE0DjiMgZhBjhQYsQyUiilMMk5nTekKD3XdMwFsTCkatGDhlJDzwbirZ4HDlyZHfXcq5TJEnAnv8L9M0FEgYJuSKMDQbUxpFIzwwSGA/oEIm0K2EvdzHG/YfcYX+QRWGUa1sKY9nGuqrEmCRygTsOESalxrL2nHiRLe4UyE/tkW+QQV/oL8tq0EUBkW5DNisrK8NNpPscTLJg8xWY/94D7kaBVk7Gjh2L8cQvsgzjI0WUZ2NrykSfPd9gPDHLML1tIVTd5v6hzg55C9tTK4iFboXRVwmRn+5NcqxAhVhlT8ae2PFwzjEYUAchylFpv0XXQXKC4N0GotK6WCx6kxoM/oMGX0SL7Mc464vBzFCP9Hq3/pwLHyVyuWVbsxvbETlREN5y8LCK6tPg2DQZuziWNRSrrIuHeTnYwmhy0q1IJBJhjm1zWW4c582awCSj7+GmyBY4laFPXl1XYDGsyCr098ek7G7aljfpC4vpITmjhxKv9e3bt76ZsuYXbsbKrLVs+2MiWiJSsgd4ME1Vjkdk1bW5+MYr2MMKCvNFtMkweL29ajoGAiEL/TNJKsqiTOCCQPmEBR0JcxwFLDqbDcJ4PP6ubVsLqI8khz6RGg97OhG5qGBR8AY0cMIaIQrwrxdViqJIt+DwuXtgJpsbJXLhVNsw+ycS8X62bfUCRl45+kOk7+D4em1d7S8T2cSnb775ZoC7/Hj4QoFt0OEw6Cd8rVzW+Pitt97KUfutJVoocE+x3DTMuG3b3hghm2ibAwvs0WlFKQVAIvD0fNvQL9IPOYcIuzW98AE9DPOKaAzBXrKHFh4bY6UZdhhvKVlR/g93VUlRFZ7u8XUIAAAQAElEQVQYgdeWCGPUqFHBMcOHH4oV8T7492hsj9yYMYwlXkObPjRVFWqqqiGyMQM2c/iaS0Jj1saCrXzCpnr0YaIgCvsBl5MkWVYxBjzfUbV4KsU1VYNKMQZz8/v3718M24qw5VaEyLsY9pc0JLqmRNckQ7fxmOu2Kiu8tXFE+reUQKyIhdzl8HMUmDYj1eOOO+7rdDLxV1HkA2TGfzf4xBN7wb+bcRRslEaPHk2/A3yPLIoxQddfth1Wi4Wdbgu8YALjjchWsMAxW7JlV+Rv1pn/xYhofr6BSLEO0ZERicV0HLOCJGWQl3UZzwbDYbrOhqPRLGZrOhSJbBBF8aOCvPyHdNM4a9mKFQ/CIXECOatn+2CSyNjT1EHOWQwWCyllmvorGEwU8bhbs9XhfC4G7te4VTEw8MBLOZMeVDEmnILJVoDxl4R+HedmYWGhhUGJgcCqatbVeGTVUneXLl3wwMt9A0RrwB4sphZ9KZ6+x0i/PXAU5IcHAgH6l0EGjjomvIFB9S3SG+hPq1EU6njvuXPnVlm2tQj21GJy67DTQLINwxQzycxhNMA9wSYfMS1mIYqpKyopyQFnPb+w0MCkT2cNPYcJKpNolV7lyJqaAHDkDxv4O0impGip6lb+l9frr79eZzvODGBejz44WKgs2G8pikIECXzchNajh4e7hf0HwzCqCoqKXJAwo2i4pEsXBluYFgwyPBBkaiDAuvfo4cDXJnyeQtvfIXKcVZ9I/jKRSZ8xZ/781+FLC9ijyfB+sJkeLlK7yLJNRZa/cQWX/vTYaxPlrb6VdHqNIIuvKpqmy6pqxDAO0ZaOcRfC4lFsmWamprauCvaYGHM68Mg5jMUVVc7CN63qDAYCWdM060OhkIH+E+EjIEtXioylKUprWWnKlClf6MnklcDrTbDY7VjQ74Xfrhg4YMDZ55577piRQ0eOA0lcxG33rkAw9CC2y+pNw7kU2yOzCYMGfQrnVjyZqi0sKaUx3pDN6uPJRCabIzsa89o6KS0tfS+VST8UiUXXC5xXy5blNNSJYKxmMhld1bSLsqnM48VFRY8LLn8iEo48GQmHn8DceZJSOBB8XJXlJzVZeVyWpCcdy/k9gPCeLeT0XBwYbetTMxfO/QiLnYG6XWAPR/Le8IUzb+HC2abj/EKQxK6RvIJ/vb34jV+NGDR09Dnjzxk09NShQ8aOHXt6OBi8Fn79LbBeLmZSv58yd+6GnJVLZnR9A8a+N3/zwnlWJpupRRvetddAB/jYroSb0TPvRsKhq9PpzBWM8csz6dTlAhd/Kgr8fDWonZvLZs5NpJJnWYZ9pmNbYxENjhRs8fSsqV+H/czFtOHP8ALwrmEbbyTTqfOMXPYcjLXLNFW5yLbM80VZfhEibb7XrFmzzDKNn6aSicsikei1kiRfXVtf91PLsB6AEzKWY71sGvrPXMf+BR7IXJPN5q7Qs+nrwgXhFa0pLysri6PO/2X13KWmaVyt57I/t13nCgzam8DmqwVB+AtW1fMxEH6G61+AyC+B86/E9Zet6WuRR7dZLwCb89DPC6H78sr1G86DbZeEoqH30La3ajetY3BjjWFZNwCjs4EjYXSWYVjncIE/jb1TnWQRCSSsnP0312Fn1ifi51mmfW5NXe1ZtpF7pkGG5JomVVUrkon4+Y7tXl4Xr79aEPjPGXMvtxz7PN0y/q93797efSkG+1rL0H9dXV31s2BA+znn7Oc11bVXZ7OZq3Q9dwUwujRn6BesWbd2PDAbI8rScOA1sj5ef3G/E/s9SN9tbmgXEzCeStTfl05lLjIM8wrT0K9QZOnC+mTiCsdxPm+Q29KxbP78eDaZvNfl7ALgcSV8/vNUKn05+nujqIsr1HD4O87dG4Hv5TU1tT83LPMq9OeKVDY7izHWSEI4994Yfw6zxGnx+gSNn0t107jCtpyLHOZewiXpzdb8QRWnzpmzoj4ev0GQxMtlUZkbr6sLFRaVHJFKJgeYtn6CyMWYIPJFiOKuMpnzm/K55Z9RvabJjUsruCT8ura+9tmG/COPPDItMud3FnOexbMAiuIairZ6hJ30jY6/4W7oAvjy+g3JJH3flRYv13Tdj7goXJXOZP4UyYv+W88aT6RSiccM03ikpqr20VxGf1hk0sOpVPLRZCLxiG1bj7oWe1gURPoz3mosOgk9k/k/y7Ke26oRrRRiAXsHaYIkSY2/jdFEzJ0zZ857CJh+puvZCaFIaINhm8cn0/FTtKB2Ui6d24u5wte2bU+YMmXK/eT7TXU/d5jzT8xDWgDc+lT9fwVRvEkJBJrdPWyS3WWH7Uq4s2bN+m7ipEkTjzv+uGcOO/yw5+YuWPD8tJnTJuKh1mQ8MJo6dcaMaa+88srMKTOmzJw8bdp8bB28N7l88jIMIo8gmqDgzp8//wts/pfPnDNnCo7Pl02e/MKsigo8N5m5qoncFk+JvFH3ddR59tCfHPrEzFkzn4Ajn+vbv+9cRBT1IPglKHsKNj06c9asR+bMnfME5BfAlsSWlCIS/S90PIvOPNZ/wIDHpk+f/hTypmGf9YOZM2fOhZ0TofdJHJ+YDHtR9goSDYAtqWzMR39XgoTmwJ6JRxx11LMLFi14CQ8Fp0Nv438DaBTGyYwZMzJo601gSJhMgd1TZ86eiSqzPp0wYYJHInScWTHzAzyomwY7Xpo8bfJLr7766tTyuXM/ozKo2ewNP9VXzJ9fPr18+pP9+vV7os/RRz8+acqUp9DXl9DGhw31oC89a+7cmfMWLHgUvnxoRnn5Q7Pnzn541pw5j86uqHgMdZ6Efc+iX5NRb/bLL7+8GBPkM2BV1aCjoXH4Izd73rxXvT6Xz3gS4+XJKdOnvwgcF1M7DXJbO1YsXLgU+svmzZv3n2P69n2yYl7Fs9Tvma/MpB98r8VYnAld/1n02qIngfN/oHvia6+91iq21M70iunfvPLqK1PmzJv3LGSfga5JGLuzZ86cSSRBIq0m6gvs+GzazGmzju/X7+8ud+9IJJO3dDXN239yxE/+Cf/OnlFRsRS2tDoupr8xPQmsXwNuXzQ0MAH+nDZr1jvo20fIc5Ha/YbttUjzFy5c+Bq2ZrzFkirDJ1VIc9FO+bRp02aUzymfvmDRopmQLYcfZs5dMNebp4Qb5U8vLy+fNXfWzOnl0xdBphZkbsxbtOh9YNnmgkjtNU1oNwEcFxFfNM1veo7m6mDMu5OmTn1WUpW7cMf028qqyntyZu4fM2d74/yrpvLQWTV9+vQPcfS4ZC6iXsxVamN9U7ldfb5dCbehMzRAKOGaBgclnHpvOqfkXWzjR0O9hmN7q3t/Bw5hqtdwjstmbyprltHGRYMeqkeppTjlUWqZ367rTdiR7A/WQZW3kNqtk+ygBD1UhxJON3tTfsu0mdA2ZJCubRDfTLSpbzYrRMb/qh8q2vcm7IiYiIT/vWhRbsKEjQth+2pvdyl3O2ncXnrabQ6RKHDM0oIBLK12V+yAgjuEcDtgP32TfAR8BHwEdjkCPuHuJBf4zfgI+Aj4CPiE648BHwEfAR+BnYSAT7g7CWi/GR+BnYwA38nt+c21AwGfcFsDyc/zEdhxCPBhw4aplAYMGKAhSe1tiuqMGjUqiDpUz0uj+owKDh48ODR69OgIHRvKxo8f/7/MbY76SoMuHNttI/WFfjcDdbS+ffsG6Eh5W0uQkUgWbQYo4eFiM9upHMnrL8lRIhwo0Tnhsql8m+zcmk07qqxZx3ZUI75eH4EfMwIgg6KhA4f2HTZkyK2jRoyYoojyqwFFW5QXjS0KB0Izhw8fft+QIUPGDB06tCdkWyUN+lPgTCbzAOd8biAQmCcIwtxwODzP7eLOi0ViC/Ws/qoqK6/kRaPzNEWdm0qmykaPGHHHoEGDToLuAtbGi4hr/JjxB4G0zzvj9DOeNnR9fnFB0SuxcOSVovzCOYNPPfVfILYzoGsfIsUtqSMS7NG9x93RSKSiuLBoriarz40bMeLALckTOauSdFVJcXFFKpGk36SY8d57753UVF6SpHMj0IfjvKKCgnldS7ss4K77CnPchV1LurwiC9KCoBaYr8jKNNh//wi86Lc8muroKOc+4XYUT/h27HYIEHmCRAdGwpG/ayG1QlW1e23TGmMa+rGGnqPf/T3WZe4QWZRujITCU2RBLAP5XDB27Fj668VmeIBstaKCwuNBMicg9cN5fz2b6+da1vGJ+rqjg5p6hGUYx1CZJAj9JVEcZ9nObwvy8stlSbobEXC3Zgo3XVA0OXbYsN6FeQW32K4xLRoMPZuoqzvfzOn9c9lMX9uy+lqmMVASxKvDWqCsIBKdZmb1X4F8vV9i26Sm8YAFQdT17OHMZSe6rtuvsKhwcH0mU9Io0OIEhMtQp5fruP3D4XBf9Gkgs1n3pmKqqu4lMH5iKBDsZ1n2CcCibyaVPjagqsfkgKNhGiegrRMi4fBwRZKvA/lO04A1FrL9murpCOdCRzDif7PBr+0j0PEQQBSoIBI9V1WUfzu2fa5pmhHDMJiiKEyWZYYIlRm5HANRsGw2yyzL4lwQjiosKv5rLpe7kMi6aa+gy7Ud2yVZRHreT3hqmubpQ/THUMc7Rzve75iQfhAZi8fjIVVRf26b5iVkU1OdOOdL3nnnGBjzkKYqd0B+H8gztIUixnDtpXQ67f1GMx3r4/GDZFn6vW0YfxszbMxBrMUL5OhKouQ02IE+u3l5eWILscbLr776yg2oAVGRJFZdTX8Ix5xAQGnGS7quu47jeP2SgR31H+TM6J8OgHQb+03XhCfsFFHhUte0r6OIu7GxDnDSrGMdwB7fBB+BTo8AojY5l86dgcj1Mce09sDtLxM5Z5hsOiK/zx3Xmey6zqOc8+e567xTVFCQTiUSzNR1VlNVFSuIxm4KysHm/wiTMeZYtq3KMnNtm0VCofWZdObxeH38gbraun/JgvAvPZP9lyDwR1VFni2L4oZcJsMUSWI48lAofFWmLuP9BgJUee/TTjutuygIN8uKOqi+vt77sW4QmQuyrgoGg4sc23lSEKXHQMDzQXrrQabgZoEhwmQF+QWnm07uRkS6xZ6yph9c8IiaFgQQLy0SW3yAl0wmuctdAcTMAqpKxO7mcmZTbQz20B9bOKIoUl8cxzLfFlz3oVA49EAymXggm0r/syCW9yy2VL5ijgMCV2kBY3kF+ZdkkpnjoWyL7aNsp76Fndqa35iPwI8AgT27dNlHlMRf2batOIjMKCEqW6dpgZstyzjXct1L+hx77M8yhn4pQr/zk+nU9eFQ6GuK3ojUampquimK+JtTTz011gCX7Dhc4KAZF5sQSOl05ssIc258ZfGr1y54bdEvplfM+cWchQt+MWP27KtsQaAfar+1sLCoEjZ4UTQi6C5qSDqgQR9tJViGdYGqBcYgImQaomWQrK7n9DLHsS9wBH7BUX2PvXzazOlX6rZ1ocXcs0DAT0GGyM+LLsOh8NmarA2GzkZC03Wdo48CT68YFQAAEABJREFU+utFpCBLrklb/uF0LE70M4oC9Z0IFVGqoAZV70/Todd7w3bqA9YnDj51sgFNe25y+cyrp86Yce3cV165dt6iV65J5jKXMeZcg/bep7sARVHIRlULKEPQhuQp6gAfO5twO0CXfRN8BHYsApYrnIgorA9NLiIeEEm1ZVtXVdfXPjyzouLj2bNnJ0B4zqJFi3LTKyq+SabTT5uO/VfI5oggiXSxfTAwqATp/9p5ZEZ5jDP6kSMGfeiAi+DZojJKuG58u9BfZdh2eTqdehsERGRFhZJpOY3RKB5M9VQU+eo0tgtIn+26bkbXFwSi4duVYHD+5MmTV5ONqOhWVFSsmzVr1mtGJnVnNpt7VlZVZDPaxtCY61w2fvz4kJeBD9M0uSjKjPpBbVNyRbeljZDc9F7CGBYnkLTFYAMj4kek75H6JgkiWQZsvKhVDQR42jCIkHlDOR3RZ13StNdd15lCbRJJUx3XYfvsvffeJE9iuzzRmNjlRvgG+AjsLgjgKXkIxEj/uYLCUUa3yoqqPj29vHwGEWxr/aR8xTAmJpPJMpTPt0zzEcd2J6T19Le49t6JRAIkZgmx2MagF1EzZ5vOPYHNPySQn0LZFO0RCeFap2sQqYCHc6fg3HvwhXyGh0zV2Or4x6GHHvptWVnZZr9OB1k2e9Gi1YaRexih5lrXdT0SdF3nJCujN4tySZYS5LzfQEbU24xAqawh1e1d5xGny72Dl805byZP9pONyPf+p5sktP5/EkHWusBE79f5KGKmSNd2LPnggw9ups9rZBd9+IS7i4D3m909EUAk2oNxt/FrTXigVWMa9hz0dquTfsqCBTWFkfDNhmNfJGrq9eVzZ/9zwYIFyxrqQS+RIqf9U4reVE2TQcLaqD59AuP7jg/gIZtGD4jGDRxYOLBfv70Fx7kUe6/0TQEQtU239/XBcPAb6GP0g+8guL4geEYkRrpN2/wEJL7FX5GjepRszr/FIrI0Go0y2vd1XZc7nA1F2wEqBzEiDv8+oAyHw2iiOYGSXNNEAnSNIx0QNDvfK0AOPRCEjR4jh0Ihhm0PG4tGMxmI0VvUbaOHiL1ekDxDHRYIBk0saB2G57ZqCPXATz4CPgLtRwCkdShzWQmIyKuE44pULkXE6V23+CASaUy2qlbOmzdvXZ8ZM3IglIZ8rwr0ciTwqOORZDgUOjwgK383owUP5iLJh2QuPJpLp/+TE8SJ+UXFs2KxPPrWQYjIGdGeiyi7AiTk/ZQiiC3KXb4/3XKDIGlrwHUt5ytc13uNbeUD0Wa9aVr/hS0MZOpJCgI7ADoj3sWmD1x7ZyB1VxWb78l6BU0+BDxObJBHNiATHByp/zgwhkWLYXFhRKQk58BYr6DFRy6R2FcSxNOxIDD0xUvo86r9kvs16mpRZadf+oS70yH3G9ydEeCu2/hNANd1WTaT3lCoaemWfcbT/d5jxoy5YuyIEVeNGjr8iqEDB19eV1Pz01FDR1z+yZgxl3/wzntXjho69CgQrzdHZUSKIEcJ5Ol9rQwEFMIDrPGSKl1kM/ciRH4XhIKhM0CIp4Dk9kdUKIJsmKJphmnZc1Pp1B/Ky8s9QkXkq1qWGSLyIjLD0WWCsPr444/PtrSz5TXtlQqSsCGTyXjE73gCPIa+Br1T+hC4F80jj+HBmm1ze5v+U4UrYOeVYdkiXUi0HUJbKeg/g86AqminjBk+6sqBJ518xfBBQ68cOWT4L4efOvgeLkr/llW1v2nb3mIADDKGac54dMmjJtR0iLfnzA5hiW+Ej8DugUCzJ+KBYIgnkvZmERZI7yjc8j6gBYIPxvJiD4fCwUcK8wseDYYCD1um9bCqqf9kXBy2YsUKhWAh8uScMwVP3+mcyMcwDO+BEpXTQyrKIyIkGaQU9mUX4iHXn0Ja+Nq+fft+CjmPCK1UynFcl5N8KpVCNuOIUm06aU/irmsWFBR4D7E8ec4F79jKRzaXZdhb3cjLrZTn5+eDXR0i0oZSzp2NhN2QUVNT430VDX3y+quoylmKKj9YUlL8iBZQH47lRf+mBQO3O45zFEX0Kh7q1dXV2ZoWeC4UCr3doGf7Hn+Yti0C9cPU+bV8BH7cCIBZvf8YQgxjuy7tn0Zk1ab/MYei77EBMUggCBnEQF9f8h4u0TcGkOgfM1KeoGqKCsJtrIToltODILpdRmSaEgVxDhPEcttlH2bBwlwUWSgSYRThMc7fyWbTN/Wq73XPS1Ne+hqRMpnk6RJDIRdRo4MI2SPwAJ7819XFi5cuXdpssfCEW3yMHz9etG03j+zmHNu16CPY0oFtjfoRhXrETlVBfi4i7sZrymuZwLgeNqhHRQ7nvFlEStGtpmnokifG0FXaYhCAFUsh0o4nkyyHxYeOqEtyhiSJz+mmft/06dOTpLSjJJ9wO4onfDt2CwQQJtK/wWn8v2Mgtn0kLdwFnWtGOiDbhCQIGxDhpUF41Y5tb6A9SsgxIlUQGLMty+3ZsydlMRAXQxRLROlFeYhOP+WmfrHlWGc5zBkpisJt4L4U1YVuZjvOQEkLXL+8YHnjV8E8RfjArXZakeU6ioZxjhzGCosK9sqsy4S8i618VFVVRSRZ6kXRJuzxbHGYuw5k6YXKIHFcul7/ifyQT/vOtOC0qpX+0gwPGTnkGsotbCZ4Wx8NGSBY72tjOHo4YMGxotFYnSiK9cAvgWMCkWx9SWnpF4Ig/juXzZwL9r+uoqLCe0jYoKcjHH3C7Qhe8G3YbRAAKXwZCAa+IOIDEdDXwkplidH3aZv1EST7RiaXG5HNGAMd2xouSuIZmUz2fSIpEAoTBAG37KCNhlq6zmRJ9oiHyBik6iZsW587d24aD9rWJlKpB23b/Av2cXPULuxgiiyfLXDhnhEjRjT7bYZoNJrSDfNjInENkSORHbYx9ndVdzNybmi+4ZgfDJaEg6HDiKjJDmpL4OKHdQiRIUPEabu2u4F04pqiTYXbPErnraXi4mJBlBSlQV5VFNvQ0832ktEORb1eNI52saa5T1imM8KxraHpRHwQGP7UdDZzMrYvTjEs46r5CxdOAtnWNmmvw5z6hNthXOEbsjsgsGDBgg3VVTVzSkpKvFtfIqREIjXW+35ukw6WlZXV4nb3/Wmzpr0zecaM95Rg8P2AptWQSH19PR3wVJ67lZWVGyNj7Evajs1APkTiLBqLCojq6B6bEnvrrbey3BAfNwx9PkWfRKa0PxsMBH6KMHTcgAEDGrcL0LapaMpCkLpFt+XY3qDfTzjIEa3+2HrYIieMx3ZC2jAGwo4DyQ6qh3YyelafvWjRIhAhc5FHR4o6Yb9ItipcdJv9GI3XuU0fSiql5bLpHqgHMx2WBaNiMfIi5E0i3uJD+9Wwl2ExEgzDWj5l5pS36R9rzqyoeHcG8Js1a9ZHSOvpoV5DvY543CK4HdFY3yYfgU6AgBvLjy0CKVUS8eHWnyHiHRhUlLuHDxhAWwst5xwfPXp0JJtIHCpK0gEUmRYVFTGQabOuJqoSRDycbuNBOiyXzoogPRdClHBgbPai2att5j5gOXYNtQsypG0I3IZrd0SD0cMh5JEzjm4mk3nVse23EO3iktEP6YihQPDmj5d8PGDYsGEb/5TMK9n4AcLWMonEySVFRTdm8KCNImMiwEw2M7ukW8m7kPLsOPbYY81wXnQZETnZgEgca448dPSg0d0g0+wNnVLcdQ8Lh8OHkz70h0myvDprWfGmgsCEQwl9fY36g3POUVdsKtNZzls6v7PY7dvpI9BhEcDt8dt11bVlRBJEkBS9BYOhGwLRvIdPw+vkk08+eOTIkfsOHz780LGjRg21DePOvLz8523b2ouIBw+ZvD8qME2bl2ZLPZKMRj0O9B6oETGBVBkIzStrCgTI+HVsSzxEhA2yowiT5HpKinQJiD3cIItIEFGo8HvoWk9yCCzpmwD7yJr8H5GLNw89dWg/2Lff0KFD90fqmxeN3hgIhZ/JZLK9qD8kLyrKettwHv/3v//d+LUvRMgOthc+7d69ez21RVsrsiydkWPZvw8dNGg4Iv0DBg4cuDdsOQx9PTugBR5ijBfF43Fv7zqXy36GB4J1rMULpOzloA4D43rk7mV0sg+fcDuZw3xzOz4CU6dOrY+GAn91HbeColxZlhn99KBu6GNkLrxYWlhUoSlqeTQcrpBEaTpI59fxRKI3kRORH0WmSDbIZZ2S/JRu0ZkpCC7I1KXtBhAtIuBG7mwGCG6vM7Zt/wP7mlOzeo6B/L1kWeYFOO/XVDidyy1G/qNEZsFg0JPLJJN7yKIwoUuX4hmiy2bnRaKzi/MLZgmM/9Y2zS5EtLjlR/sh08hl/+mK7uKmOukcke8XmWx2MuzwdFKeIitncEF8MT+WX96lpLQ8oChzC2N5z+R0/RCKhkknHoAxLggzIO89gMPRe6vYTiFs6IJkRc5d7P12StIVqBN+8hHwEdi+CEwuL18mqfJVIJ2XJUkyiNRAeAyEISYSie7YX903kUh2BZFIlE9EFgTpITLVORfeVxX5pxkj98yjS5aYnmU6oz1h77cUSJ4LTPTyW/lA9FqFiPFhbE2sIyLDLTkDeUewhXALIsvShir0wM1wnAcSifjdiqJU0fYCkTnJY+84D3bvXVdb2yuRSORRVAvbvaqwswp17lAN41+kw8ts8kEPrNKZ9O/DkcgC+kpXJpPxSlEvEo/X740I+IDamtpSiuSBj7cvjTJwb+4PECzHHrO3yODce8MOsWEhQj+Ag7lZZO8JdoIPn3A7gZN8EzsnAoh0VwiK/MtMKnMpiGxqfl5eFefcAoEwRLfMtW3sr6oOSDcHclwhydKTOT13hZnLnHfIEUc8C+L0vtNLvQ+HZfprAJuIh66hrxkpUV7TBIJfXFNT82+SR5v0vVX6q6/+uD4PD78CDbKIiKv3rNv73lQqeV46lX6ksKjwO0SUDtmINuhhGm010NEsyC9YoWrqw8lk4txwXt7/TV20qJ41KGpxhO3fusy9LJ3OTADp/hfEamKRYQFEq45lMYpmRVEkvSkc52dy2UtzhnHv9Fa+NxuPxwW6S6AmsNjY6A+vqqrqlKTrEy550U8+AjsIARDI2vJ5c55lknh5TSI+WpDEi0zbuRlEdLMgyTfrOf1naig4rjYRH1lTX/9LJRB4btaCBV/RXmhTk+KVldWOw/4kytKtXBRuBRneD/LcGDo2Fdx0DiLNgKQedR37l4oi38oYvyWVSt/smM76VCrV7Hux9Kevs+bOnSdqyo2pRHZczjLPskz7OttlN2WzmZsCkfA1qXTqjLpUYmzONG8qr6iY3zIKZa28aMEJRUL3VdfWnBHU1NOZ61yTNY3fcFG6CaR9k27olzuOPSYTr78Ekf1Lc+fOTbeihpWUlMyF3M3Y/rjFtpybmcAWLFq0yGpNtqPn+YTb0T3k27dbIAACrEbU9/a0GTOen10x+0/llGaX/6l87pxHp0yZMge34UtBIqktEVn566/XTZK1+v4AAANuSURBVJs57amp06f/YfrMmX+YXl7+IvRho2HL8MyZM2fFjFmz/jFz1qw/zJk754/laG9WxaznUa8xcm5aG4tDcvrs6R+i/OXZ8yv+Bjvvq1iwgP5a65/lc+ZMh43eb/k2rdPWOfqTXbhw4dJJ06bNqJg//5+w6c+kd/a8effNqqh4fMqMGa/MXrRoddkWfhKS9L/88stvArc/zZoz54+z587+P+h4j/I7Y/IJtzN6zbfZR+AHIeBX2tUI+IS7qz3gt+8j4CPwo0HAJ9wfjav9jvoI+AjsagR8wt3VHvDb9xFoHQE/dzdEwCfc3dCpfpd8BHwEOiYCPuF2TL/4VvkI+Ajshgj4hLsbOtXv0s5HwG/RR6A9CPiE2x6UfBkfAR8BH4HtgIBPuNsBRF+Fj4CPgI9AexDwCbc9KPkyuxcCfm98BHYRAj7h7iLg/WZ9BHwEfnwI+IT74/O532MfAR+BXYSAT7i7CHi/2fYi4Mv5COw+CPiEu/v40u+Jj4CPQAdHwCfcDu4g3zwfAR+B3QcBn3B3H192hJ74NvgI+AhsBQGfcLcCjl/kI+Aj4COwPRHwCXd7ounr8hHwEfAR2AoCPuFuBZzdvcjvn4+Aj8DORcAn3J2Lt9+aj4CPwI8YAZ9wf8TO97vuI+AjsHMR8Al35+L9w1vza/oI+Ah0egR8wu30LvQ74CPgI9BZEPAJt7N4yrfTR8BHoNMj4BPuDnGhr9RHwEfAR2BzBHzC3RwTP8dHwEfAR2CHIOAT7g6B1VfqI+Aj4COwOQI+4TK2OSp+jo+Aj4CPwA5AwCfcHQCqr9JHwEfAR6A1BHzCbQ0VP89HwEfAR2AHINDpCHcHYOCr9BHwEfAR2CkI+IS7U2D2G/ER8BHwEWDMJ1x/FPgI+Aj4COwkBHYs4e6kTvjN+Aj4CPgIdAYEfMLtDF7ybfQR8BHYLRDwCXe3cKPfCR8BH4HOgEATwu0M5vo2+gj4CPgIdF4EfMLtvL7zLfcR8BHoZAj4hNvJHOab6yPgI7DzEdheLfqEu72Q9PX4CPgI+Ai0gYBPuG0A5Bf7CPgI+AhsLwR8wt1eSPp6fAR8BDoGAh3YCp9wO7BzfNN8BHwEdi8EfMLdvfzp98ZHwEegAyPgE24Hdo5vmo/A7o/Aj6uHPuH+uPzt99ZHwEdgFyLw/wAAAP//KU22lgAAAAZJREFUAwD0+roy0cgLKgAAAABJRU5ErkJggg==" style="max-height:60px; max-width:95%; width:auto; display:block; margin:0 auto;">
              </div>
              <div style="border-top:1.5px solid #000; margin:0; width:100%;"></div>
              <div style="font-size:7.5px; font-weight:bold; color:#002060; text-align:center; padding:4px 2px; font-family:Arial, sans-serif;">PT. BHUMI KARYA UTAMA</div>
            </td>
            <td style="width:45%; text-align:center; border:1px solid #111; padding:6px; vertical-align:middle;">
              <div style="font-size:9px; color:#555; font-weight:bold; letter-spacing:1px;">FORMULIR</div>
              <div style="font-size:15px; font-weight:900; color:#111; letter-spacing:0.5px; margin-top:2px;">PERMOHONAN DANA</div>
            </td>
            <td style="width:30%; padding:0; border:1px solid #111; vertical-align:middle;">
              <table style="width:100%; border-collapse:collapse;">
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:80px; border-right:1px solid #ddd; padding:3px 5px; border-bottom:1px solid #eee;">No Dokumen</td><td style="border-bottom:1px solid #eee; padding:3px 5px; font-weight:bold;">BIS.FR.FAT.001</td></tr>

                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:80px; border-right:1px solid #ddd; padding:3px 5px; border-bottom:1px solid #eee;">Tanggal Efektif</td><td style="border-bottom:1px solid #eee; padding:3px 5px;">01-Jan-26</td></tr>
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:80px; border-right:1px solid #ddd; padding:3px 5px; border-bottom:1px solid #eee;">Revisi</td><td style="border-bottom:1px solid #eee; padding:3px 5px;">01</td></tr>
                <tr><td style="font-weight:bold; color:#444; background:#f5f5f5; width:80px; border-right:1px solid #ddd; padding:3px 5px;">Halaman</td><td style="padding:3px 5px;">1 dari 1</td></tr>
              </table>
            </td>
          </tr>
        </table>
        
        <!-- Metadata table rows -->
        <table style="width:100%; border-collapse:collapse; border:1px solid #111; margin-bottom:8px; font-size:9.5px;">
          <tr>
            <td style="font-weight:bold; color:#444; background:#f5f5f5; width:12%; border:1px solid #111; padding:4px;">NO</td>
            <td style="width:3%; text-align:center; font-weight:bold; border:1px solid #111; padding:4px;">:</td>
            <td style="font-weight:bold; color:#111; border:1px solid #111; padding:4px;">${doc.docNumber}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#444; background:#f5f5f5; width:12%; border:1px solid #111; padding:4px;">TGL</td>
            <td style="text-align:center; font-weight:bold; border:1px solid #111; padding:4px;">:</td>
            <td style="border:1px solid #111; padding:4px;">${formatDate(doc.date)}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#444; background:#f5f5f5; width:12%; border:1px solid #111; padding:4px;">DEPT</td>
            <td style="text-align:center; font-weight:bold; border:1px solid #111; padding:4px;">:</td>
            <td style="border:1px solid #111; padding:4px;">${doc.dept}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#444; background:#f5f5f5; width:12%; border:1px solid #111; padding:4px;">SUBJECT</td>
            <td style="text-align:center; font-weight:bold; border:1px solid #111; padding:4px;">:</td>
            <td style="font-weight:bold; border:1px solid #111; padding:4px;">${doc.subject}</td>
          </tr>
        </table>
        
        <!-- Items Table -->
        <table style="width:100%; border-collapse:collapse; border:1px solid #111; margin-bottom:8px;">
          <thead>
            <tr>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:4%;">NO</th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:8%;">PC<br><small style="font-weight:normal; font-size:7.5px;">(PROJECT CODE)</small></th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:10%;">DR<br><small style="font-weight:normal; font-size:7.5px;">(DISTRIBUTION RULES)<br>*Diisi Oleh Cost Control</small></th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase;">DESCRIPTION</th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:6%;">QTY</th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:12%;">PRICE</th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:14%;">AMOUNT (IDR)</th>
              <th style="background:#f5f5f5; color:#111; padding:4px; font-weight:bold; border:1px solid #111; font-size:9px; text-transform:uppercase; width:16%;">INFORMATION</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRowsHTML}
            <tr style="font-weight:bold; background:#f5f5f5;">
              <td colspan="5" style="border:1px solid #111; padding:4px; text-align:right;">TOTAL PERMOHONAN DANA :</td>
              <td style="border:1px solid #111; padding:4px; text-align:center;">Rp</td>
              <td style="border:1px solid #111; padding:4px; text-align:right; color:#c8102e;">${formatCurrency(doc.nominal).substring(3)}</td>
              <td style="border:1px solid #111; padding:4px;"></td>
            </tr>
          </tbody>
        </table>
        
        <!-- Terbilang Box -->
        <div style="background:#fafafa; border:1px solid #ddd; padding:6px 10px; font-size:9px; margin-bottom:8px;">Terbilang : <strong>${terbilangText} rupiah</strong></div>
        
        <!-- Budget Review -->
        <div style="font-size:8.5px; font-weight:bold; margin-bottom:4px;">Budget Review <span style="font-weight:normal; font-style:italic; color:#666;">*Diisi Oleh Cost Control</span></div>
        <table style="width:100%; border-collapse:collapse; border:1px solid #111; text-align:center; margin-bottom:8px;">
          <thead>
            <tr>
              <th style="background:#e3f2fd; color:#111; border:1px solid #111; padding:4px; font-size:9px; font-weight:bold; width:20%;">PC</th>
              <th style="background:#e3f2fd; color:#111; border:1px solid #111; padding:4px; font-size:9px; font-weight:bold; width:22%;">DR</th>
              <th style="background:#e3f2fd; color:#111; border:1px solid #111; padding:4px; font-size:9px; font-weight:bold; width:20%;">Budget Available</th>
              <th style="background:#e3f2fd; color:#111; border:1px solid #111; padding:4px; font-size:9px; font-weight:bold; width:20%;">Budget Actual</th>
              <th style="background:#e3f2fd; color:#111; border:1px solid #111; padding:4px; font-size:9px; font-weight:bold; width:18%;">Variant (a-b)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="font-weight:bold; border:1px solid #111; padding:4px;"></td>
              <td style="border:1px solid #111; padding:4px;"></td>
              <td style="font-weight:bold; border:1px solid #111; padding:4px;"></td>
              <td style="border:1px solid #111; padding:4px;"></td>
              <td style="font-weight:bold; border:1px solid #111; padding:4px;"></td>
            </tr>

          </tbody>
        </table>
        
        <!-- Signatures Grid -->
        <table style="width:100%; border-collapse:collapse; text-align:center; font-size:8.5px; table-layout:fixed;">
          <thead>
            <tr style="background:#f5f5f5; font-weight:bold;">
              <th style="width:12.5%; border:1px solid #111; padding:3px;">Prepared By,</th>
              <th style="width:12.5%; border:1px solid #111; padding:3px;">Verified By,</th>
              <th style="width:12.5%; border:1px solid #111; padding:3px;">Approved By,</th>
              <th colspan="3" style="width:37.5%; border:1px solid #111; padding:3px;">Verification Column<br><small style="font-weight:normal; font-size:7.5px;">Checked By.</small></th>
              <th colspan="2" style="width:25%; border:1px solid #111; padding:3px;">Disbursement Approval<br><small style="font-weight:normal; font-size:7.5px;">Approved By.</small></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigPrepared.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigVerified.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigApprovedPm.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigCheckedFin.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigCheckedCc.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigCheckedAcc.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigDisbPm.content}</td>
              <td style="height:35px; vertical-align:middle; border:1px solid #111; padding:3px;">${sigDisbCfo.content}</td>
            </tr>
            <tr style="font-weight:bold; font-size:8px;">
              <td style="border:1px solid #111; padding:3px;">${sigPrepared.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigVerified.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigApprovedPm.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigCheckedFin.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigCheckedCc.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigCheckedAcc.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigDisbPm.name}</td>
              <td style="border:1px solid #111; padding:3px;">${sigDisbCfo.name}</td>
            </tr>
            <tr style="font-size:7.5px; color:#555; font-weight:normal; vertical-align:top;">
              <td style="border:1px solid #111; padding:3px;">USER</td>
              <td style="border:1px solid #111; padding:3px;">Dept. Head Department<br>/ Project Manager</td>
              <td style="border:1px solid #111; padding:3px;">Project Manager /<br>Operation Manager</td>
              <td style="border:1px solid #111; padding:3px;">Finance Site</td>
              <td style="border:1px solid #111; padding:3px;">Cost Control</td>
              <td style="border:1px solid #111; padding:3px;">Accounting HO</td>
              <td style="border:1px solid #111; padding:3px;">Project Manager /<br>GM Operation / COO</td>
              <td style="border:1px solid #111; padding:3px;">GM FAT / CFO</td>
            </tr>
          </tbody>
        </table>
        
        <!-- Approval Matrix -->
        <table style="width:100%; border-collapse:collapse; text-align:center; font-size:8.5px; border:1px solid #111; table-layout:fixed; margin-top:15px;">
          <thead>
            <tr style="font-weight:bold;">
              <th style="border:1px solid #111; padding:3px; background:#ccc; font-style:italic; width:25%;">Matriks Persetujuan</th>
              <th style="border:1px solid #111; padding:3px; width:25%;">Diajukan</th>
              <th style="border:1px solid #111; padding:3px; width:25%;">Disetujui</th>
              <th style="border:1px solid #111; padding:3px; width:25%;">Persetujuan Pencairan</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border:1px solid #111; padding:3px; font-weight:bold;">&le; 5 Juta Rupiah</td>
              <td style="border:1px solid #111; padding:3px;">User (Supervisor)</td>
              <td style="border:1px solid #111; padding:3px;">Dept. Head</td>
              <td style="border:1px solid #111; padding:3px;">PM / Manager</td>
            </tr>
            <tr>
              <td style="border:1px solid #111; padding:3px; font-weight:bold;">&gt; 5 Jt - 44 Jt Rupiah</td>
              <td style="border:1px solid #111; padding:3px;">Dept Head</td>
              <td style="border:1px solid #111; padding:3px;">PM / Manager</td>
              <td style="border:1px solid #111; padding:3px;">Board of Executive</td>
            </tr>
            <tr>
              <td style="border:1px solid #111; padding:3px; font-weight:bold;">&gt; 45 jt - &le; 100 jt</td>
              <td style="border:1px solid #111; padding:3px;">PM/ Manager</td>
              <td style="border:1px solid #111; padding:3px;">GM</td>
              <td style="border:1px solid #111; padding:3px;">BOE & GM FAT</td>
            </tr>
            <tr>
              <td style="border:1px solid #111; padding:3px; font-weight:bold;">&gt; 100 jt</td>
              <td style="border:1px solid #111; padding:3px;">Manager / GM</td>
              <td style="border:1px solid #111; padding:3px;">BOE</td>
              <td style="border:1px solid #111; padding:3px;">GM FAT / CFO</td>
            </tr>
          </tbody>
        </table>
        
        ${doc.budgetCapture ? `
          <div style="border:1px solid #111; padding:8px; margin-top:12px; page-break-inside:avoid;">
            <div style="font-weight:bold; font-size:10px; border-bottom:1px solid #111; padding-bottom:3px; margin-bottom:5px; text-transform:uppercase;">Capture Budget / Bukti Budget:</div>
            <div style="text-align:center;"><img src="${doc.budgetCapture}" style="max-height:280px; max-width:100%; object-fit:contain;" /></div>
          </div>
        ` : ''}
        
        ${doc.attachment ? `
          <div class="page-break-preview" style="border:1px solid #111; padding:8px; margin-top:20px;">
            <div style="font-weight:bold; font-size:10px; border-bottom:1px solid #111; padding-bottom:3px; margin-bottom:5px; text-transform:uppercase;">Lampiran / Attachments:</div>
            ${doc.attachment.indexOf('data:application/pdf') === 0 || doc.attachment.toLowerCase().indexOf('.pdf') !== -1 || (doc.attachmentName && doc.attachmentName.toLowerCase().indexOf('.pdf') !== -1) ? 
              (doc.attachment.indexOf('data:application/pdf') === 0 ? 
                `<div class="pdf-rendering-container" data-pdf="${doc.attachment}" style="text-align:center; padding:10px;">Mengurai halaman PDF...</div>` :
                `<div style="padding:10px;"><a href="${doc.attachment}" target="_blank" style="color:#1565c0; text-decoration:underline; font-weight:bold;"><i class="fas fa-external-link-alt"></i> Buka Lampiran PDF (${doc.attachmentName || 'File'})</a></div>`
              ) :
              (doc.attachment.indexOf('data:image') === 0 || doc.attachment.match(/\.(jpeg|jpg|gif|png|webp|svg)/i) || (doc.attachmentName && doc.attachmentName.match(/\.(jpeg|jpg|gif|png|webp|svg)/i)) ? 
                `<div style="text-align:center; padding:10px;"><img src="${doc.attachment}" style="width:100%; max-width:100%; height:auto; object-fit:contain;" /></div>` : 
                `<div style="padding:10px;"><a href="${doc.attachment}" target="_blank" download="${doc.attachmentName || 'lampiran'}" style="color:#1565c0; text-decoration:underline; font-weight:bold;">Unduh Lampiran (${doc.attachmentName || 'File'})</a></div>`
              )
            }
          </div>
        ` : ''}
      </div>
    `;
  }
}

// Terbilang helper function in Indonesian
function terbilang(angka) {
  angka = Math.floor(angka);
  if (angka < 0) return "minus " + terbilang(Math.abs(angka));
  if (angka === 0) return "nol";
  
  var kata = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"];
  var temp = "";
  
  if (angka < 12) {
    temp = " " + kata[angka];
  } else if (angka < 20) {
    temp = terbilang(angka - 10) + " belas";
  } else if (angka < 100) {
    temp = terbilang(Math.floor(angka / 10)) + " puluh" + terbilang(angka % 10);
  } else if (angka < 200) {
    temp = " seratus" + terbilang(angka - 100);
  } else if (angka < 1000) {
    temp = terbilang(Math.floor(angka / 100)) + " ratus" + terbilang(angka % 100);
  } else if (angka < 2000) {
    temp = " seribu" + terbilang(angka - 1000);
  } else if (angka < 1000000) {
    temp = terbilang(Math.floor(angka / 1000)) + " ribu" + terbilang(angka % 1000);
  } else if (angka < 1000000000) {
    temp = terbilang(Math.floor(angka / 1000000)) + " juta" + terbilang(angka % 1000000);
  } else if (angka < 1000000000000) {
    temp = terbilang(Math.floor(angka / 1000000000)) + " milyar" + terbilang(angka % 1000000000);
  } else if (angka < 1000000000000000) {
    temp = terbilang(Math.floor(angka / 1000000000000)) + " trilyun" + terbilang(angka % 1000000000000);
  }
  
  return temp.replace(/\s+/g, ' ').trim();
}

/**
 * ADMINISTRATOR CRUD ENDPOINTS
 */
function createUserRecord(payload) {
  try {
    if (useGitHub()) {
      var existing = getGitHubData('m_users');
      var count = existing.length + 1;
      var existingIds = existing.map(function(row) {
        var rawId = row.ID || row.id || '';
        return rawId.toString();
      });
      var idValue = 'USR-' + count;
      while (existingIds.indexOf('USR-' + count) !== -1) {
        count++;
      }
      idValue = 'USR-' + count;
      
      payload.ID = idValue;
      payload.Signature = '';
      appendObjectToSheet('m_users', payload);
      return { success: true, record: payload };
    }

    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('m_users');
    if (!sheet) return { success: false, error: 'User sheet not found' };
    
    var lastRow = sheet.getLastRow();
    var idValue = 'USR-' + lastRow;
    
    payload.ID = idValue;
    payload.Signature = '';
    
    appendObjectToSheet('m_users', payload);
    return { success: true, record: payload };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function editUserRecord(userId, payload) {
  try {
    var success = updateObjectInSheet('m_users', userId, payload);
    return { success: success };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function deleteUserRecord(userId) {
  try {
    if (useGitHub()) {
      var success = deleteGitHubRecord('m_users', userId);
      return { success: success, error: success ? null : 'User delete failed' };
    }

    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('m_users');
    if (!sheet) return { success: false, error: 'User sheet not found' };
    
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var idIndex = headers.indexOf('ID');
    if (idIndex === -1) return { success: false, error: 'ID column not found' };
    
    for (var i = 1; i < data.length; i++) {
      if (data[i][idIndex].toString() === userId.toString()) {
        sheet.deleteRow(i + 1);
        return { success: true };
      }
    }
    return { success: false, error: 'User not found' };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function updateMatrixApproval(matrixId, steps) {
  try {
    var success = updateObjectInSheet('t_approval_matrix', matrixId, {
      Steps: steps.join(', ')
    });
    return { success: success };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}


/**
 * =========================================================================
 * GITHUB DATABASE & STORAGE CONNECTOR DRIVER
 * =========================================================================
 */

var SEED_DATA = {
  'm_departments': [
    { ID: 'DEPT-1', Code: 'HRGA', Name: 'Human Resources & General Affairs' },
    { ID: 'DEPT-2', Code: 'QAQC', Name: 'Quality Assurance & Quality Control' },
    { ID: 'DEPT-3', Code: 'SHE', Name: 'Safety, Health & Environment' },
    { ID: 'DEPT-4', Code: 'Engineering', Name: 'Engineering Department' },
    { ID: 'DEPT-5', Code: 'Plant', Name: 'Plant Operation' },
    { ID: 'DEPT-6', Code: 'External', Name: 'External Affairs' },
    { ID: 'DEPT-7', Code: 'Eksplorasi', Name: 'Eksplorasi & Geological' }
  ],
  'm_projects': [
    { ID: 'PROJ-1', Code: 'PROJ-CRM', Name: 'CRM System Development' },
    { ID: 'PROJ-2', Code: 'PROJ-MSR', Name: 'MSR Safety Procurement' },
    { ID: 'PROJ-3', Code: 'PROJ-EXPL', Name: 'Sko Coal Drilling Plan' }
  ],
  'm_coas': [
    { ID: 'COA-1', Code: '610-02-03-001', Name: 'Kipas Angin Regency 16 Inch' },
    { ID: 'COA-2', Code: '610-02-03-002', Name: 'Stop Kontak Arde 5 Meter' },
    { ID: 'COA-3', Code: '610-02-05-001', Name: 'Termometer Digital' },
    { ID: 'COA-4', Code: '610-02-05-002', Name: 'Safety Helmet Yellow' },
    { ID: 'COA-5', Code: '610-02-06-001', Name: 'Kertas A4 80gr Sinar Dunia' }
  ],
  'm_cost_elements': [
    { ID: 'CE-1', Code: '612.01.04', Name: 'Office Supplies' },
    { ID: 'CE-2', Code: '612.01.05', Name: 'Tool Equipment' },
    { ID: 'CE-3', Code: '612.02.01', Name: 'Safety Equipment' }
  ],
  'm_users': [
    { ID: 'USR-1', Username: 'mona.asrani', Fullname: 'Mona Asrani', Role: 'Supervisor', Department: 'HRGA', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-2', Username: 'rosalia.natalia', Fullname: 'Rosalia Natalia', Role: 'Project Manager', Department: 'Management', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-3', Username: 'putri.amalia', Fullname: 'Putri Amalia', Role: 'Finance', Department: 'Finance', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-4', Username: 'rosmina.rabbang', Fullname: 'Rosmina Rabbang', Role: 'Supervisor', Department: 'SHE', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-5', Username: 'erwin.eka', Fullname: 'Erwin Eka', Role: 'Supervisor', Department: 'External', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-6', Username: 'yusril', Fullname: 'Yusril', Role: 'Supervisor', Department: 'QAQC', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-7', Username: 'roymon.biang', Fullname: 'Roymon Biang', Role: 'Supervisor', Department: 'Engineering', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-8', Username: 'muh.said', Fullname: 'Muh. Said', Role: 'Supervisor', Department: 'Plant', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-9', Username: 'laode.rusman', Fullname: 'Laode Rusman', Role: 'Supervisor', Department: 'Eksplorasi', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-10', Username: 'idul.yusuf', Fullname: 'Muh Idul Adhan Yusuf', Role: 'User', Department: 'HRGA', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-11', Username: 'saiful.basri', Fullname: 'Saiful Basri', Role: 'User', Department: 'SHE', Password: 'BARAindah@2026', Signature: '', Status: 'Active' },
    { ID: 'USR-12', Username: 'admin', Fullname: 'System Administrator', Role: 'Administrator', Department: 'IT', Password: 'BARAindah@2026', Signature: '', Status: 'Active' }
  ],
  't_approval_matrix': [
    { ID: 'AM-1', DocType: 'PD', Department: 'ALL', MinAmount: 0, MaxAmount: 99999999999, Steps: 'Project Manager, Finance' },
    { ID: 'AM-2', DocType: 'PR', Department: 'ALL', MinAmount: 0, MaxAmount: 99999999999, Steps: 'Supervisor, Finance, Project Manager' }
  ],
  't_budget': [
    { ID: 'B-1', Department: 'HRGA', Project: 'PROJ-CRM', Year: 2026, AnnualBudget: 650000000, ActualBudget: 420000000 },
    { ID: 'B-2', Department: 'QAQC', Project: 'PROJ-CRM', Year: 2026, AnnualBudget: 320000000, ActualBudget: 150000000 },
    { ID: 'B-3', Department: 'SHE', Project: 'PROJ-MSR', Year: 2026, AnnualBudget: 180000000, ActualBudget: 80000000 },
    { ID: 'B-4', Department: 'Engineering', Project: 'PROJ-CRM', Year: 2026, AnnualBudget: 2100000000, ActualBudget: 1200000000 },
    { ID: 'B-5', Department: 'Plant', Project: 'PROJ-CRM', Year: 2026, AnnualBudget: 4200000000, ActualBudget: 2800000000 },
    { ID: 'B-6', Department: 'External', Project: 'PROJ-CRM', Year: 2026, AnnualBudget: 252000000, ActualBudget: 110000000 },
    { ID: 'B-7', Department: 'Eksplorasi', Project: 'PROJ-EXPL', Year: 2026, AnnualBudget: 2000000000, ActualBudget: 1400000000 }
  ],
  't_requests': [],
  't_request_items': [],
  't_audit_log': []
};

// Helper Map of lowercase table fields to original Sheets casings
var FIELD_CASING_MAP = {
  id: 'ID',
  type: 'Type',
  docnumber: 'DocNumber',
  date: 'Date',
  department: 'Department',
  priority: 'Priority',
  inventorytype: 'InventoryType',
  purchasecategory: 'PurchaseCategory',
  subject: 'Subject',
  requester: 'Requester',
  totalnominal: 'TotalNominal',
  status: 'Status',
  currentapproverrole: 'CurrentApproverRole',
  createdat: 'CreatedAt',
  signatures: 'Signatures',
  userfor: 'UserFor',
  attachment: 'Attachment',
  attachmentname: 'AttachmentName',
  budgetcapture: 'BudgetCapture',
  requestid: 'RequestId',
  coa: 'COA',
  partnumber: 'PartNumber',
  description: 'Description',
  costelement: 'CostElement',
  quantity: 'Quantity',
  uom: 'UoM',
  price: 'Price',
  total: 'Total',
  doctype: 'DocType',
  minamount: 'MinAmount',
  maxamount: 'MaxAmount',
  steps: 'Steps',
  project: 'Project',
  year: 'Year',
  annualbudget: 'AnnualBudget',
  actualbudget: 'ActualBudget',
  timestamp: 'Timestamp',
  user: 'User',
  activity: 'Activity',
  module: 'Module',
  ipaddress: 'IPAddress',
  code: 'Code',
  name: 'Name',
  username: 'Username',
  fullname: 'Fullname',
  role: 'Role',
  password: 'Password',
  signature: 'Signature'
};

function useGitHub() {
  var props = PropertiesService.getScriptProperties();
  var dbType = props.getProperty('DB_TYPE');
  var owner = props.getProperty('GITHUB_OWNER');
  var repo = props.getProperty('GITHUB_REPO');
  var token = props.getProperty('GITHUB_TOKEN');
  return (dbType === 'GITHUB' || (owner && repo && token && dbType !== 'SHEETS'));
}

function getGitHubOwner() {
  return PropertiesService.getScriptProperties().getProperty('GITHUB_OWNER') || '';
}

function getGitHubRepo() {
  return PropertiesService.getScriptProperties().getProperty('GITHUB_REPO') || '';
}

function getGitHubBranch() {
  return PropertiesService.getScriptProperties().getProperty('GITHUB_BRANCH') || 'main';
}

function getGitHubToken() {
  return PropertiesService.getScriptProperties().getProperty('GITHUB_TOKEN') || '';
}

function setupGitHubCredentials(owner, repo, token, branch) {
  branch = branch || 'main';
  var props = PropertiesService.getScriptProperties();
  props.setProperty('GITHUB_OWNER', owner);
  props.setProperty('GITHUB_REPO', repo);
  props.setProperty('GITHUB_TOKEN', token);
  props.setProperty('GITHUB_BRANCH', branch);
  props.setProperty('DB_TYPE', 'GITHUB');
  return "GitHub credentials updated successfully!";
}

function mapGitHubRowToAppsScript(row) {
  if (!row) return row;
  var mapped = {};
  for (var key in row) {
    if (row.hasOwnProperty(key)) {
      var val = row[key];
      var originalKey = FIELD_CASING_MAP[key.toLowerCase()] || key;
      mapped[originalKey] = val;
      
      // Map lowercase key
      var lowerKey = originalKey.toLowerCase();
      if (originalKey !== lowerKey) {
        mapped[lowerKey] = val;
      }
      // Map TitleCase key
      var titleKey = lowerKey.charAt(0).toUpperCase() + lowerKey.slice(1);
      if (originalKey !== titleKey) {
        mapped[titleKey] = val;
      }
    }
  }
  return mapped;
}

function getFileSha(path) {
  var url = 'https://api.github.com/repos/' + getGitHubOwner() + '/' + getGitHubRepo() + '/contents/' + path + '?ref=' + getGitHubBranch() + '&t=' + new Date().getTime();
  var options = {
    method: 'GET',
    headers: {
      Authorization: 'Bearer ' + getGitHubToken(),
      Accept: 'application/vnd.github.v3+json'
    },
    muteHttpExceptions: true
  };
  var response = UrlFetchApp.fetch(url, options);
  if (response.getResponseCode() === 200) {
    var json = JSON.parse(response.getContentText());
    return json.sha;
  }
  return null;
}

function getGitHubData(tableName) {
  var path = 'db/' + tableName + '.json';
  var url = 'https://api.github.com/repos/' + getGitHubOwner() + '/' + getGitHubRepo() + '/contents/' + path + '?ref=' + getGitHubBranch() + '&t=' + new Date().getTime();
  var options = {
    method: 'GET',
    headers: {
      Authorization: 'Bearer ' + getGitHubToken(),
      Accept: 'application/vnd.github.v3+json'
    },
    muteHttpExceptions: true
  };
  var response = UrlFetchApp.fetch(url, options);
  var code = response.getResponseCode();
  
  if (code === 404) {
    // Auto-seed if not exists
    var seed = SEED_DATA[tableName] || [];
    writeGitHubFile(path, seed);
    return seed.map(mapGitHubRowToAppsScript);
  }
  
  if (code < 200 || code >= 300) {
    throw new Error("Failed to read " + tableName + " from GitHub: " + response.getContentText());
  }
  
  var json = JSON.parse(response.getContentText());
  var decodedStr = Utilities.newBlob(Utilities.base64Decode(json.content)).getDataAsString();
  var data = JSON.parse(decodedStr);
  return data.map(mapGitHubRowToAppsScript);
}

function writeGitHubFile(path, dataObj) {
  var contentStr = JSON.stringify(dataObj, null, 2);
  var base64Content = Utilities.base64Encode(Utilities.newBlob(contentStr).getBytes());
  var sha = getFileSha(path);
  
  var url = 'https://api.github.com/repos/' + getGitHubOwner() + '/' + getGitHubRepo() + '/contents/' + path;
  var payload = {
    message: 'Update database: ' + path,
    content: base64Content
  };
  if (sha) {
    payload.sha = sha;
  }
  
  var options = {
    method: 'PUT',
    contentType: 'application/json',
    headers: {
      Authorization: 'Bearer ' + getGitHubToken(),
      Accept: 'application/vnd.github.v3+json'
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  var response = UrlFetchApp.fetch(url, options);
  var code = response.getResponseCode();
  if (code < 200 || code >= 300) {
    throw new Error("Failed to write file " + path + " to GitHub: " + response.getContentText());
  }
  return true;
}

function appendGitHubRecord(tableName, obj) {
  var data = getGitHubData(tableName);
  
  var dbObj = {};
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      var val = obj[key];
      if (key === 'Signatures' && typeof val === 'object') {
        val = JSON.stringify(val);
      }
      dbObj[key.toLowerCase()] = val;
    }
  }
  
  data.push(dbObj);
  writeGitHubFile('db/' + tableName + '.json', data);
  return true;
}

function updateGitHubRecord(tableName, idValue, updatedFields, idColumn) {
  idColumn = idColumn || 'id';
  var data = getGitHubData(tableName);
  var updated = false;
  
  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    var rowId = row[idColumn.toLowerCase()] || row[idColumn] || '';
    if (rowId.toString().toLowerCase() === idValue.toString().toLowerCase()) {
      for (var key in updatedFields) {
        if (updatedFields.hasOwnProperty(key)) {
          var val = updatedFields[key];
          if (key === 'Signatures' && typeof val === 'object') {
            val = JSON.stringify(val);
          }
          row[key.toLowerCase()] = val;
        }
      }
      updated = true;
      break;
    }
  }
  
  if (updated) {
    writeGitHubFile('db/' + tableName + '.json', data);
  }
  return updated;
}

function deleteGitHubRecord(tableName, idValue, idColumn) {
  idColumn = idColumn || 'id';
  var data = getGitHubData(tableName);
  var initialLength = data.length;
  
  data = data.filter(function(row) {
    var rowId = row[idColumn.toLowerCase()] || row[idColumn] || '';
    return rowId.toString().toLowerCase() !== idValue.toString().toLowerCase();
  });
  
  if (data.length !== initialLength) {
    writeGitHubFile('db/' + tableName + '.json', data);
    return true;
  }
  return false;
}

function uploadToGitHubStorage(base64Data, fileName) {
  try {
    if (!base64Data || base64Data.indexOf('data:') !== 0) {
      return base64Data; // Return as is if already a URL or empty
    }
    
    var parts = base64Data.split(',');
    var header = parts[0];
    var content = parts[1]; // base64 encoded file content
    var mimeType = header.split(';')[0].split(':')[1];
    
    // Generate unique name
    var fileExt = fileName.split('.').pop();
    var cleanName = fileName.substring(0, fileName.lastIndexOf('.')).replace(/[^a-zA-Z0-9]/g, '_');
    var uniqueName = Utilities.getUuid().substring(0, 8) + '_' + cleanName + '.' + fileExt;
    
    var path = 'attachments/' + uniqueName;
    var url = 'https://api.github.com/repos/' + getGitHubOwner() + '/' + getGitHubRepo() + '/contents/' + path;
    
    var payload = {
      message: 'Upload attachment: ' + uniqueName,
      content: content
    };
    
    var options = {
      method: 'PUT',
      contentType: 'application/json',
      headers: {
        Authorization: 'Bearer ' + getGitHubToken(),
        Accept: 'application/vnd.github.v3+json'
      },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    };
    
    var response = UrlFetchApp.fetch(url, options);
    var code = response.getResponseCode();
    if (code === 200 || code === 201) {
      return 'https://raw.githubusercontent.com/' + getGitHubOwner() + '/' + getGitHubRepo() + '/' + getGitHubBranch() + '/' + path;
    } else {
      Logger.log("GitHub storage upload failed with code " + code + ": " + response.getContentText());
      return base64Data; // Fallback
    }
  } catch(e) {
    Logger.log("Error uploading to GitHub Storage: " + e.toString());
    return base64Data; // Fallback
  }
}

/**
 * AUTOMATIC DATA MIGRATION UTILITY
 */
function migrateSheetsToGitHub() {
  if (!useGitHub()) {
    return "Error: GitHub is not configured yet. Add DB_TYPE, GITHUB_OWNER, GITHUB_REPO, and GITHUB_TOKEN in script properties.";
  }
  
  var ss = getSpreadsheet();
  var tables = [
    'm_departments',
    'm_projects',
    'm_coas',
    'm_cost_elements',
    'm_users',
    't_approval_matrix',
    't_budget',
    't_requests',
    't_request_items',
    't_audit_log'
  ];
  
  var results = [];
  
  for (var i = 0; i < tables.length; i++) {
    var tableName = tables[i];
    var sheet = ss.getSheetByName(tableName);
    if (!sheet) {
      results.push(tableName + ": Sheet not found");
      continue;
    }
    
    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) {
      results.push(tableName + ": No data to migrate");
      continue;
    }
    
    var headers = data[0];
    var rows = data.slice(1);
    var migratedData = [];
    
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var obj = {};
      headers.forEach(function(header, idx) {
        if (header !== undefined && header !== null && header !== '') {
          obj[header] = row[idx];
        }
      });
      
      // Specially handle attachment conversion during migration
      if (tableName === 't_requests') {
        if (obj.Attachment && obj.Attachment.indexOf('data:') === 0) {
          obj.Attachment = uploadToGitHubStorage(obj.Attachment, obj.AttachmentName || 'attachment.pdf');
        }
        if (obj.BudgetCapture && obj.BudgetCapture.indexOf('data:') === 0) {
          obj.BudgetCapture = uploadToGitHubStorage(obj.BudgetCapture, 'budget_capture.png');
        }
      }
      
      // Map to lowercase keys
      var lowerObj = {};
      for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
          var val = obj[key];
          if (key === 'Signatures' && typeof val === 'object') {
            val = JSON.stringify(val);
          }
          lowerObj[key.toLowerCase()] = val;
        }
      }
      migratedData.push(lowerObj);
    }
    
    try {
      writeGitHubFile('db/' + tableName + '.json', migratedData);
      results.push(tableName + ": Migrated " + migratedData.length + " rows");
    } catch(err) {
      results.push(tableName + ": Migration failed - " + err.toString());
    }
  }
  
  return "Migration to GitHub completed!\n" + results.join("\n");
}

function doPost(e) {
  var JSONResponse;
  try {
    var requestData = JSON.parse(e.postData.contents);
    var action = requestData.action;
    var args = requestData.args || [];
    
    var allowedActions = [
      'getDashboardData', 'getApprovalRequests', 'processApproval', 
      'getDocumentHistory', 'saveUserSignature', 'createUserRecord', 
      'editUserRecord', 'deleteUserRecord', 'getDropdownData',
      'saveBudgetLive', 'deleteBudgetLive', 'importBudgetLiveCSV',
      'isPMOnLeave', 'getApprovalSteps'
    ];
    
    if (allowedActions.indexOf(action) !== -1) {
      var result = this[action].apply(this, args);
      JSONResponse = { success: true, data: result };
    } else {
      JSONResponse = { success: false, error: 'Unauthorized or invalid action: ' + action };
    }
  } catch (err) {
    JSONResponse = { success: false, error: err.toString() };
  }
  
  return ContentService.createTextOutput(JSON.stringify(JSONResponse))
    .setMimeType(ContentService.MimeType.JSON);
}



